import {PRE_PATTERN, POST_PATTERN, ACTIVITY_PATTERN, isEndActivityTitle} from './rules.js';

export function forumTaskKind(title = '', groupContext = '') {
  const localContext = String(groupContext || '');
  if (POST_PATTERN.test(title) || POST_PATTERN.test(localContext)) return 'post_quiz';
  if (PRE_PATTERN.test(title) || PRE_PATTERN.test(localContext)) return 'pre_quiz';
  if (isEndActivityTitle(title) || ACTIVITY_PATTERN.test(title) || ACTIVITY_PATTERN.test(localContext) || /แบบฝึกหัด|แบบทดสอบท้ายบท/i.test(title)) return 'assignment';
  return null;
}

export function forumTaskEvidence(title, contentText, groupContext = '') {
  const kind = forumTaskKind(title, groupContext);
  const body = String(contentText || '').replace(/\s+/g, ' ').trim();
  const instructionSource = `${title} ${body}`;
  const instructions = /ให้นักศึกษา|ให้ผู้เรียน|จง|ตอบคำถาม|คำถาม|สรุป|อธิบาย|วิเคราะห์|อภิปราย|แสดงความคิดเห็น|ส่งงาน|ทำแบบฝึกหัด|อะไร|อย่างไร|เพราะเหตุใด|ใครบ้าง|ใคร|อะไรบ้าง|\?|answer|summari[sz]e|describe|explain|analyse|analyze|discuss|comment|submit|what|why|how/i.test(instructionSource);
  const numbered = /(?:^|\s)[1-9][0-9]*[.)]\s*\S/.test(body);
  return {kind, confirmed:Boolean(kind && body.length >= 30 && (instructions || numbered)), excerpt:body.slice(0, 800)};
}
