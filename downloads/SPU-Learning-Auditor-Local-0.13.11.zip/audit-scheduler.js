export async function runBounded(items, handler, {
  concurrency = 2,
  deadline = Number.POSITIVE_INFINITY,
  onDeadline = async () => {},
  onSettled = async () => {}
} = {}) {
  const list = Array.from(items || []);
  const workerCount = Math.min(Math.max(1, Math.floor(concurrency)), Math.max(1, list.length));
  let nextIndex = 0;
  let started = 0;
  let skipped = 0;
  const worker = async () => {
    while (true) {
      const index = nextIndex++;
      if (index >= list.length) return;
      const item = list[index];
      try {
        if (Date.now() >= deadline) {
          skipped += 1;
          await onDeadline(item, index);
        } else {
          started += 1;
          await handler(item, index);
        }
      } finally {
        await onSettled(item, index);
      }
    }
  };
  // A failing worker must not let a new course start while sibling workers
  // still own preview tabs or probes from the previous course.
  const results = await Promise.allSettled(Array.from({ length:workerCount }, worker));
  const failed = results.find((result) => result.status === "rejected");
  if (failed) throw failed.reason;
  return { total:list.length, started, skipped, concurrency:workerCount };
}

export function createLimiter(concurrency = 1) {
  const limit = Math.max(1, Math.floor(Number(concurrency) || 1));
  const waiting = [];
  let active = 0;

  const dispatch = () => {
    while (active < limit && waiting.length) {
      active += 1;
      const {resolve} = waiting.shift();
      let released = false;
      resolve(() => {
        if (released) return;
        released = true;
        active -= 1;
        dispatch();
      });
    }
  };

  const acquire = () => new Promise((resolve, reject) => {
    waiting.push({resolve,reject});
    dispatch();
  });

  const run = async (task) => {
    const release = await acquire();
    try { return await task(); }
    finally { release(); }
  };

  const cancelWaiting = (error) => { waiting.splice(0).forEach((entry) => entry.reject(error)); };
  return { acquire, run, cancelWaiting, stats:() => ({ active, waiting:waiting.length, limit }) };
}

export function interleaveByKey(items, keyFor) {
  const groups = new Map();
  for (const item of items || []) {
    const key = String(keyFor(item) ?? "");
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(item);
  }
  const queues = [...groups.values()];
  const ordered = [];
  let remaining = queues.reduce((sum, queue) => sum + queue.length, 0);
  while (remaining > 0) {
    for (const queue of queues) {
      if (!queue.length) continue;
      ordered.push(queue.shift());
      remaining -= 1;
    }
  }
  return ordered;
}
