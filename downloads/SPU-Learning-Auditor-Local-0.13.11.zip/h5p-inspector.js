(() => {
  const unique = (items) => [...new Set(items.filter(Boolean))];
  const youtube = (url) => /(?:youtube(?:-nocookie)?\.com|youtu\.be)/i.test(url);
  const findUrls = (text) => [...String(text || "").matchAll(/https?:\\?\/\\?\/[^"'\\\s<>]+/gi)]
    .map((match) => match[0].replace(/\\\//g, "/"));
  const jsonObjectAfter = (text, marker) => {
    const markerIndex = text.indexOf(marker);
    if (markerIndex < 0) return null;
    const start = text.indexOf("{", markerIndex + marker.length);
    if (start < 0) return null;
    let depth = 0, quote = "", escaped = false;
    for (let index = start; index < text.length; index += 1) {
      const char = text[index];
      if (quote) {
        if (escaped) escaped = false;
        else if (char === "\\") escaped = true;
        else if (char === quote) quote = "";
      } else if (char === '"' || char === "'") quote = char;
      else if (char === "{") depth += 1;
      else if (char === "}" && --depth === 0) return text.slice(start, index + 1);
    }
    return null;
  };
  const integrationSummary = () => {
    const script = [...document.scripts].map((item) => item.textContent || "").find((text) => text.includes("H5PIntegration"));
    const raw = script && jsonObjectAfter(script, "var H5PIntegration");
    if (!raw) return { found:false, libraries:[], urls:[], error:"ไม่พบข้อมูล H5PIntegration ที่อ่านได้" };
    try {
      const integration = JSON.parse(raw);
      const contents = integration.contents || {};
      const records = Object.values(contents);
      const serialized = JSON.stringify(contents);
      const urls = unique(findUrls(serialized));
      const strings = [...serialized.matchAll(/"([^"\\]*(?:\\.[^"\\]*)*)"/g)].map((match) => match[1].replace(/\\\//g, "/"));
      const contentBase = urls.find((url) => /\/content\/\d+(?:$|[?#])/i.test(url));
      const relativeMedia = strings.filter((value) => /\.(?:mp4|webm|m4v|mov|m3u8)(?:[?#].*)?$/i.test(value));
      const mediaUrls = unique(relativeMedia.map((value) => /^https?:/i.test(value) ? value : contentBase ? `${contentBase.replace(/\/$/, "")}/${value.replace(/^\.?\//, "")}` : null));
      const videoDefinitions = [];
      const visit = (value) => {
        if (typeof value === "string") { if (/^\s*[\[{]/.test(value)) { try { visit(JSON.parse(value)); } catch { /* plain string */ } } return; }
        if (!value || typeof value !== "object") return;
        const mime = String(value.mime || value.contentType || value.type || "");
        const path = value.path || value.src || value.source || value.videoId || value.id;
        if (path && (/youtube/i.test(mime) || /youtube/i.test(String(value.sourceType || "")) || /\.(?:mp4|webm|m4v|mov|m3u8)(?:[?#].*)?$/i.test(String(path)))) videoDefinitions.push({path:String(path),mime});
        for (const child of Object.values(value)) visit(child);
      };
      visit(contents);
      return { found:true, libraries:unique(records.map((record) => record.library || record.libraryName)), urls, mediaUrls, videoDefinitions, contentCount:records.length };
    } catch (error) { return { found:false, libraries:[], urls:[], error:error.message }; }
  };
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type !== "INSPECT_H5P") return;
    try {
      const frames = [...document.querySelectorAll("iframe[src]")].map((frame) => frame.src);
      const media = [...document.querySelectorAll("video,source")].flatMap((element) => [element.currentSrc, element.src]);
      const anchors = [...document.querySelectorAll("a[href]")].map((anchor) => anchor.href);
      const scriptUrls = [...document.scripts].flatMap((script) => findUrls(script.textContent));
      const h5pContent = integrationSummary();
      const allUrls = unique([...frames, ...media, ...anchors, ...scriptUrls, ...h5pContent.urls]);
      sendResponse({
        ok:true,
        pageUrl:location.href,
        title:document.title,
        youtubeUrls:unique(allUrls.filter(youtube)),
        iframeUrls:unique(frames),
        mediaUrls:unique(media),
        h5pContent:{...h5pContent, youtubeUrls:unique(h5pContent.urls.filter(youtube)), mediaUrls:unique(h5pContent.mediaUrls || []), videoDefinitions:h5pContent.videoDefinitions || []},
        h5pSignals:unique([...document.scripts].map((script) => script.textContent || "").filter((text) => /H5PIntegration|jsonContent|H5P\.Video/i.test(text)).map((text) => text.slice(0, 1200)))
      });
    } catch (error) { sendResponse({ok:false,error:error.message}); }
  });
})();
