from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
ICON_DIR = ROOT / "icons"
ICON_DIR.mkdir(exist_ok=True)

canvas = 512
image = Image.new("RGBA", (canvas, canvas), (0, 0, 0, 0))
pixels = image.load()
for y in range(canvas):
    for x in range(canvas):
        blend = (x + y) / (2 * (canvas - 1))
        pixels[x, y] = (
            round(18 + (14 - 18) * blend),
            round(70 + (165 - 70) * blend),
            round(129 + (233 - 129) * blend),
            255,
        )

mask = Image.new("L", (canvas, canvas), 0)
ImageDraw.Draw(mask).rounded_rectangle((8, 8, 504, 504), radius=112, fill=255)
image.putalpha(mask)
draw = ImageDraw.Draw(image)

# White audit sheet with a folded corner.
draw.rounded_rectangle((116, 72, 388, 424), radius=38, fill=(255, 255, 255, 255))
draw.polygon([(312, 72), (388, 148), (312, 148)], fill=(198, 234, 255, 255))

# Three compact checklist rows, designed to survive the 16 px toolbar size.
for y in (184, 254, 324):
    draw.rounded_rectangle((154, y, 198, y + 44), radius=10, outline=(14, 165, 233, 255), width=14)
    draw.rounded_rectangle((224, y + 11, 344, y + 31), radius=10, fill=(31, 73, 125, 255))

# Prominent confirmation check.
draw.line([(158, 338), (180, 360), (222, 306)], fill=(16, 185, 129, 255), width=22, joint="curve")

resampling = Image.Resampling.LANCZOS
for size in (16, 32, 48, 128):
    output = image.resize((size, size), resampling)
    output.save(ICON_DIR / f"icon-{size}.png", optimize=True)

