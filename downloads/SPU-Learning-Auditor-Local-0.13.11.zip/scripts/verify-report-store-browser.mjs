import assert from "node:assert/strict";
import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import {createRequire} from "node:module";
import {fileURLToPath} from "node:url";

const modules = process.env.CODEX_NODE_MODULES;
if (!modules) throw new Error("CODEX_NODE_MODULES is required");
const require = createRequire(import.meta.url);
const {chromium} = require(path.join(modules, "playwright"));
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const server = http.createServer((request,response)=>{
  if(request.url==="/"){response.writeHead(200,{"Content-Type":"text/html"});response.end("<!doctype html><title>Report store verification</title>");return;}
  const target=path.resolve(root,"."+decodeURIComponent(request.url.split("?")[0]));
  if(!target.startsWith(root+path.sep)||!fs.existsSync(target)){response.writeHead(404);response.end();return;}
  response.writeHead(200,{"Content-Type":target.endsWith(".js")?"text/javascript":"text/plain"});
  fs.createReadStream(target).pipe(response);
});
await new Promise(resolve=>server.listen(0,"127.0.0.1",resolve));
const port=server.address().port;
const browser=await chromium.launch({executablePath:"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",headless:true});
try{
  const page=await browser.newPage();
  await page.addInitScript(()=>{
    const values={};window.__storage=values;
    const select=(keys)=>{if(keys==null)return structuredClone(values);const list=Array.isArray(keys)?keys:[keys];return Object.fromEntries(list.filter(key=>key in values).map(key=>[key,structuredClone(values[key])]));};
    window.chrome={storage:{local:{get:async keys=>select(keys),set:async update=>Object.assign(values,structuredClone(update)),remove:async keys=>{for(const key of Array.isArray(keys)?keys:[keys])delete values[key];}}}};
  });
  await page.goto(`http://127.0.0.1:${port}/`);
  const result=await page.evaluate(async()=>{
    const legacy={id:"legacy-report",courseTitle:"Legacy Course",courseUrl:"https://dlearning.spu.ac.th/course/view.php?id=1",courseType:"GS",credits:3,createdAt:new Date().toISOString(),activities:[],weeks:[]};
    await chrome.storage.local.set({latestReport:legacy,recentReports:[legacy]});
    const store=await import("/report-store.js");
    const migrated=await store.loadStoredReport("legacy-report");
    for(let number=2;number<=20;number++)await store.saveStoredReport({id:`report-${number}`,courseTitle:`Course ${number}`,courseUrl:`https://dlearning.spu.ac.th/course/view.php?id=${number}`,courseType:"GS",credits:3,createdAt:new Date(Date.now()+number).toISOString(),activities:Array.from({length:300},(_,index)=>({kind:"video",title:`Video ${index}`,href:`https://example.test/${number}/${index}`})),weeks:[]});
    const twentieth=await store.loadStoredReport("report-20");
    let overflow="";try{await store.assertCanCreateReport();}catch(error){overflow=error.message;}
    const local=await chrome.storage.local.get(["reportIndex","latestReport","recentReports","latestReportId"]);
    return {migratedId:migrated.id,activityCount:twentieth.activities.length,indexCount:local.reportIndex.length,latestReportId:local.latestReportId,legacyCopies:Boolean(local.latestReport||local.recentReports),overflow};
  });
  assert.equal(result.migratedId,"legacy-report");
  assert.equal(result.activityCount,300);
  assert.equal(result.indexCount,20);
  assert.equal(result.latestReportId,"report-20");
  assert.equal(result.legacyCopies,false);
  assert.match(result.overflow,/ครบ 20 รายการ/);
  console.log("browser report-store verification passed: migration, 20 full reports, no duplicate legacy bodies and preflight capacity");
}finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
