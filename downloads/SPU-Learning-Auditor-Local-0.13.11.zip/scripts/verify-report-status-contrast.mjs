import assert from "node:assert/strict";
import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import {createRequire} from "node:module";
import {fileURLToPath} from "node:url";
const modules=process.env.CODEX_NODE_MODULES;if(!modules)throw new Error("CODEX_NODE_MODULES is required");
const require=createRequire(import.meta.url),{chromium}=require(path.join(modules,"playwright"));
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const server=http.createServer((request,response)=>{const target=path.resolve(root,"."+decodeURIComponent(request.url.split("?")[0]));if(!target.startsWith(root+path.sep)||!fs.existsSync(target)){response.writeHead(404);response.end();return;}const type=target.endsWith(".js")?"text/javascript":target.endsWith(".css")?"text/css":"text/html";response.writeHead(200,{"Content-Type":type});fs.createReadStream(target).pipe(response);});
await new Promise(resolve=>server.listen(0,"127.0.0.1",resolve));
const browser=await chromium.launch({executablePath:"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",headless:true});
try{
  const page=await browser.newPage({viewport:{width:1280,height:900},colorScheme:"dark"});
  await page.goto(`http://127.0.0.1:${server.address().port}/tests/report-runtime-fixture.html?type=GS`);
  await page.waitForSelector(".status-badge.fail");
  const result=await page.evaluate(()=>{
    const rgb=value=>(value.match(/[\d.]+/g)||[]).slice(0,3).map(Number);
    const luminance=value=>{const channels=rgb(value).map(part=>{const v=part/255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;});return .2126*channels[0]+.7152*channels[1]+.0722*channels[2];};
    const contrast=element=>{const style=getComputedStyle(element),a=luminance(style.color),b=luminance(style.backgroundColor);return (Math.max(a,b)+.05)/(Math.min(a,b)+.05);};
    const badges=[...document.querySelectorAll(".status-badge.pass,.status-badge.fail,.score-status-badge")];
    return {theme:document.documentElement.dataset.theme,count:badges.length,ratios:badges.map(contrast),labels:badges.map(item=>item.textContent.trim())};
  });
  assert.equal(result.theme,"dark");assert.ok(result.count>=3);for(const ratio of result.ratios)assert.ok(ratio>=4.5,`status contrast ${ratio.toFixed(2)} is below 4.5:1`);
  assert.ok(result.labels.some(label=>label.includes("ผ่าน")));assert.ok(result.labels.some(label=>label.includes("ไม่ผ่าน")));
  if(process.env.STATUS_SCREENSHOT){await page.evaluate(()=>{for(const element of document.querySelectorAll("[data-panel]"))element.hidden=false;scrollTo(0,document.querySelector(".score-card")?.offsetTop||0);});await page.screenshot({path:process.env.STATUS_SCREENSHOT});await page.evaluate(()=>scrollTo(0,[...document.querySelectorAll(".week-card")].find(card=>card.querySelector(".status-badge"))?.offsetTop||0));await page.screenshot({path:process.env.STATUS_SCREENSHOT.replace(/\.png$/,"-weekly.png")});}
  console.log(`dark report status verification passed: ${result.count} badges, minimum contrast ${Math.min(...result.ratios).toFixed(2)}:1`);
}finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
