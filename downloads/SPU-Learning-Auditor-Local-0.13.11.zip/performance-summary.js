const number = (value) => Number.isFinite(Number(value)) ? Number(value) : 0;

export function summarizeInspectionTiming(activities = []) {
  const list = Array.from(activities || []);
  const total = (field) => list.reduce((sum, item) => sum + Math.max(0, number(item?.[field])), 0);
  const slowestActivities = [...list]
    .filter((item) => number(item?.readElapsedMs) > 0)
    .sort((left, right) => number(right?.readElapsedMs) - number(left?.readElapsedMs))
    .slice(0, 5)
    .map((item) => ({
      title:item.title || item.kind || "ไม่ระบุรายการ",
      section:item.auditSession || item.section || "",
      kind:item.kind || "",
      elapsedMs:number(item.readElapsedMs),
      mediaStatus:item.mediaStatus || "",
      source:item.source || ""
    }));
  return {
    externalResolveWorkMs:total("externalResolveMs"),
    fileInspectionWorkMs:total("fileInspectionMs"),
    mediaInspectionWorkMs:total("mediaInspectionMs"),
    forumInspectionWorkMs:total("forumInspectionMs"),
    slowestActivities
  };
}

export function inspectionGoalStatus(timing = {}, score = {}) {
  const measuredTotalMs = Math.max(0, number(timing.queueElapsedMs ?? timing.totalElapsedMs));
  const targetTotalMs = Math.max(1, number(timing.targetTotalMs) || 28 * 60 * 1000);
  const scoreConfirmed = !score.provisional;
  const withinTarget = measuredTotalMs > 0 && measuredTotalMs <= targetTotalMs;
  const key = scoreConfirmed && withinTarget
    ? "confirmed_within_target"
    : scoreConfirmed
      ? "confirmed_over_target"
      : withinTarget
        ? "provisional_within_target"
        : "provisional_over_target";
  const labels = {
    confirmed_within_target:"ยืนยันคะแนนได้ภายในเป้าหมาย",
    confirmed_over_target:"ยืนยันคะแนนได้ แต่ใช้เวลาเกินเป้าหมาย",
    provisional_within_target:"เสร็จภายในเป้าหมาย แต่ยังยืนยันคะแนนไม่ได้",
    provisional_over_target:"ยังไม่ถึงเป้าหมายเวลาและการยืนยันคะแนน"
  };
  return {
    key,
    label:labels[key],
    className:key === "confirmed_within_target" ? "pass" : key === "provisional_over_target" ? "fail" : "needs_review",
    measuredTotalMs,
    targetTotalMs,
    scoreConfirmed,
    withinTarget
  };
}
