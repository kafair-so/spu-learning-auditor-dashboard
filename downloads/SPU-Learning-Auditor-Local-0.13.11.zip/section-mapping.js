function sectionNumber(section) {
  const text = String(section || "");
  const match = text.match(/\bsection\s*([0-9０-９OＯ]+)\b/i)
    || text.match(/第\s*([0-9０-９〇零一二三四五六七八九十百]+)\s*(?:回|週|周|講)/i);
  return match ? number(match[1]) : null;
}

function normal(value) {
  return String(value || "").normalize("NFC").replace(/คร(?:้ั|ั้)ง/g, "ครั้ง").replace(/\s+/g, " ").trim();
}

function headingSignature(value) {
  return normal(value).toLowerCase().replace(/[‐‑‒–—−-]+/g, "-").replace(/\s*-\s*/g, "-");
}

function number(value) {
  const normalized = String(value)
    .replace(/[OＯ]/gi, "0")
    .replace(/[０-９]/g, (digit) => String(digit.charCodeAt(0) - 0xFF10));
  if (/^\d+$/.test(normalized)) return Number(normalized);
  const digits = {〇:0,零:0,一:1,二:2,三:3,四:4,五:5,六:6,七:7,八:8,九:9};
  if (/^[〇零一二三四五六七八九]+$/.test(normalized)) return Number([...normalized].map((digit) => digits[digit]).join(""));
  const hundred = normalized.match(/^([一二三四五六七八九])?百(?:([一二三四五六七八九])?十)?([一二三四五六七八九])?$/);
  if (hundred) return (digits[hundred[1]] || 1) * 100 + (hundred[2] ? digits[hundred[2]] * 10 : /十/.test(normalized) ? 10 : 0) + (digits[hundred[3]] || 0);
  const ten = normalized.match(/^([一二三四五六七八九])?十([一二三四五六七八九])?$/);
  if (ten) return (digits[ten[1]] || 1) * 10 + (digits[ten[2]] || 0);
  return Number.NaN;
}

// Lesson/Unit/EP/Chapter describe content, not a checklist session. Only an
// explicit teaching-meeting marker is allowed to select a session number.
function declaredSession(value) {
  const text = normal(value);
  const match = text.match(/(?:ครั้ง(?:ที่)?|(?:ประจำ)?สัปดาห์(?:ที่)?|week|session)\s*(?:no\.?|#)?\s*([0-9０-９OＯ〇零一二三四五六七八九十百]+)/i)
    || text.match(/第\s*([0-9０-９OＯ〇零一二三四五六七八九十百]+)\s*(?:回|週|周|講)/i);
  return match ? number(match[1]) : null;
}

function headingSession(value) {
  const text = normal(value);
  if (/^(?:ครั้ง(?:ที่)?|(?:ประจำ)?สัปดาห์(?:ที่)?|week|session|第)(?=\s*(?:no\.?|#)?\s*[0-9０-９OＯ〇零一二三四五六七八九十百])/i.test(text)) return declaredSession(text);
  if (/(?:การบรรยาย|การสอน|เรียน|หัวข้อการสอน).{0,24}(?:ครั้ง(?:ที่)?|(?:ประจำ)?สัปดาห์(?:ที่)?)\s*[0-9０-９OＯ]+/i.test(text)) return declaredSession(text);
  const afterSection = text.replace(/^section\s*\d+\s*/i, "");
  // A session marker near the start names the container; one buried after a
  // topic such as "การเขียน figure ครั้งที่ 1" names the learning content.
  const markerAt = afterSection.search(/(?:ครั้ง(?:ที่)?|(?:ประจำ)?สัปดาห์(?:ที่)?|week|session)\s*(?:no\.?|#)?\s*[0-9０-９OＯ〇零一二三四五六七八九十百]+|第\s*[0-9０-９OＯ〇零一二三四五六七八九十百]+\s*(?:回|週|周|講)/i);
  return markerAt >= 0 && markerAt <= 8 ? declaredSession(afterSection.slice(markerAt)) : null;
}

// Some courses label the physical Moodle container and the academic topic in
// the same heading, for example "ครั้งที่ 16 หัวข้อที่ 15".  The first number
// is then the box ordinal while the topic number is the 15-session curriculum
// ordinal. Keep this deliberately narrow: a bare Lesson/Unit/Chapter number is
// still content, not session evidence.
function headingTopic(value) {
  const match = normal(value).match(/(?:หัวข้อ)(?:ที่)?\s*(?:no\.?|#)?\s*([0-9０-９OＯ]+)/i);
  return match ? number(match[1]) : null;
}

function chapterNumber(value) {
  const match = normal(value).match(/(?:^|\b)chapter\s*(?:no\.?|#)?\s*([0-9０-９OＯ]+)(?=$|[\s:._/()\-–—])/i);
  return match ? number(match[1]) : null;
}

function chapterItemNumber(group) {
  // Use activity names only. A long description can mention several chapters
  // and is not a reliable boundary. Every detected Chapter number in one
  // Section must agree before it may relabel the Section.
  const chapters = group.map((item) => chapterNumber(item.title)).filter((value) => Number.isInteger(value));
  const distinct = new Set(chapters);
  return distinct.size === 1 ? chapters[0] : null;
}

function firstSessionHeading(value) {
  return /^(?:general|(?:ส่วน)?แนะนำ(?:การเรียน)?(?:รายวิชา|บทเรียน)|course\s*(?:introduction|overview)|课程(?:介绍|简介|概述)|課程(?:介紹|簡介|概述)|コース(?:紹介|概要)|授業概要)(?=\s|$|และ|\/|[-–—:])/i.test(normal(value));
}

function firstSessionSignal(item) {
  const text = normal([item.section, item.title, item.groupContext, item.text].join(" "));
  return /ข้อมูล.*รายวิชา|แนะนำรายวิชา|course\s*(?:information|introduction)|ผู้สอน|อาจารย์|ai\s*tutor|podcast|วิดีโอแนะนำ|เอกสารประกอบ|课程(?:信息|介绍)|課程(?:資訊|介紹)|授课教师|授課教師|コース(?:情報|紹介)|担当教員|講義資料/i.test(text);
}

function introductionBundle(group) {
  const text = normal(group.map((item) => [item.title, item.groupContext, item.text].join(" ")).join(" "));
  const courseIntroduction = /แนะนำ(?:การเรียน)?รายวิชา|แนะนำภาพรวมวิชา|ภาพรวมรายวิชา|course\s*(?:information|introduction|overview)|课程(?:信息|介绍|简介|概述)|課程(?:資訊|介紹|簡介|概述)|コース(?:情報|紹介|概要)|授業概要/i.test(text);
  if (!courseIntroduction) return false;
  const supporting = [
    /แผนการสอน|มคอ\s*3|course\s*(?:plan|syllabus)|教学计划|教學計畫|课程大纲|課程大綱|授業計画|シラバス/i,
    /ai\s*tutor/i,
    /แบบทดสอบก่อนเรียน|pre[-\s]?test|课前测验|課前測驗|事前テスト|プレテスト/i,
    /การประเมินผล|assessment|考核|評価/i,
    /ผู้สอน|อาจารย์|ช่องทางติดต่อ|授课教师|授課教師|担当教員|連絡先/i
  ].filter((pattern) => pattern.test(text)).length;
  return supporting >= 2;
}

export function sectionKey(item) {
  return item.sectionId ? `id:${item.sectionId}` : Number.isInteger(item.sectionIndex) && item.sectionIndex >= 0 ? `index:${item.sectionIndex}` : String(item.section || "").trim();
}

function uniqueSections(items) {
  const groups = new Map();
  for (const item of items) {
    const source = sectionKey(item);
    if (!source) continue;
    if (!groups.has(source)) groups.set(source, []);
    groups.get(source).push(item);
  }
  return groups;
}

function winningVote(votes) {
  if (!votes.length) return null;
  const counts = votes.reduce((all, vote) => ((all[vote] = (all[vote] || 0) + 1), all), {});
  return Number(Object.entries(counts).sort(([leftWeek, leftCount], [rightWeek, rightCount]) => Number(rightCount) - Number(leftCount) || Number(leftWeek) - Number(rightWeek))[0][0]);
}

function sectionItemVote(group) {
  const votes = group.map((item) => declaredSession(item.title)).filter(Boolean);
  // A phrase such as "การเขียน figure ครั้งที่ 1" can be a subtopic. Require
  // corroboration from a second item before letting activity titles relabel an
  // entire Moodle Section.
  return votes.length >= 2 ? winningVote(votes) : null;
}

// A topic-only box may continue the explicitly numbered box immediately above
// it. Accept a single item-level session marker only when it belongs to a
// teaching-plan title; this is strong boundary evidence, unlike an incidental
// phrase such as "ตัวอย่างครั้งที่ 1" inside ordinary lesson content.
function teachingPlanSession(group) {
  const votes = group.map((item) => {
    const text = normal([item.title, item.groupContext].join(" "));
    if (!/(?:แผน(?:การ)?(?:เรียน)?การสอน|แผนการจัดการเรียนรู้|teaching\s*plan|lesson\s*plan|weekly\s*plan|教学计划|教學計畫|课程大纲|課程大綱|授業計画|シラバス)/i.test(text)) return null;
    return declaredSession(text);
  }).filter(Boolean);
  return winningVote(votes);
}

// Checklist sessions are capped at 15; Moodle containers are not. The returned
// topology preserves both the chosen mapping and the reasons it is trustworthy.
export function sectionTopology(items, expectedSessions = 15, sectionBoxes = []) {
  const groups = uniqueSections(items);
  for (const box of sectionBoxes) if (!groups.has(sectionKey(box))) groups.set(sectionKey(box),[{...box,kind:"section_boundary",title:""}]);
  const mapping = new Map();
  const diagnostics = [];
  const outOfRange = new Set();
  const ignored = new Set();
  const finalize = (mode, confidence, orderedEntries = [...groups.entries()]) => {
    const rows = orderedEntries.map(([key, group]) => {
      const section = group[0]?.section || key;
      const chosenSession = mapping.get(key) || null;
      const declared = headingSession(section);
      const chapter = chapterItemNumber(group);
      const diagnostic = [...diagnostics].reverse().find((entry) => entry.section === section);
      let reason = diagnostic?.reason || "";
      if (ignored.has(key)) reason ||= "กล่องข้อมูลก่อนเริ่มเรียน — ไม่นับเป็นครั้งเรียน";
      else if (outOfRange.has(key)) reason ||= `อยู่นอกกรอบ ${expectedSessions} ครั้ง`;
      else if (chosenSession && declared === chosenSession) reason ||= "ใช้เลขครั้ง/สัปดาห์จากหัวข้อ Section";
      else if (chosenSession === 1 && firstSessionHeading(section)) reason ||= "ข้อมูลแนะนำรายวิชา — รวมกับครั้งที่ 1";
      else if (chosenSession && chapter === chosenSession) reason ||= `ใช้ Chapter ${chapter} เป็นครั้งเรียน`;
      else if (chosenSession) reason ||= `ใช้ลำดับกล่องเป็นครั้งที่ ${chosenSession}`;
      else reason ||= "ยังไม่มีหลักฐานพอจะระบุครั้งเรียน";
      return {key,section,chosenSession,declaredSession:declared,chapter,ignored:ignored.has(key),outOfRange:outOfRange.has(key),reason};
    });
    const safetyIssues = [];
    const mappedRows = rows.filter((row) => row.chosenSession);
    for (let index = 1; index < mappedRows.length; index += 1) {
      if (mappedRows[index].chosenSession < mappedRows[index - 1].chosenSession) {
        safetyIssues.push(`ลำดับครั้งเรียนย้อนกลับที่ ${mappedRows[index].section}`);
      }
    }
    for (const row of rows) {
      const approvedDifference = /Chapter|หัวข้อ|รวมกล่อง|กล่องนำ|แนะนำรายวิชา/i.test(row.reason);
      if (row.declaredSession >= 1 && row.declaredSession <= expectedSessions
        && row.chosenSession && row.declaredSession !== row.chosenSession && !approvedDifference) {
        safetyIssues.push(`${row.section}: หัวข้อระบุครั้งที่ ${row.declaredSession} แต่ระบบจับเป็นครั้งที่ ${row.chosenSession}`);
      }
    }
    const scoringKeys = new Set(items.filter((item) => item.kind !== "forum" && item.kind !== "section_boundary").map(sectionKey));
    for (const row of rows) {
      if (scoringKeys.has(row.key) && !row.chosenSession && !row.outOfRange && !row.ignored) safetyIssues.push(`${row.section}: ยังจับคู่ครั้งเรียนไม่ได้`);
    }
    if (confidence === "low") safetyIssues.push("หลักฐานโครงสร้างรายวิชายังมีความเชื่อมั่นต่ำ");
    return {mapping,outOfRangeSections:[...outOfRange],mode,confidence,diagnostics,expectedSessions,mappedSectionCount:mapping.size,sectionCount:groups.size,mappingRows:rows,safetyIssues:[...new Set(safetyIssues)],reviewRequired:safetyIssues.length > 0};
  };
  // Physical container order is authoritative, including mixed/misnumbered
  // headings. Legacy scans retain first-seen box order when DOM IDs are absent.
  if (groups.size >= 1 && (sectionBoxes.length || items.some((item) => item.sectionId || Number.isInteger(item.sectionIndex) && item.sectionIndex >= 0))) {
    const entries = [...groups.entries()].sort((a, b) => {
      const left = a[1][0].sectionIndex, right = b[1][0].sectionIndex;
      return Number.isInteger(left) && left >= 0 && Number.isInteger(right) && right >= 0 ? left - right : 0;
    });
    const announcementOnlyGroup = (group) => group.every((item) => item.kind === "forum" || item.kind === "url")
      && group.every((item) => /ประกาศ|announcement|ช่องทางติดต่อ|ผู้สอน|อาจารย์|公告|通知|お知らせ|連絡|授课教师|授課教師|担当教員/i.test([item.title,item.text].join(" ")));
    const lectureHeadingNumber = (value) => {
      const match = normal(value).match(/^lecture\s*(?:no\.?|#)?\s*([0-9０-９OＯ]+)\b/i);
      return match ? number(match[1]) : null;
    };
    // i-Learning commonly has exactly 15 visible academic boxes named
    // Course Introduction + Lecture 1..14. Themes may additionally expose an
    // empty wrapper as a SECTION boundary; that wrapper must not activate the
    // overflow merge intended for genuinely more-than-15 teaching boxes.
    const substantiveEntries = entries.filter(([, group]) => !announcementOnlyGroup(group)
      && !group.every((item) => item.kind === "section_boundary"));
    const exactIntroductionLectureLayout = substantiveEntries.length === expectedSessions
      && substantiveEntries.some(([, group]) => /^course\s*(?:introduction|overview)\b/i.test(normal(group[0].section || "")))
      && Array.from({length:expectedSessions - 1}, (_, index) => index + 1)
        .every((lecture) => substantiveEntries.some(([, group]) => lectureHeadingNumber(group[0].section || "") === lecture))
      && substantiveEntries.every(([, group]) => /^course\s*(?:introduction|overview)\b/i.test(normal(group[0].section || ""))
        || Number.isInteger(lectureHeadingNumber(group[0].section || "")));
    // Fifteen real teaching boxes already match the rubric exactly and must
    // remain fifteen distinct sessions. Merge an introductory box with a
    // following Week/Lecture 1 only when the physical layout would otherwise
    // exceed the 15-session frame.
    // Count only real teaching boxes. Empty theme wrappers are not Sections.
    // Exactly 15 boxes stay separate; only a genuine overflow merges the
    // first two boxes (course introduction + first meeting) into session 1.
    const physicalEntries = entries.filter(([, group]) => !announcementOnlyGroup(group));
    const mergeOverflowIntroduction = !exactIntroductionLectureLayout && physicalEntries.length > expectedSessions;
    const explicitOverflowHeadings = entries.map(([, group]) => headingSession(group[0].section || ""))
      .filter((value) => Number.isInteger(value) && value >= 1 && value <= expectedSessions);
    const declaredHeadingSet = new Set(explicitOverflowHeadings);
    // Two distinct headings in increasing order establish the author's own
    // session sequence even when the teacher intentionally omits a meeting
    // number (for example 2, 7 and 9). Requiring consecutive numbers shifted
    // sparse courses to the following physical box. A single isolated heading
    // is still insufficient because it can be a copied or mistyped title.
    const distinctDeclaredHeadings = explicitOverflowHeadings.filter((value, index, values) => index === 0 || value !== values[index - 1]);
    const hasDeclaredHeadingSequence = new Set(distinctDeclaredHeadings).size >= 2
      && distinctDeclaredHeadings.every((value, index) => index === 0 || value > distinctDeclaredHeadings[index - 1]);
    // When an overflow layout still labels almost the complete 1..15 sequence,
    // those headings are stronger than the physical box ordinal. This is the
    // common "course introduction + ครั้งที่ 1" layout: both belong to the
    // first checklist session and a physical box 16 labelled ครั้งที่ 15 must
    // remain session 15 instead of being discarded.
    const useDeclaredOverflowHeadings = mergeOverflowIntroduction
      && new Set(explicitOverflowHeadings).size >= Math.max(3, expectedSessions - 2)
      && explicitOverflowHeadings.includes(1)
      && explicitOverflowHeadings.includes(expectedSessions);
    const topicOffsetEvidence = entries.filter(([, group]) => {
      const heading = headingSession(group[0].section || "");
      const topic = headingTopic(group[0].section || "");
      return heading && topic && heading === topic + 1 && topic <= expectedSessions;
    }).length;
    const chapterOffsetEvidence = entries.filter(([, group]) => {
      const heading = headingSession(group[0].section || "");
      const chapter = chapterItemNumber(group);
      return heading && chapter && heading === chapter + 1 && chapter <= expectedSessions;
    }).length;
    let session = 0;
    let precedingIntroduction = false;
    let previousHeadingSignature = "";
    for (const [key, group] of entries) {
      const title = group[0].section || key;
      const titleSignature = headingSignature(title);
      const boundaryOnly = group.every((item) => item.kind === "section_boundary");
      const exactLecture = lectureHeadingNumber(title);
      const exactIntroduction = exactIntroductionLectureLayout && /^course\s*(?:introduction|overview)\b/i.test(normal(title));
      if (exactIntroductionLectureLayout && boundaryOnly && !exactIntroduction && !Number.isInteger(exactLecture)) {
        ignored.add(key);
        continue;
      }
      // Some Moodle themes expose the course-title wrapper twice: one real
      // container with activities and one empty adjacent wrapper whose dash
      // glyph may differ. It is not a teaching box and must not consume a
      // session. Limit this exception to the pre-session area; a genuinely
      // empty box between lessons must still reserve its physical position.
      const duplicateEmptyPrelude = session === 0 && boundaryOnly
        && previousHeadingSignature && titleSignature === previousHeadingSignature;
      if (duplicateEmptyPrelude) { ignored.add(key); continue; }
      const announcementOnly = announcementOnlyGroup(group);
      if (announcementOnly) { ignored.add(key); previousHeadingSignature = titleSignature; continue; }
      // A text-only rules/etiquette card before the course introduction is
      // administrative guidance, not one of the 15 academic Chapters. Keep an
      // empty teaching box elsewhere because it may intentionally reserve a
      // meeting; this exception is limited to a clearly named opening prelude.
      const rulesPrelude = session === 0 && boundaryOnly
        && /กฎ(?:กติกา)?|กติกา|ข้อปฏิบัติ|ระเบียบ|course\s*(?:rules|etiquette)|learning\s*(?:rules|etiquette)|class\s*(?:rules|etiquette)/i.test(normal(title));
      if (rulesPrelude) { ignored.add(key); previousHeadingSignature = titleSignature; continue; }
      // Only an introductory first box followed by an explicit meeting 1
      // shares session 1. Unnumbered lesson boxes still follow physical order.
      const zeroPrelude = /^(?:section-0|0)$/i.test(group[0].sectionId || "") || sectionNumber(title) === 0;
      const zeroHasFirstLesson = group.some((item) => declaredSession(item.title) === 1) || group.filter(firstSessionSignal).length >= 3;
      const heading = headingSession(title);
      // A labelled Week 0 is an introductory half of the first checklist
      // session. When Week 1 follows it, both boxes must share session 1 rather
      // than shifting every later week by one.
      const introduction = heading === 0 || firstSessionHeading(title) || introductionBundle(group);
      const mergeFirst = mergeOverflowIntroduction && session === 1 && precedingIntroduction
        && (heading === 1 || /^lecture\s*(?:no\.?|#)?\s*1\b/i.test(normal(title)));
      const planSession = teachingPlanSession(group);
      const topic = headingTopic(title);
      const chapter = chapterItemNumber(group);
      // In an overflow layout, repeated headings such as "ครั้งที่ 2 หัวข้อที่
      // 1" prove that the introductory box shifted every physical ordinal by
      // one. A final "ครั้งที่ 16 หัวข้อที่ 15" is also sufficient to rescue
      // the last curriculum topic from being discarded as a 16th lesson.
      const useTopicOffset = mergeOverflowIntroduction && heading === topic + 1
        && topic >= 1 && topic <= expectedSessions
        && (topicOffsetEvidence >= 2 || session >= expectedSessions);
      // Some courses have two opening cards (rules + course introduction),
      // then name the 15 teaching cards by their physical ordinals 2..16 while
      // the activities consistently say Chapter 1..15. Multiple matching
      // Sections establish that Chapter is the curriculum session; one stray
      // Chapter reference can never shift the course by itself.
      const useChapterOffset = mergeOverflowIntroduction && heading === chapter + 1
        && chapter >= 1 && chapter <= expectedSessions && chapterOffsetEvidence >= 2;
      // If an explicit "ครั้งที่ N" box is followed by a topic box whose own
      // teaching plan says Week N, both boxes are the same checklist session.
      // Do not consume the next number until a later physical box begins it.
      const continuesCurrentSession = session >= 1 && !heading && planSession === session;
      const useDeclaredOverflow = useDeclaredOverflowHeadings && heading >= 1 && heading <= expectedSessions;
      const useDeclaredHeading = hasDeclaredHeadingSequence && heading >= 1 && heading <= expectedSessions;
      let chosen;
      if (exactIntroductionLectureLayout && (exactIntroduction || Number.isInteger(exactLecture))) {
        chosen = exactIntroduction ? 1 : exactLecture + 1;
        session = Math.max(session, chosen);
      } else if (useDeclaredOverflow) {
        chosen = heading;
        session = Math.max(session, chosen);
      } else if (useTopicOffset) {
        chosen = topic;
        session = Math.max(session, chosen);
      } else if (useChapterOffset) {
        chosen = chapter;
        session = Math.max(session, chosen);
      } else if (useDeclaredHeading) {
        chosen = heading;
        session = Math.max(session, chosen);
      } else {
        chosen = mergeFirst || zeroPrelude && session === 0 && !zeroHasFirstLesson
          ? 1
          : continuesCurrentSession ? session : ++session;
      }
      precedingIntroduction = chosen === 1 && introduction && !mergeFirst;
      previousHeadingSignature = titleSignature;
      if (chosen <= expectedSessions) mapping.set(key, chosen);
      else { outOfRange.add(key); diagnostics.push({section:title,reason:`กล่องลำดับที่ ${chosen} เกิน ${expectedSessions} ครั้ง — แสดงหลักฐานแต่ไม่นับคะแนน`,excluded:true}); }
      if (useDeclaredOverflow) diagnostics.push({section:title,reason:`ใช้เลขครั้งที่ ${heading} จากหัวข้อ และรวมกล่องแนะนำรายวิชากับครั้งที่ 1`});
      else if (useTopicOffset) diagnostics.push({section:title,reason:`รวมตามเลขหัวข้อที่ ${topic} เพราะเลขครั้งของกล่องนำหัวข้อจริง 1 ลำดับ`});
      else if (useChapterOffset) diagnostics.push({section:title,reason:`ใช้ Chapter ${chapter} เป็นครั้งที่ ${chapter} เพราะเลขครั้งเป็นลำดับกล่องที่นำ Chapter อยู่ 1 ลำดับ`});
      else if (useDeclaredHeading) diagnostics.push({section:title,reason:`ใช้เลขครั้งที่ ${heading} จากหัวข้อ Section ที่ระบุชัด`});
      else if (heading && heading !== chosen) diagnostics.push({section:title,reason:`ใช้ลำดับกล่องจริงเป็นครั้งที่ ${chosen}`});
    }
    return finalize("ordered_section_boxes",items.some((item) => item.sectionId) ? "high" : "medium",entries);
  }
  const numbered = [...groups.entries()]
    .map(([source, group]) => ({ source, group, number:sectionNumber(source) }))
    .filter((entry) => Number.isInteger(entry.number));

  // A heading that explicitly says "สัปดาห์ที่ N", "ครั้งที่ N", Week N or
  // Session N is stronger evidence than Moodle's internal Section number.
  for (const source of groups.keys()) {
    const declared = headingSession(source);
    if (declared && declared >= 1 && declared <= expectedSessions) mapping.set(source, declared);
    else if (declared && declared > expectedSessions) {
      outOfRange.add(source);
      diagnostics.push({section:source, reason:`ครั้งที่ ${declared} เกินกรอบเกณฑ์ ${expectedSessions} ครั้ง — แสดงเป็นหลักฐานแต่ไม่นับคะแนน`,excluded:true});
    }
    else if (firstSessionHeading(source)) mapping.set(source, 1);
  }
  // A course-title card can be Moodle's Section 0 even when its heading never
  // says "Introduction". A bundled course overview plus at least two strong
  // first-session components is sufficient to merge that card into session 1.
  const bundledIntroduction = [...groups.entries()].find(([source, group]) => !headingSession(source) && introductionBundle(group));
  if (bundledIntroduction) mapping.set(bundledIntroduction[0], 1);

  for (const { source, group } of numbered) {
    const vote = sectionItemVote(group);
    const declared = headingSession(source) || vote;
    if (declared && declared >= 1 && declared <= expectedSessions) mapping.set(source, declared);
  }

  const zero = numbered.find((entry) => entry.number === 0);
  const positives = numbered.filter((entry) => entry.number >= 1).sort((left, right) => left.number - right.number);
  const positiveNumbers = [...new Set(positives.map((entry) => entry.number))];
  const startsAtOne = positiveNumbers[0] === 1;
  const hasExplicitSessionOne = [...groups.entries()].some(([source, group]) => headingSession(source) === 1 || sectionItemVote(group) === 1);
  const zeroSignals = zero ? zero.group.filter(firstSessionSignal).length : 0;
  const zeroExplicitFirst = Boolean(zero && (headingSession(zero.source) === 1 || zero.group.some((item) => declaredSession(item.title) === 1 || declaredSession(item.groupContext) === 1)));
  const zeroLooksLikeFirst = zeroExplicitFirst || zeroSignals >= 3;

  let mode = "unresolved";
  let confidence = "low";
  const explicitSessions = new Set([...groups.keys()].map(headingSession).filter((value) => value >= 1 && value <= expectedSessions));
  if (explicitSessions.size >= 3) {
    mode = "explicit_session_headings";
    confidence = explicitSessions.size === expectedSessions ? "high" : "medium";
  } else if (zero && startsAtOne && zeroLooksLikeFirst) {
    // Full first-session evidence is in Section 0: 0=>1, 1=>2 … 14=>15.
    mode = "zero_based_first_session";
    confidence = zeroExplicitFirst ? "high" : "medium";
    for (const entry of numbered) {
      const session = entry.number + 1;
      if (session >= 1 && session <= expectedSessions && !mapping.has(entry.source)) mapping.set(entry.source, session);
      if (session > expectedSessions && !mapping.has(entry.source)) { outOfRange.add(entry.source); diagnostics.push({section:entry.source, reason:"เกินจำนวนครั้งตามเกณฑ์ — ไม่นับเป็นครั้งที่ 16",excluded:true}); }
    }
  } else if (startsAtOne || (positiveNumbers[0] === 2 && hasExplicitSessionOne)) {
    // Ordinary Moodle layout: Section 0 is a prelude; Section 1 starts week 1.
    mode = zero ? "section_zero_intro" : "one_based_sessions";
    confidence = positiveNumbers.length >= 3 ? "medium" : "low";
    for (const entry of positives) {
      if (entry.number <= expectedSessions && !mapping.has(entry.source)) mapping.set(entry.source, entry.number);
      if (entry.number > expectedSessions && !mapping.has(entry.source)) { outOfRange.add(entry.source); diagnostics.push({section:entry.source, reason:"เกินจำนวนครั้งตามเกณฑ์ — แสดงหลักฐานแต่ไม่นับคะแนน",excluded:true}); }
    }
    if (zero && (zeroSignals || zeroExplicitFirst)) mapping.set(zero.source, 1);
  } else if (explicitSessions.size === 0 && numbered.length === 0 && groups.size >= 3) {
    // Some Moodle courses use visually separate section cards but name every
    // card only by its topic. DOM order is then the only stable week boundary.
    // Ignore a standalone Announcements/Forum card and map the remaining
    // section boxes from top to bottom, capped by the 15-session rubric.
    const orderedBoxes = [...groups.entries()].filter(([source, group]) => {
      const forumOnly = group.length > 0 && group.every((item) => item.kind === "forum");
      if (forumOnly && /ประกาศ|announcement|forum|公告|通知|お知らせ|フォーラム/i.test(source)) {
        ignored.add(source);
        return false;
      }
      return true;
    });
    if (orderedBoxes.length) {
      mapping.clear();
      mode = "ordered_section_boxes";
      confidence = orderedBoxes.length >= 3 ? "medium" : "low";
      orderedBoxes.forEach(([source], index) => {
        const session = index + 1;
        if (session <= expectedSessions) mapping.set(source, session);
        else {
          outOfRange.add(source);
          diagnostics.push({section:source, reason:`กล่อง Section ลำดับที่ ${session} เกินกรอบเกณฑ์ ${expectedSessions} ครั้ง — แสดงเป็นหลักฐานแต่ไม่นับคะแนน`,excluded:true});
        }
      });
    }
  }

  const unmapped = [...groups.keys()].filter((source) => !mapping.has(source) && !outOfRange.has(source) && !ignored.has(source));
  if (unmapped.length) diagnostics.push({section:unmapped.join(", "), reason:"ยังไม่มีหลักฐานพอจะระบุครั้งเรียน"});
  const directConflicts = numbered.filter(({source, group, number:sectionNo}) => {
    const vote = sectionItemVote(group);
    return vote && mapping.get(source) && vote !== mapping.get(source) && vote !== sectionNo;
  });
  for (const conflict of directConflicts) diagnostics.push({section:conflict.source, reason:"เลขครั้งเรียนในรายการขัดกับรูปแบบ Section — ต้องตรวจทาน"});
  if (directConflicts.length) confidence = "low";
  return finalize(mode,confidence);
}

export function sectionWeekMapping(items) {
  return sectionTopology(items).mapping;
}

export function canonicalWeek(item, mapping) {
  const mapped = mapping.get(sectionKey(item));
  if (mapped) return mapped;
  if (mapping.size >= 3 || item.sectionId) return null;
  const section = normal(item.section);
  if (/แนะนำ(?:รายวิชา|บทเรียน)|^general$|课程(?:介绍|简介)|課程(?:介紹|簡介)|コース(?:紹介|概要)|授業概要/i.test(section)) return 1;
  return headingSession(section);
}

export function groupedByWeek(items, mapping) {
  return items.reduce((all, item) => {
    const week = canonicalWeek(item, mapping);
    if (!week) return all;
    const key = `ครั้งที่ ${week}`;
    (all[key] ||= []).push(item);
    return all;
  }, {});
}

export function weekOrder(section) {
  return declaredSession(section) ?? Number.MAX_SAFE_INTEGER;
}
