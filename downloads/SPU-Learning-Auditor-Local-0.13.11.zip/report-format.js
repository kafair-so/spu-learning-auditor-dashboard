import { learningPlatformName, isLmsHost } from "./platform.js";

export function providerLabel(value) {
  try {
    const host=new URL(String(value)).hostname.replace(/^www\./,"").toLowerCase();
    if(host==="drive.google.com")return "Google Drive";
    if(host==="docs.google.com")return "Google Docs";
    if(host.endsWith("notebooklm.google.com")||host==="notebook.google.com")return "NotebookLM";
    if(host.endsWith("youtube.com")||host==="youtu.be")return "YouTube";
    if(isLmsHost(host))return learningPlatformName(host);
    return host;
  } catch { return "ลิงก์ภายนอก"; }
}
export function friendlyEvidenceTitle(value) {
  const title=String(value||"").trim();
  if(/^https?:\/\//i.test(title))return {label:`ลิงก์ ${providerLabel(title)}`,rawUrl:title};
  return {label:title||"ไม่ระบุชื่อรายการ",rawUrl:""};
}
export function friendlyGroup(value) {
  return String(value||"").trim().replace(/\.(?:png|jpe?g|webp)$/i,"");
}
export function noteExcerpt(value,max=86) {
  const note=String(value||"").trim();
  const first=note.split(/\s*[·]\s*|\s+หลักฐานการจัดประเภท\s*:/)[0].trim();
  return first.length>max?first.slice(0,max-1).trimEnd()+"…":first;
}
