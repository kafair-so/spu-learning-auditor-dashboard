import { initI18n, addLanguageMenu } from "./i18n.js";
await initI18n();
await addLanguageMenu();
