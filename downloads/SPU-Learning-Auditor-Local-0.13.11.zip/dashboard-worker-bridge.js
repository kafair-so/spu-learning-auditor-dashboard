(() => {
  const SOURCE_PAGE = "spu-auditor-dashboard";
  const SOURCE_EXTENSION = "spu-auditor-extension";
  const allowed = new Set([
    "https://kafair-so.github.io",
    "http://127.0.0.1:8765",
    "http://localhost:8765"
  ]);
  if (!allowed.has(location.origin)) return;

  window.addEventListener("message", async (event) => {
    const data = event.data || {};
    if (event.source !== window || event.origin !== location.origin || data.source !== SOURCE_PAGE || !data.requestId) return;
    const supported = new Set([
      "CENTRAL_WORKER_PING",
      "CENTRAL_WORKER_ENABLE",
      "CENTRAL_WORKER_START",
      "CENTRAL_WORKER_STATUS",
      "CENTRAL_WORKER_ACK"
    ]);
    if (!supported.has(data.type)) return;
    try {
      const response = await chrome.runtime.sendMessage({type:data.type,payload:data.payload || {}});
      window.postMessage({source:SOURCE_EXTENSION,requestId:data.requestId,response}, location.origin);
    } catch (error) {
      window.postMessage({source:SOURCE_EXTENSION,requestId:data.requestId,response:{ok:false,error:error?.message || String(error)}}, location.origin);
    }
  });

  window.postMessage({source:SOURCE_EXTENSION,type:"CENTRAL_WORKER_READY"}, location.origin);
})();
