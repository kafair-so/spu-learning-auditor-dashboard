(() => {
  // OCR is deliberately local to the browser.  It is used only for a small,
  // clearly-labelled set of assignment instruction images; no course image or
  // text is sent to another service.
  const asset = (path) => chrome.runtime.getURL(path);
  const timeout = (promise, milliseconds) => Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error("OCR_TIMEOUT")), milliseconds))
  ]);
  const cache = new Map();
  let workerPromise;

  const worker = async () => {
    if (!globalThis.Tesseract) throw new Error("OCR_ENGINE_UNAVAILABLE");
    workerPromise ||= globalThis.Tesseract.createWorker("tha+eng+jpn+chi_sim+chi_tra", 1, {
      workerPath: asset("vendor/worker.min.js"),
      corePath: asset("vendor"),
      langPath: asset("vendor/lang"),
      workerBlobURL: false,
      gzip: false,
      cacheMethod: "none",
      logger: () => {}
    });
    return workerPromise;
  };

  globalThis.dlearningOcr = {
    async readAssignmentImage(image) {
      const key = image.currentSrc || image.src;
      if (!key) return { status:"unavailable", reason:"ไม่พบที่อยู่ของภาพ" };
      if (cache.has(key)) return cache.get(key);
      const task = (async () => {
        try {
          await image.decode?.().catch(() => {});
          const ocrWorker = await timeout(worker(), 12000);
          const result = await timeout(ocrWorker.recognize(image, {}, { text:true }), 18000);
          const text = String(result?.data?.text || "").replace(/\s+/g, " ").trim();
          const confidence = Math.round(Number(result?.data?.confidence || 0));
          return text ? { status:"read", text:text.slice(0, 1800), confidence } : { status:"unclear", reason:"อ่านข้อความจากภาพไม่ได้" };
        } catch (error) {
          const code = String(error?.message || error);
          return { status:code.includes("TIMEOUT") ? "timeout" : "unavailable", reason:code.includes("TIMEOUT") ? "อ่านภาพเกินเวลาที่กำหนด" : "ระบบอ่านข้อความจากภาพยังไม่พร้อม" };
        }
      })();
      cache.set(key, task);
      return task;
    }
  };
})();
