export function podcastReviewKey(item) {
  return String(item?.href || item?.externalUrl || "");
}

export function parsePodcastDuration(value) {
  const text = String(value || "").trim();
  if (!text) return null;
  const parts = text.split(":").map((part) => Number(part));
  if (parts.some((part) => !Number.isInteger(part) || part < 0)) return null;
  if (parts.length === 2 && parts[1] < 60) return parts[0] * 60 + parts[1];
  if (parts.length === 3 && parts[1] < 60 && parts[2] < 60) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  return null;
}

export function podcastDurationInput(seconds) {
  const value = Math.max(0, Math.round(Number(seconds || 0)));
  if (!value) return "";
  const hours = Math.floor(value / 3600);
  const minutes = Math.floor((value % 3600) / 60);
  const remainder = value % 60;
  return hours ? `${hours}:${String(minutes).padStart(2, "0")}:${String(remainder).padStart(2, "0")}` : `${minutes}:${String(remainder).padStart(2, "0")}`;
}

export function applyPodcastReviews(items, courseReviews = {}) {
  for (const item of items || []) {
    if (item.kind !== "podcast") continue;
    // Podcast playback time is a reviewer decision. Discard legacy automatic
    // durations so old reports follow the same policy after an extension
    // upgrade and cannot silently pass without confirmation.
    item.automaticDurationIgnored = Boolean(item.automaticDurationSeconds || item.durationSeconds);
    item.automaticDurationSeconds = null;
    item.automaticDurationSource = null;
    item.durationSeconds = null;
    item.reviewerDurationSeconds = null;
    item.reviewerDurationConfirmed = false;
    item.podcastTypeNote ||= item.accessNote || "";
    item.accessNote = item.podcastTypeNote;
    // Moodle-hosted Podcast files are compliance evidence only. Ignore any
    // stale draft saved by an older extension version and never restore time.
    if (item.podcastDelivery === "internal_upload") continue;
    const review = courseReviews[podcastReviewKey(item)];
    const seconds = Number(review?.seconds || 0);
    // Keep a reviewer's draft even while provider type detection is pending.
    // It must not become scoring evidence until the target is verified audio
    // and the reviewer explicitly checks the confirmation box.
    if (Number.isFinite(seconds) && seconds > 0) item.reviewerDurationSeconds = Math.round(seconds);
    if (item.mediaType !== "audio") continue;
    if (!review?.confirmed || !Number.isFinite(seconds) || seconds <= 0) continue;
    item.durationSeconds = Math.round(seconds);
    item.reviewerDurationSeconds = Math.round(seconds);
    item.reviewerDurationConfirmed = true;
    item.reviewerConfirmedAt = review.confirmedAt || null;
    item.source = "reviewer-confirmed-podcast-time";
    item.mediaStatus = "podcast_time_confirmed";
    item.accessNote = "ผู้ตรวจยืนยันว่าเวลาที่กรอกถูกต้อง";
  }
  return items;
}
