const FIRST = ["ข้อมูลและแนะนำรายวิชา", "ข้อมูลผู้สอนและการติดต่อ", "File PDF เอกสารประกอบการสอน", "วิดีโอแนะนำ/บันทึกการสอน", "คลิปเสียง Podcast", "กิจกรรมท้ายบท", "ระบบให้คำปรึกษา AI Tutor"];
const WEEKLY = ["File PDF แผนการสอน", "File PDF เอกสารประกอบ", "วิดีโอบันทึกการสอนล่วงหน้า", "คลิปเสียง Podcast", "แบบทดสอบก่อนเรียน", "แบบทดสอบหลังเรียน", "กิจกรรมท้ายบท (ถ้ามี)"];
const GN_FIRST = ["ข้อมูลแนะนำรายวิชาและผู้สอน", "File PDF เอกสารประกอบการสอน", "วิดีโอแนะนำ/บันทึกการสอน", "คลิปเสียง Podcast", "ระบบให้คำปรึกษา AI Tutor"];
const GN_WEEKLY = ["File PDF แผนการจัดการเรียนการสอน", "File PDF เอกสารประกอบการสอน", "วิดีโอบันทึกการสอนล่วงหน้า", "คลิปเสียง Podcast"];

const uniq = (values) => [...new Set(values.filter(Boolean))];
const sessionList = (sessions) => {
  const values = uniq(sessions);
  const numbers = [...new Set(values.map((value) => Number(String(value).match(/\d+/)?.[0])).filter(Number.isFinite))].sort((a,b)=>a-b);
  const ranges = [];
  for (const value of numbers) {
    const last = ranges.at(-1);
    if (last && value === last[1] + 1) last[1] = value;
    else ranges.push([value,value]);
  }
  const numbered = ranges.map(([start,end]) => start === end ? String(start) : `${start}–${end}`);
  const intro = values.some((value) => !/\d/.test(String(value)) || /แนะนำ|general|introduction|overview/i.test(String(value)));
  return [intro ? "ส่วนแนะนำรายวิชา" : "", numbered.length ? `ครั้งที่ ${numbered.join(", ")}` : ""].filter(Boolean).join(" และ ");
};

function addIssue(target, key, text, session) {
  if (!target.has(key)) target.set(key, { key, text, sessions:[] });
  target.get(key).sessions.push(session);
}

function labelsFor(data, first) {
  return data.courseType === "GN" ? (first ? GN_FIRST : GN_WEEKLY) : (first ? FIRST : WEEKLY);
}

function actionFor(label, detail) {
  if (/แผนการ/.test(label) && /PDF/.test(label)) return ["plan_document", "เพิ่มเอกสารแผนการสอนที่เปิดตรวจสอบได้"];
  if (/เอกสารประกอบ/.test(label)) return ["material_document", "เพิ่มเอกสารประกอบการสอนที่เปิดตรวจสอบได้"];
  if (/วิดีโอ/.test(label)) {
    if (/ลิงก์เสีย|ไม่สามารถเข้าถึง|ไม่มีอยู่/i.test(detail)) return ["video_link", "แก้ลิงก์วิดีโอที่เปิดไม่ได้หรือไม่มีไฟล์ปลายทาง"];
    if (/โฟลเดอร์\s*Cloud/i.test(detail)) return ["video_folder", "แนบลิงก์วิดีโอรายคลิปแทนลิงก์โฟลเดอร์ Cloud"];
    if (/ติดสิทธิ์|ไม่มีสิทธิ์|ลงชื่อเข้าใช้|เข้าถึงไม่ได้/i.test(detail)) return ["video_permission", "เปิดสิทธิ์ลิงก์วิดีโอให้ผู้ตรวจเข้าชมได้"];
    if (/อัปโหลดภายใน Moodle|ไม่ยืนยันว่าเป็นลิงก์ภายนอก|ยืนยันว่าเป็นลิงก์ภายนอกไม่ได้|เกณฑ์การวางสื่อ/i.test(detail)) return ["video_external", "นำวิดีโอที่อัปโหลดใน Moodle ไปไว้บนผู้ให้บริการภายนอก แล้วเพิ่มเป็นลิงก์วิดีโอในรายวิชา"];
    if (/^0\s+ลิงก์|ไม่พบ.*วิดีโอ/i.test(detail)) return ["video_missing", "เพิ่มวิดีโอการสอนล่วงหน้า"];
    return ["video_duration", "เพิ่มเวลารวมของวิดีโอการสอนล่วงหน้าให้ครบตามเกณฑ์"];
  }
  if (/Podcast/.test(label)) {
    const hasCountableAudio = /[1-9]\d*\s+คลิปเสียงภายนอก/i.test(detail);
    if (/Podcast รูปแบบวิดีโอ|ปลายทางเป็นวิดีโอ/i.test(detail) && !hasCountableAudio) return ["podcast_video", "เปลี่ยน Podcast รูปแบบวิดีโอให้เป็นคลิปเสียง เพราะเกณฑ์รับเฉพาะคลิปเสียง"];
    if (/ติดสิทธิ์|ไม่มีสิทธิ์|ลงชื่อเข้าใช้|เข้าถึงไม่ได้/i.test(detail)) return ["podcast_permission", "เปิดสิทธิ์ลิงก์ Podcast ให้ผู้ตรวจเข้าถึงได้"];
    if (/อัปโหลดใน Moodle|ต้องใช้ลิงก์ภายนอก/i.test(detail)) return ["podcast_external", "เปลี่ยน Podcast เป็นลิงก์ภายนอกที่เปิดตรวจสอบได้"];
    if (/^0\s+(?:คลิปเสียงภายนอก|ลิงก์)|ไม่พบ.*Podcast/i.test(detail)) return ["podcast_missing", "เพิ่มคลิปเสียง Podcast ผ่านลิงก์ภายนอกให้ครบตามเกณฑ์"];
    return ["podcast_duration", "เพิ่มเวลา Podcast ให้ครบอย่างน้อย 10 นาที"];
  }
  if (/แบบทดสอบก่อนเรียน|แบบทดสอบหลังเรียน/.test(label)) {
    return ["external_prepost", "เพิ่มหรือเปลี่ยน Pre-test/Post-test เป็นลิงก์ภายนอก เช่น Google Form"];
  }
  if (/AI Tutor/.test(label)) return ["ai_tutor", "เพิ่มลิงก์ภายนอกสำหรับ AI Tutor"];
  if (/กิจกรรมท้ายบท/.test(label)) return ["assignment", "เพิ่มกิจกรรมท้ายบท เช่น Assignment หรือใบงานกิจกรรม (Quiz ใน Moodle ไม่นับ)"];
  if (/ข้อมูลผู้สอน|ข้อมูลแนะนำรายวิชาและผู้สอน/.test(label)) return ["instructor", "เพิ่มข้อมูลผู้สอนให้ครบ ได้แก่ รูป ชื่อ และช่องทางติดต่อ"];
  if (/ข้อมูลและแนะนำรายวิชา/.test(label)) return ["course_intro", "เพิ่มข้อมูลแนะนำรายวิชาให้ครบ"];
  return ["other:" + label, `แก้ไขหัวข้อ “${label}” ให้ผ่านตามเกณฑ์`];
}

function pendingFor(label, detail) {
  if (/วิดีโอ/.test(label)) return ["pending_video", "ตรวจสอบลิงก์วิดีโอที่ระบบยังอ่านเวลาหรือยืนยันปลายทางไม่ได้"];
  if (/Podcast/.test(label) && /รอผู้ตรวจกรอกและยืนยันเวลา/i.test(detail)) return ["pending_podcast_time", "ผู้ตรวจกรอกเวลา Podcast และติ๊กยืนยันในรายงาน"];
  if (/Podcast/.test(label)) return ["pending_podcast", "ตรวจสอบลิงก์ Podcast ที่ระบบยังยืนยันว่าเป็นคลิปเสียงหรือวิดีโอไม่ได้"];
  if (/PDF/.test(label)) return ["pending_pdf", "ตรวจสอบไฟล์เอกสารที่ระบบยังยืนยันชนิดไฟล์ไม่ได้"];
  if (/แบบทดสอบ/.test(label)) return ["pending_quiz", "ตรวจสอบปลายทางลิงก์ Pre-test/Post-test ที่ระบบยังยืนยันไม่ได้"];
  if (/ผู้สอน/.test(label)) return ["pending_instructor", "ผู้ตรวจควรยืนยันข้อมูลผู้สอนจากหลักฐานที่พบ"];
  return ["pending:" + label, `ตรวจสอบหัวข้อ “${label}” เพิ่มเติม`];
}

export function buildTeacherSummary(data) {
  const actions = new Map();
  const pending = new Map();
  for (const [weekIndex, week] of (data.weeks || []).entries()) {
    const first = weekIndex === 0 || week.section === "ครั้งที่ 1";
    const labels = labelsFor(data, first);
    for (const [index, item] of (week.checklist || []).entries()) {
      const label = labels[index] || `รายการที่ ${index + 1}`;
      const detail = String(item.detail || "");
      // An internal upload remains a delivery problem even when other valid
      // external clips already provide enough time for this weekly row.
      if (/วิดีโอ/.test(label) && /วิดีโออัปโหลดภายใน Moodle/i.test(detail)) {
        addIssue(actions, "video_external", "นำวิดีโอที่อัปโหลดใน Moodle ไปไว้บนผู้ให้บริการภายนอก แล้วเพิ่มเป็นลิงก์วิดีโอในรายวิชา", week.section);
      }
      if (/พบเอกสารอยู่ใน Assignment/.test(detail)) {
        addIssue(actions, "misplaced_assignment_document", MISPLACED_DOCUMENT_MESSAGE, week.section);
        continue;
      }
      // Optional end activity is informational when absent. Do not instruct an
      // instructor to add one unless the rubric marks the row as a failure.
      if (item.status === "not_applicable") continue;
      if (item.status === "fail") {
        const [key, text] = actionFor(label, detail);
        addIssue(actions, key, text, week.section);
      } else if (item.status === "needs_review") {
        const [key, text] = pendingFor(label, detail);
        addIssue(pending, key, text, week.section);
      }
    }
  }
  const finish = (map) => [...map.values()].map((issue) => ({ ...issue, sessions:uniq(issue.sessions), sessionText:sessionList(issue.sessions) }));
  return { actions:finish(actions), pending:finish(pending) };
}
import { MISPLACED_DOCUMENT_MESSAGE } from "./document-placement.js";
