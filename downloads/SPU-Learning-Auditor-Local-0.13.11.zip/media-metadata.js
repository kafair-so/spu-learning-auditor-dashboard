const FAST_METADATA_HOST = /(?:^|\.)(?:youtube\.com|youtube-nocookie\.com|youtu\.be|heygen\.com|drive\.google\.com|photos\.google\.com|photos\.app\.goo\.gl|loom\.com|vidyard\.com|vimeo\.com|wistia\.com|kaltura\.com|onedrive\.live\.com|sharepoint\.com)$/i;

export function isFastMetadataHost(value) {
  try { return FAST_METADATA_HOST.test(new URL(value).hostname); }
  catch { return false; }
}

export function mediaTypeFromProviderEvidence({ contentType = "", markup = "", targetUrl = "", finalUrl = "" } = {}) {
  const mime = String(contentType).toLowerCase();
  if (/^video\//.test(mime)) return "video";
  if (/^audio\//.test(mime)) return "audio";
  const text = String(markup || "");
  // Inspect the actual player/metadata rather than trusting a filename. This
  // also catches provider URLs whose path has no media extension.
  if (/<video\b|(?:content|type|mimeType|mime_type)["'\s:=\\]+video\//i.test(text)
    || /(?:og:type|twitter:player)[^>]{0,120}(?:video|player)/i.test(text)) return "video";
  if (/<audio\b|(?:content|type|mimeType|mime_type)["'\s:=\\]+audio\//i.test(text)
    || /(?:og:type)[^>]{0,120}audio/i.test(text)) return "audio";
  let host = "";
  try { host = new URL(finalUrl || targetUrl).hostname.toLowerCase(); } catch { /* invalid URL */ }
  // These services expose video players. Drive/OneDrive are intentionally not
  // inferred from host because the same service can contain real audio files.
  if (/(?:^|\.)(?:youtube(?:-nocookie)?\.com|youtu\.be|heygen\.com|tiktok\.com|vimeo\.com|loom\.com|vidyard\.com|wistia\.com|kaltura\.com|photos\.google\.com|photos\.app\.goo\.gl)$/i.test(host)) return "video";
  return null;
}

export function unavailableMediaFromProviderMarkup(markup, targetUrl, finalUrl) {
  const text = String(markup || "");
  let host = "";
  try { host = new URL(finalUrl || targetUrl).hostname.toLowerCase(); } catch { return null; }
  if (!/(?:^|\.)youtube(?:-nocookie)?\.com$|youtu\.be$/i.test(host)) return null;

  // A normal YouTube navigation can play the video even when a background
  // fetch receives an anti-bot, sign-in, consent or temporary playback
  // response.  Those responses are not proof that the teacher's link is
  // broken, so let the real browser-tab probe continue instead of failing the
  // item before its player has opened.
  const transientReason = /sign\s*in|log\s*in|confirm\s+(?:that\s+)?you(?:'|’)?re\s+not\s+a\s+bot|protect\s+our\s+community|unusual\s+traffic|too\s+many\s+requests|try\s+again\s+later|temporar(?:y|ily)|consent|before\s+you\s+continue|age[-\s]?restricted|verify\s+your\s+age|playback\s+on\s+other\s+websites\s+has\s+been\s+disabled/i;
  const permanentReason = /(?:video|content).{0,40}(?:isn['’]?t|is\s+not|no\s+longer)\s+available|has\s+been\s+(?:removed|deleted)|(?:removed|deleted)\s+by|private\s+video|this\s+video\s+is\s+private|does\s+not\s+exist|not\s+found/i;

  // Prefer positive metadata for the requested video over an ERROR block
  // belonging to an advert, recommendation or another bootstrap response.
  let requestedVideoId = "";
  try {
    const url = new URL(finalUrl || targetUrl);
    requestedVideoId = url.hostname === "youtu.be"
      ? url.pathname.split("/").filter(Boolean)[0] || ""
      : url.searchParams.get("v") || url.pathname.match(/\/(?:embed|shorts|live)\/([^/?#]+)/i)?.[1] || "";
  } catch { /* invalid URLs were already rejected above */ }
  if (requestedVideoId) {
    const escapedId = requestedVideoId.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const requestedDetails = text.match(new RegExp(`["']videoId["']\\s*:\\s*["']${escapedId}["'][\\s\\S]{0,24000}?["']lengthSeconds["']\\s*:\\s*["']?(\\d+)`, "i"));
    if (Number(requestedDetails?.[1]) > 0) return null;
  }

  // YouTube exposes this before its visible error screen is painted. Reading
  // the status object avoids turning a removed video into a slow player timeout
  // on congested connections. Only an explicit permanent reason is decisive;
  // an unknown ERROR/UNPLAYABLE state must be verified by normal navigation.
  for (const match of text.matchAll(/["']playabilityStatus["']\s*:/gi)) {
    const statusBlock = text.slice(match.index, match.index + 12000);
    const status = statusBlock.match(/["']status["']\s*:\s*["']([A-Z_]+)["']/i)?.[1]?.toUpperCase();
    if (status === "ERROR" || status === "UNPLAYABLE") {
      const reason = (statusBlock.match(/"(?:reason|simpleText)"\s*:\s*"((?:\\.|[^"\\]){1,480})"/i)?.[1]
        || statusBlock.match(/'(?:reason|simpleText)'\s*:\s*'((?:\\.|[^'\\]){1,480})'/i)?.[1])
        ?.replace(/\\u0026/g, "&").replace(/\\n/g, " ").replace(/\\(["'])/g, "$1").trim();
      if (!reason || transientReason.test(reason) || !permanentReason.test(reason)) continue;
      return {
        mediaStatus: "link_unavailable",
        accessNote: reason
          ? `ลิงก์วิดีโอ YouTube ไม่สามารถเข้าถึงได้ — ${reason}`
          : "ลิงก์วิดีโอ YouTube ไม่สามารถเข้าถึงได้ — YouTube ยืนยันสถานะวิดีโอไม่พร้อมใช้งาน"
      };
    }
  }
  return null;
}

// YouTube ships translated error templates in otherwise playable watch-page
// HTML. A background fetch can therefore contain “This video is unavailable”
// even while the requested player is valid. The YouTube-specific parser above
// is allowed to reject only a permanent playabilityStatus for the requested
// video; the provider-neutral text gate must wait for visible browser evidence.
export function filterProviderMarkupAccessGate(gate, targetUrl, finalUrl) {
  if (!gate) return null;
  let host = "";
  try { host = new URL(finalUrl || targetUrl).hostname.toLowerCase(); } catch { return gate; }
  if (/(?:^|\.)youtube(?:-nocookie)?\.com$|youtu\.be$/i.test(host)) return null;
  return gate;
}

const clockSeconds = (value) => {
  const parts = String(value || "").split(":").map(Number);
  if (parts.some((part) => !Number.isFinite(part))) return 0;
  return parts.length === 3 ? parts[0] * 3600 + parts[1] * 60 + parts[2] : parts.length === 2 ? parts[0] * 60 + parts[1] : 0;
};

export function selectProviderDurationEvidence(items = []) {
  const evidenceScore = (item) => item.mainDurationSeconds
    ? 5
    : item.isNotebook && item.notebookDurationSeconds
      ? 4.75
      : item.seconds
        ? 4
        : item.controlDurationSeconds
          ? 3.5
          : item.embeddedDurationSeconds
            ? 3
            : clockSeconds(item.durationText)
              ? 2
              : 0;
  const best = [...items].sort((a, b) => evidenceScore(b) - evidenceScore(a))[0] || {};
  const durationSeconds = best.mainDurationSeconds
    || (best.isNotebook ? best.notebookDurationSeconds : 0)
    || best.seconds
    || best.controlDurationSeconds
    || best.embeddedDurationSeconds
    || clockSeconds(best.durationText)
    || null;
  return { best, durationSeconds };
}

export function durationFromProviderMarkup(markup, targetUrl, finalUrl) {
  const text = String(markup || "");
  let host = "";
  try { host = new URL(finalUrl || targetUrl).hostname.toLowerCase(); } catch { /* invalid target */ }
  const valid = (seconds) => Number.isFinite(seconds) && seconds > 0 && seconds <= 8 * 3600 ? Math.round(seconds) : null;
  const iso = text.match(/(?:itemprop|property)=["'](?:duration|video:duration)["'][^>]*content=["'](PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?|\d+)["']/i)
    || text.match(/content=["'](PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?|\d+)["'][^>]*(?:itemprop|property)=["'](?:duration|video:duration)["']/i);
  if (iso) {
    const value = iso[1];
    const parts = value.match(/^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/i);
    const seconds = parts ? Number(parts[1] || 0) * 3600 + Number(parts[2] || 0) * 60 + Number(parts[3] || 0) : Number(value);
    if (valid(seconds)) return { durationSeconds:valid(seconds), source:"provider-meta-tag" };
  }
  // JSON-LD is the primary public metadata channel used by providers such as
  // HeyGen. It is not written as a <meta> tag, so keep it as a separate,
  // provider-neutral duration source.
  const jsonLdIso = text.match(/["']duration["']\s*:\s*["'](PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)["']/i);
  if (jsonLdIso) {
    const parts = jsonLdIso[1].match(/^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/i);
    const seconds = parts ? Number(parts[1] || 0) * 3600 + Number(parts[2] || 0) * 60 + Number(parts[3] || 0) : 0;
    if (valid(seconds)) return { durationSeconds:valid(seconds), source:"provider-jsonld" };
  }
  if (/(?:^|\.)youtube(?:-nocookie)?\.com$|youtu\.be$/i.test(host)) {
    const detailsAt = text.indexOf('"videoDetails"');
    const details = detailsAt >= 0 ? text.slice(detailsAt, detailsAt + 24000) : "";
    const seconds = Number(details.match(/"lengthSeconds"\s*:\s*"?(\d+)"?/i)?.[1]);
    if (valid(seconds)) return { durationSeconds:valid(seconds), source:"youtube-metadata" };
  }
  if (/photos\.google\.com$|photos\.app\.goo\.gl$/i.test(host)) {
    const millis = Number(text.match(/"(?:durationMillis|durationMs)"\s*:\s*"?(\d+)"?/i)?.[1]);
    if (valid(millis / 1000)) return { durationSeconds:valid(millis / 1000), source:"google-photos-metadata" };
    const micros = Number(text.match(/"(?:durationMicros|durationUsec|durationUs)"\s*:\s*"?(\d+)"?/i)?.[1]);
    if (valid(micros / 1000000)) return { durationSeconds:valid(micros / 1000000), source:"google-photos-metadata" };
  }
  if (/drive\.google\.com$|onedrive\.live\.com$|sharepoint\.com$/i.test(host)) {
    const millis = Number(text.match(/"(?:durationMillis|durationMs)"\s*:\s*"?(\d+)"?/i)?.[1]);
    if (valid(millis / 1000)) return { durationSeconds:valid(millis / 1000), source:/drive\.google/.test(host) ? "drive-metadata" : "onedrive-metadata" };
  }
  if (/(?:heygen|loom|vidyard|vimeo|wistia|kaltura)\.com$|fast\.wistia\.net$/i.test(host)) {
    const seconds = Number(text.match(/"(?:duration|durationSeconds|videoDuration|lengthSeconds)"\s*:\s*"?(\d+(?:\.\d+)?)"?/i)?.[1]
      || text.match(/\\?"duration\\?"\s*,\s*(\d+(?:\.\d+)?)/i)?.[1]);
    if (valid(seconds)) return { durationSeconds:valid(seconds), source:"provider-metadata" };
  }
  return null;
}
