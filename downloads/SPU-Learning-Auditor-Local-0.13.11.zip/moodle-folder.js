const DOCUMENT_EXTENSION = /\.(?:pdf|pptx?|docx?|xlsx?|odt|odp|ods|rtf|txt|csv)(?:$|[?#])/i;
const PDF_EVIDENCE = /\.pdf(?:$|[?#\s])|application\/pdf|(?:\/|%2f)f(?:\/|%2f)pdf\b|fa-file-pdf/i;
const DOCUMENT_EVIDENCE = /\.(?:pptx?|docx?|xlsx?|odt|odp|ods|rtf|txt|csv)(?:$|[?#\s])|application\/(?:msword|rtf|vnd\.)|text\/(?:plain|csv)|fa-file-(?:word|powerpoint|excel|text)/i;

const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();

function decodedFileName(url) {
  const segment = String(url?.pathname || "").split("/").filter(Boolean).at(-1) || "";
  try { return decodeURIComponent(segment); } catch { return segment; }
}

function canonicalFolderFile(url) {
  const copy = new URL(url.href);
  copy.hash = "";
  copy.searchParams.delete("forcedownload");
  return copy.href;
}

// Moodle Folder pages may show the same file in a tree row, a filename row and
// a download control. Normalize those DOM observations into one document per
// real file and reject the generated "Download folder" archive.
export function normalizeMoodleFolderEntries(rawEntries, folderUrl) {
  let folder;
  try { folder = new URL(folderUrl); } catch { return []; }
  const found = new Map();
  for (const raw of Array.isArray(rawEntries) ? rawEntries : []) {
    let url;
    try { url = new URL(raw?.href || "", folder); } catch { continue; }
    if (!/^https?:$/.test(url.protocol) || url.origin !== folder.origin) continue;
    const title = clean(raw?.title) || decodedFileName(url) || "ไฟล์ในโฟลเดอร์ Moodle";
    const evidence = `${title} ${url.href} ${clean(raw?.type)} ${clean(raw?.evidence)}`;
    if (/download\s*folder|ดาวน์โหลด\s*โฟลเดอร์/i.test(title) || /\.zip(?:$|[?#])/i.test(evidence)) continue;
    // Folder contents are served through pluginfile.php. Requiring either that
    // route or explicit document evidence prevents navigation/buttons and
    // audio/video assets from becoming teaching-document credit.
    const pluginFile = /\/(?:webservice\/)?pluginfile\.php\//i.test(url.pathname);
    const isPdf = PDF_EVIDENCE.test(evidence);
    const isDocument = isPdf || DOCUMENT_EXTENSION.test(evidence) || DOCUMENT_EVIDENCE.test(evidence);
    if (!isDocument || (!pluginFile && !DOCUMENT_EXTENSION.test(url.pathname + url.search))) continue;
    const key = canonicalFolderFile(url);
    if (found.has(key)) continue;
    found.set(key, {
      href:url.href,
      title,
      folderPath:clean(raw?.path),
      isPdf,
      fileVerification:isPdf ? "pdf" : "not_pdf",
      sourceType:"moodle_folder"
    });
  }
  return [...found.values()];
}
