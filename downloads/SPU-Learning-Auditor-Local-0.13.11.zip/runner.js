import { initTheme } from "./theme.js";
import { initI18n, addLanguageMenu } from "./i18n.js";
import {reportPageUrl} from "./report-store.js";
await initI18n();
await addLanguageMenu();
await initTheme();
const course = document.querySelector("#course");
const status = document.querySelector("#status");
const fill = document.querySelector("#fill");
const done = document.querySelector("#done");
const errorBox = document.querySelector("#error");
const stop = document.querySelector("#stop");
let isRunning = true;
let runId = null;
let auditStartedAt = null;
let timerId = null;
let latestProgress = null;
let completedReportId = null;
const elapsed = () => {
  const seconds = Math.max(0, Math.floor((Date.now() - Number(auditStartedAt || Date.now())) / 1000));
  return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
};
const remaining = (progress) => {
  const current = Number(progress?.current || 0);
  const total = Number(progress?.total || 0);
  if (current < 2 || total <= current) return "";
  const usedMs = Date.now() - Number(auditStartedAt || Date.now());
  const seconds = Math.max(0, Math.round((usedMs / current) * (total - current) / 1000));
  return ` · คาดว่าเหลือ ${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
};

stop.addEventListener("click", async () => {
  if (!runId || !isRunning) return;
  stop.disabled = true;
  status.textContent = "กำลังหยุดหลังจบลิงก์ที่กำลังเปิด…";
  await chrome.storage.local.set({cancelAuditId: runId});
});

function showProgress(progress) {
  if (progress) latestProgress = progress;
  if (!latestProgress) return;
  const pct = latestProgress.total ? Math.round((latestProgress.current / latestProgress.total) * 100) : 2;
  fill.style.width = `${Math.max(2,pct)}%`;
  status.textContent = `${latestProgress.label || `กำลังตรวจ ${latestProgress.current || 0} จาก ${latestProgress.total || 0} รายการ`} · ใช้เวลา ${elapsed()}${remaining(latestProgress)} · เป้าหมาย 28:00`;
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.auditProgress && isRunning) showProgress(changes.auditProgress.newValue);
});

const { pendingAudit } = await chrome.storage.local.get("pendingAudit");
if (!pendingAudit) {
  status.textContent = "ไม่พบงานตรวจ กรุณาเริ่มจากหน้ารายวิชา";
  fill.style.width = "0";
} else {
  runId = pendingAudit.runId || crypto.randomUUID();
  pendingAudit.runId = runId;
  auditStartedAt = pendingAudit.timing?.auditStartedAt || Date.now();
  timerId = setInterval(() => { if (isRunning) showProgress(null); }, 1000);
  await chrome.storage.local.set({pendingAudit, cancelAuditId: null});
  course.textContent = `${pendingAudit.courseTitle} · ${pendingAudit.courseType} · ${pendingAudit.credits} หน่วยกิต`;
  await chrome.storage.local.set({auditProgress:{current:0,total:pendingAudit.activities.length,label:"กำลังเตรียมลิงก์…"}});
  const response = await chrome.runtime.sendMessage({type:"AUDIT",payload:pendingAudit});
  isRunning = false;
  clearInterval(timerId);
  if (!response?.ok || response?.report?.runId !== runId) {
    status.textContent = response?.error === "หยุดการตรวจตามคำสั่งผู้ใช้" ? "หยุดการตรวจแล้ว" : "การตรวจหยุดลง";
    errorBox.hidden = false; errorBox.textContent = response?.error || "ไม่พบผลตรวจของรอบปัจจุบัน";
  } else {
    completedReportId = response.report.id;
    fill.style.width = "100%";
    status.textContent = `ตรวจเสร็จแล้ว · ใช้เวลา ${elapsed()}`;
    done.hidden = false;
    await chrome.storage.local.remove("pendingAudit");
  }
}
document.querySelector("#openReport").addEventListener("click",()=>chrome.tabs.create({url:reportPageUrl(chrome.runtime.getURL("report.html"),completedReportId)}));
