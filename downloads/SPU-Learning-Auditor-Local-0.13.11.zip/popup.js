import { initTheme } from "./theme.js";
import { initI18n, addLanguageMenu } from "./i18n.js";
import { isCourseUrl } from "./platform.js";
import { listStoredReports } from "./report-store.js";

await initI18n();
await addLanguageMenu();
await initTheme();

const queueButton = document.querySelector("#queue");
const historyButton = document.querySelector("#history");
const diagnoseButton = document.querySelector("#diagnose");
const queueMeta = document.querySelector("#queueMeta");
const historyMeta = document.querySelector("#historyMeta");
const structureMeta = document.querySelector("#structureMeta");
const progress = document.querySelector("#progress");
const version = chrome.runtime.getManifest().version;
document.querySelector("#version").textContent = `รุ่น ${version} · ศูนย์รวมการตรวจรายวิชา`;

// Structure diagnostics need only the compact page model. Link and media
// inspection belong to the queue runner and never start from this popup.
const compactScan = (scan) => ({...scan, activities:(scan.activities || []).map(({html, ...activity}) => activity)});
const [activeAtOpen] = await chrome.tabs.query({active:true, currentWindow:true});
const currentCourse = isCourseUrl(activeAtOpen?.url);

diagnoseButton.disabled = !currentCourse;
structureMeta.textContent = currentCourse
  ? `พร้อมตรวจ: ${activeAtOpen.title || "รายวิชาที่เปิดอยู่"}`
  : "เปิดหน้ารายวิชา d-Learning หรือ i-Learning ก่อน";

async function refreshSummary() {
  const [{auditQueue:items = []}, reports] = await Promise.all([
    chrome.storage.local.get("auditQueue"),
    listStoredReports().catch(() => [])
  ]);
  const running = items.filter((item) => item.status === "running").length;
  const waiting = items.filter((item) => ["queued", "paused"].includes(item.status)).length;
  queueMeta.textContent = running || waiting
    ? `กำลังตรวจ ${running} · รอคิว ${waiting}`
    : "ไม่มีงานค้าง — เพิ่มรายวิชาได้ในหน้าคิว";
  historyMeta.textContent = `${reports.length} รายงานที่บันทึกไว้`;
}

async function readCurrentCourse() {
  const [tab] = await chrome.tabs.query({active:true, currentWindow:true});
  if (!isCourseUrl(tab?.url)) throw new Error("กรุณาเปิดหน้ารายวิชา d-Learning หรือ i-Learning ก่อน");
  try {
    const scan = await chrome.tabs.sendMessage(tab.id, {type:"SCAN_COURSE"});
    if (!scan?.ok) throw new Error(scan?.error || "อ่านหน้าไม่ได้");
    return scan;
  } catch (error) {
    if (/อ่านหน้าไม่ได้/.test(error.message)) throw error;
    throw new Error("โปรดรีเฟรชหน้ารายวิชา แล้วลองอีกครั้ง");
  }
}

queueButton.addEventListener("click", () => chrome.tabs.create({url:chrome.runtime.getURL("queue.html")}));
historyButton.addEventListener("click", () => chrome.tabs.create({url:chrome.runtime.getURL("history.html")}));
diagnoseButton.addEventListener("click", async () => {
  diagnoseButton.disabled = true;
  progress.hidden = false;
  progress.textContent = "กำลังตรวจโครงสร้าง โดยยังไม่เปิดลิงก์ภายนอก…";
  try {
    const scan = compactScan(await readCurrentCourse());
    await chrome.storage.local.set({lastStructureScan:{...scan, capturedAt:new Date().toISOString()}});
    await chrome.tabs.create({url:chrome.runtime.getURL("diagnostic.html")});
    progress.textContent = "ตรวจโครงสร้างเสร็จแล้ว";
  } catch (error) {
    progress.textContent = error.message || "ตรวจโครงสร้างไม่สำเร็จ";
    diagnoseButton.disabled = !currentCourse;
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.auditQueue || changes.reportIndex)) refreshSummary();
});
await refreshSummary();
