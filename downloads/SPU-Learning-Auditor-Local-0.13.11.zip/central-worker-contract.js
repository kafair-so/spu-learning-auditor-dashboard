export const CENTRAL_WORKER_STATE_KEY = "centralWorkerState";

const text = (value) => String(value ?? "").trim();

export function normalizeCentralJob(payload = {}) {
  const raw = payload.job || payload;
  const course = raw.course || {};
  const courseId = text(raw.courseId || raw.course_id || course.courseId || course.course_id);
  const courseUrl = text(raw.courseUrl || raw.course_url || course.courseUrl || course.course_url)
    || (courseId ? `https://dlearning.spu.ac.th/course/view.php?id=${encodeURIComponent(courseId)}` : "");
  const profile = text(raw.courseProfile || raw.course_profile || course.courseProfile || course.course_profile);
  const inferredGroup = (profile.match(/\d{3}(GN|GR|GS)-/i) || [])[1] || "";
  const courseType = text(raw.courseType || raw.course_type || raw.courseGroup || raw.course_group || course.courseType || course.course_type || course.courseGroup || course.course_group || inferredGroup).toUpperCase();
  const jobId = text(raw.jobId || raw.job_id);
  const credits = Number(raw.credits || course.credits || 3);
  if (!jobId || !courseId || !courseUrl || !["GN", "GR", "GS"].includes(courseType)) {
    throw new Error("ข้อมูลคิวกลางไม่ครบ: ต้องมีรหัสงาน รหัสรายวิชา ลิงก์ และกลุ่ม GN/GR/GS");
  }
  return {
    jobId,
    courseId,
    courseUrl,
    courseType,
    credits:Number.isFinite(credits) && credits > 0 ? credits : 3,
    gnTrack:courseType === "GN" ? text(raw.gnTrack || raw.gn_track || course.gnTrack || course.gn_track || "theory") : null,
    courseCode:text(raw.courseCode || raw.course_code || course.courseCode || course.course_code),
    courseTitle:text(raw.courseTitle || raw.course_title || course.courseTitle || course.course_title),
    courseProfile:profile,
    claimedAt:text(raw.claimedAt || raw.claimed_at),
    kind:text(raw.kind || "missing")
  };
}

export function failedCentralResult(job, error, {runId = "", version = ""} = {}) {
  const message = text(error?.message || error || "งานตรวจไม่สำเร็จ");
  return {
    schemaVersion:2,
    recordType:"spu_learning_audit_result",
    auditId:`central-failed-${job.jobId}-${Date.now()}`,
    runId,
    auditedAt:new Date().toISOString(),
    auditorVersion:version,
    group:job.courseType,
    courseTitle:job.courseTitle,
    courseUrl:job.courseUrl,
    courseId:job.courseId,
    courseCode:job.courseCode,
    courseProfile:job.courseProfile,
    internalStatus:"audit_failed",
    publicStatus:"",
    confirmedScore:0,
    reviewablePoints:0,
    possibleScore:0,
    threshold:job.courseType === "GN" ? 0 : 80,
    reason:"worker_error",
    scoreModel:"weekly_criterion_v2",
    coverageComplete:false,
    evidenceSnapshot:{workerError:message}
  };
}

export function emptyCentralResult(job, scan = {}, {runId = "", version = ""} = {}) {
  return {
    schemaVersion:2,
    recordType:"spu_learning_audit_result",
    auditId:`central-empty-${job.jobId}-${Date.now()}`,
    runId,
    auditedAt:new Date().toISOString(),
    auditorVersion:version,
    group:job.courseType,
    courseTitle:scan.courseTitle || job.courseTitle,
    courseUrl:job.courseUrl,
    courseId:job.courseId,
    courseCode:job.courseCode,
    courseProfile:job.courseProfile,
    internalStatus:"no_content",
    publicStatus:"no_content",
    confirmedScore:0,
    reviewablePoints:0,
    possibleScore:0,
    threshold:job.courseType === "GN" ? 0 : 80,
    reason:"successful_scan_found_no_course_content",
    scoreModel:"weekly_criterion_v2",
    coverageComplete:true,
    evidenceSnapshot:{
      emptyReason:scan.emptyReason || "ไม่พบเนื้อหารายวิชา",
      coverage:scan.coverage || {},
      activities:[]
    }
  };
}
