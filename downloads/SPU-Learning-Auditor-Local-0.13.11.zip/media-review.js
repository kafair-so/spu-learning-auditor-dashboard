export const MEDIA_DECISIONS = ["pending", "use", "recording", "activity", "supplementary"];
export const DEFINITIVE_MEDIA_FAILURES = new Set(["access_denied", "login_required", "link_unavailable", "link_error", "reviewer_confirmed_unreadable"]);
export function isDefinitiveMediaFailure(item) {
  return DEFINITIVE_MEDIA_FAILURES.has(item?.mediaStatus);
}
export function requiresMediaReview(item) {
  // A confirmed access wall or broken destination is already a final result.
  // It must never also appear as an ambiguous clip awaiting a reviewer.
  if (item?.mediaReviewDecision && item.mediaReviewDecision !== "pending") return false;
  return item.kind === "video" && !isDefinitiveMediaFailure(item) && (item.mediaReviewRequired || item.mediaCandidateProbe || item.classification?.contextConflict || !item.durationSeconds);
}
export function videoStatusWithFailures(items, computedStatus) {
  // Broken or access-restricted extras must not erase duration already proven
  // by valid clips. They remain visible as issues, but the time row passes
  // once usable media reaches the rubric threshold.
  if (computedStatus === "pass" || computedStatus === "pass_tolerance") return computedStatus;
  return items.some(isDefinitiveMediaFailure) ? "fail" : computedStatus;
}
export function applyMediaReviews(items, reviews = {}) {
  for (const item of items) {
    if (item.kind === "video" && isDefinitiveMediaFailure(item)) {
      item.mediaReviewRequired = false;
      item.mediaReviewDecision = null;
      item.reviewExcluded = false;
      continue;
    }
    const savedDecision = reviews[item.href]?.decision || item.mediaReviewDecision || "pending";
    if (savedDecision !== "pending") {
      item.mediaReviewRequired = false;
      item.mediaReviewDecision = savedDecision;
      item.reviewExcluded = ["recording","activity","supplementary"].includes(savedDecision);
      if (item.reviewExcluded) item.countingEligible = false;
      else if (!item.duplicateOf) item.countingEligible = true;
      continue;
    }
    if (!requiresMediaReview(item)) continue;
    item.mediaReviewRequired = true;
    item.mediaReviewDecision = "pending";
    item.reviewExcluded = ["recording","activity","supplementary"].includes(item.mediaReviewDecision);
    if (item.reviewExcluded) item.countingEligible = false;
    else if (!item.duplicateOf) item.countingEligible = true;
  }
}
export function parsePodcastParts(minutes, seconds) {
  if (!/^\d{1,2}$/.test(minutes) || !/^\d{1,2}$/.test(seconds)) return null;
  if (Number(seconds) > 59) return null;
  const value = Number(minutes) * 60 + Number(seconds);
  return value > 0 ? value : null;
}
export function finalReviewBlockerDetails(report) {
  const c = report.coverage || {};
  const details = [];
  if (c.reachedEnd === false) details.push("ระบบยังอ่านหน้าเรียนไม่ถึงท้ายหน้า");
  if (c.structurallyComplete === false) details.push("โครงสร้างครั้งเรียนยังไม่ครบ");
  if (c.topologyReviewRequired === true || !c.topologyManuallyConfirmed && (c.topologyConfidence === "low" || (c.topologyDiagnostics || []).some(x => !x.excluded && /ขัด|เกิน/.test(x.reason || "")))) details.push("โครงสร้าง Section ยังขัดแย้งหรือยังไม่ได้รับการยืนยัน");
  if (Number(c.unmappedNonForumActivityCount || 0) > 0) details.push(`ยังจับคู่ครั้งเรียนไม่ได้ ${c.unmappedNonForumActivityCount} รายการ`);
  const typeItems = (report.activities || []).filter(item => !item.titleAlternativeOf && (item.kind === "video_candidate" || item.kind === "assignment_image_candidate" || item.classification?.contextConflict && (!item.mediaReviewRequired || item.mediaReviewDecision === "pending")));
  if (Number(c.unresolvedClassificationCount || 0) > 0) details.push(typeItems.length ? `ยังไม่ยืนยันประเภท: ${typeItems.slice(0,3).map(item => item.title || "ไม่ระบุชื่อ").join(", ")}` : `ยังไม่ยืนยันประเภทรายการ ${c.unresolvedClassificationCount} รายการ`);
  if (Number(c.unresolvedScoringEvidenceCount || 0) > 0) {
    const scoringItems = (report.activities || []).filter(item => !item.outOfRange && item.auditSession && ["video","podcast"].includes(item.kind) && item.countingEligible !== false && (item.mediaReviewRequired && item.mediaReviewDecision !== "use" || !item.durationSeconds) && !isDefinitiveMediaFailure(item));
    details.push(scoringItems.length ? `ยังมีหลักฐานที่มีผลต่อคะแนนค้าง: ${scoringItems.slice(0,3).map(item => item.title || "ไม่ระบุชื่อ").join(", ")}` : `ยังมีหลักฐานที่มีผลต่อคะแนนค้าง ${c.unresolvedScoringEvidenceCount} รายการ`);
  }
  for (const week of report.weeks || []) {
    const count = (week.checklist || []).filter(item => item.status === "needs_review").length;
    if (count) details.push(`${week.section || "ไม่ระบุครั้ง"} ยังต้องตรวจทาน ${count} หัวข้อ`);
  }
  return [...new Set(details)];
}
export function finalReviewBlockers(report) {
  return finalReviewBlockerDetails(report).length > 0;
}
