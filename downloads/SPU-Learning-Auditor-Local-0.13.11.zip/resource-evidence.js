export function applyMoodleFileTypeHint(resource, activity) {
  const current = resource || { target:activity.href, name:"", isPdf:false, isAudio:false, isVideo:false, fileVerification:"unresolved" };
  // Response headers, file signatures and a confirmed non-PDF destination are
  // stronger than a course-page icon. The icon is only a fallback when target
  // inspection cannot decide (forced downloads and Chrome's PDF UI).
  if (current.fileVerification && current.fileVerification !== "unresolved") return current;
  const label = String(activity.title || "").replace(/\s+File$/i, "").trim();
  if (activity.fileTypeHint === "pdf") return { ...current, target:current.target || activity.href, name:current.name || label, isPdf:true, isAudio:false, isVideo:false, fileVerification:"pdf", sourceType:"moodle_activity_icon" };
  if (activity.fileTypeHint === "audio") return { ...current, target:current.target || activity.href, name:current.name || label, isPdf:false, isAudio:true, isVideo:false, fileVerification:"not_pdf", sourceType:"moodle_activity_icon" };
  if (activity.fileTypeHint === "video") return { ...current, target:current.target || activity.href, name:current.name || label, isPdf:false, isAudio:false, isVideo:true, fileVerification:"not_pdf", sourceType:"moodle_activity_icon" };
  return current;
}

export async function resolveMoodleResourceEvidence(activity, inspectTarget) {
  // Moodle's own /f/pdf and /f/audio icons are MIME decisions made by the
  // server for this activity. Resolve them before opening view.php: that route
  // can return an HTML wrapper or Chrome PDF page and must not erase the MIME
  // evidence already present on the course page.
  const hinted = applyMoodleFileTypeHint(null, activity);
  if (hinted.fileVerification !== "unresolved") return hinted;
  return applyMoodleFileTypeHint(await inspectTarget(activity.href), activity);
}
