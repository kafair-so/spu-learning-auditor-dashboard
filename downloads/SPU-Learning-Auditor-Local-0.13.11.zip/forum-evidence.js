import {PRE_PATTERN, POST_PATTERN, ACTIVITY_PATTERN} from './rules.js';

export function forumTaskKind(title = '') {
  if (POST_PATTERN.test(title)) return 'post_quiz';
  if (PRE_PATTERN.test(title)) return 'pre_quiz';
  if (ACTIVITY_PATTERN.test(title) || /แบบฝึกหัด|แบบทดสอบท้ายบท/i.test(title)) return 'assignment';
  return null;
}

export function forumTaskEvidence(title, contentText) {
  const kind = forumTaskKind(title);
  const body = String(contentText || '').replace(/\s+/g, ' ').trim();
  const instructions = /ให้นักศึกษา|ให้ผู้เรียน|จง|ตอบคำถาม|คำถาม|อธิบาย|วิเคราะห์|อภิปราย|ส่งงาน|ทำแบบฝึกหัด|อะไร|อย่างไร|เพราะเหตุใด|ใครบ้าง|ใคร|อะไรบ้าง|\?|answer|describe|explain|discuss|submit|what|why|how/i.test(body);
  const numbered = /(?:^|\s)[1-9][0-9]*[.)]\s*\S/.test(body);
  return {kind, confirmed:Boolean(kind && body.length >= 30 && (instructions || numbered)), excerpt:body.slice(0, 800)};
}
