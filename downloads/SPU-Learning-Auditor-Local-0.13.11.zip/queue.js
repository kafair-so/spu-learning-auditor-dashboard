import { MEDIA_PROVIDER_ORIGINS } from "./providers.js";
import { initTheme } from "./theme.js";
import { initI18n, addLanguageMenu } from "./i18n.js";
import { isCourseUrl } from "./platform.js";
import {loadStoredReport,reportPageUrl} from "./report-store.js";
import {buildDashboardRecord} from "./dashboard-export.js";
import {courseQueueKey,deduplicateAuditQueue} from "./queue-dedup.js";

await initI18n();
await addLanguageMenu();
await initTheme();

const form = document.querySelector("#add");
const url = document.querySelector("#url");
const type = document.querySelector("#type");
const gnTrack = document.querySelector("#gnTrack");
const gnTrackRow = document.querySelector("#gnTrackRow");
const credits = document.querySelector("#credits");
const list = document.querySelector("#list");
const status = document.querySelector("#status");
const catalogFile = document.querySelector("#catalogFile");
const catalogStatus = document.querySelector("#catalogStatus");
const escapeHtml = (value) => String(value || "").replace(/[&<>]/g, (char) => ({"&":"&amp;","<":"&lt;",">":"&gt;"}[char]));
const labels = {queued:"รอตรวจ",running:"กำลังตรวจ",paused:"พักไว้",done:"เสร็จแล้ว",empty:"ไม่พบเนื้อหารายวิชา",failed:"ตรวจไม่สำเร็จ",cancelled:"หยุดแล้ว"};
const normalizeCatalogCourse = (course = {}) => {
  const courseUrl = String(course.courseUrl || course.url || course["ลิงก์"] || "").trim();
  const profile = String(course.courseProfile || course.profile || course["Course Profile"] || "");
  const inferredType = (profile.match(/\d{3}(GN|GR|GS)-/i) || [])[1] || "";
  const courseType = String(course.courseType || course.type || course["ประเภท"] || inferredType).toUpperCase();
  const rawCredits = course.credits ?? course["หน่วยกิต"] ?? 3;
  const credits = Number((String(rawCredits).match(/\d+/) || [3])[0]);
  return {courseUrl,courseType,credits,courseCode:String(course.courseCode || course["รหัสวิชา"] || ""),courseProfile:profile,faculty:String(course.faculty || course["คณะ / วิทยาลัย"] || ""),instructors:String(course.instructors || course["อาจารย์ผู้สอน"] || "")};
};
let seenProgressAt = 0;
const syncGnTrack = () => { gnTrackRow.hidden = type.value !== "GN"; };
type.addEventListener("change", syncGnTrack);
syncGnTrack();

const duration = (milliseconds) => {
  const seconds = Math.max(0, Math.floor(Number(milliseconds || 0) / 1000));
  return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
};
const elapsedFor = (item) => {
  const stored = Number(item.attemptElapsedMs ?? item.elapsedMs ?? 0);
  return item.status === "running" ? stored + Math.max(0, Date.now() - Number(item.attemptStartedAt || item.startedAt || Date.now())) : stored;
};
const estimateRemaining = (item, progress) => {
  const current = Number(progress?.current || 0);
  const total = Number(progress?.total || 0);
  if (current < 2 || total <= current) return "";
  const elapsedMs = elapsedFor(item);
  const remainingMs = Math.round((elapsedMs / current) * (total - current));
  return ` · คาดว่าเหลือประมาณ ${duration(remainingMs)}`;
};

async function state() {
  return chrome.storage.local.get(["auditQueue","auditQueueControl","auditProgress"]);
}

async function cleanStoredQueueDuplicates() {
  const {auditQueue:items = []} = await state();
  const cleaned = deduplicateAuditQueue(items);
  if (cleaned.length === items.length) return 0;
  await chrome.storage.local.set({auditQueue:cleaned});
  return items.length - cleaned.length;
}

const removedDuplicateJobs = await cleanStoredQueueDuplicates();
if (removedDuplicateJobs) catalogStatus.textContent = `นำรายการตรวจซ้ำออก ${removedDuplicateJobs.toLocaleString("th-TH")} รายการ โดยไม่ลบรายงานย้อนหลัง`;

async function render() {
  const {auditQueue:items = [], auditQueueControl:control = {}, auditProgress:progress = {}} = await state();
  const active = items.find((item) => item.status === "running");
  const live = active ? `<div class="meta">ขั้นตอน: ${escapeHtml(progress.label || "กำลังเริ่มงาน")} · ${progress.total ? `${progress.current} / ${progress.total} รายการ` : "กำลังอ่านโครงสร้าง"} · ใช้เวลา ${duration(elapsedFor(active))}${estimateRemaining(active, progress)} · เป้าหมายไม่เกิน 28:00 · อัปเดตล่าสุด ${seenProgressAt ? new Date(seenProgressAt).toLocaleTimeString("th-TH") : "รอสัญญาณ"}</div>` : "";
  status.textContent = control.paused ? "พักคิวแล้ว" : control.stopped ? "หยุดคิวแล้ว" : active ? "กำลังตรวจอยู่" : items.some((item) => item.status === "queued") ? "มีรายการรอตรวจ" : "ไม่มีงานค้าง";
  list.innerHTML = live + (items.length ? items.map((item, index) => {
    const time = item.status === "running" ? `กำลังตรวจมาแล้ว ${duration(elapsedFor(item))}` : item.elapsedMs ? `ใช้เวลาตรวจ ${duration(elapsedFor(item))}` : "";
    const track = item.courseType === "GN" ? ` · ${item.gnTrack === "practical" ? "ปฏิบัติ" : "ทฤษฎี"}` : "";
    const tone = item.status === "done" ? "success" : item.status === "running" || item.status === "paused" || item.status === "empty" ? "warning" : item.status === "failed" || item.status === "cancelled" ? "danger" : "info";
    return `<section class="card panel ${tone}"><strong>${escapeHtml(item.courseTitle || item.courseUrl)}</strong><div class="meta">${item.courseType}${track} · ${item.credits} หน่วยกิต</div><div class="${item.status}">${labels[item.status]}</div>${time ? `<div class="meta elapsed">${time}</div>` : ""}${item.resultMessage ? `<div class="empty-note">${escapeHtml(item.resultMessage)}</div>` : ""}${item.error ? `<div class="failed">${escapeHtml(item.error)}</div>` : ""}${item.status === "done" ? `<button data-open="${index}">เปิดรายงาน</button>` : ""}${["failed","cancelled","paused","empty"].includes(item.status) ? `<button class="secondary" data-retry="${index}">ตรวจใหม่</button>` : ""}</section>`;
  }).join("") : '<p class="muted">ยังไม่มีรายวิชาในคิว</p>');
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  let parsed;
  try { parsed = new URL(url.value); } catch { status.textContent = "URL ไม่ถูกต้อง"; return; }
  if (!isCourseUrl(parsed.href)) {
    status.textContent = "ต้องเป็นลิงก์หน้ารายวิชา d-Learning หรือ i-Learning";
    return;
  }
  const {auditQueue:items = []} = await state();
  const key = courseQueueKey(parsed.href);
  if (items.some((item) => courseQueueKey(item.courseUrl) === key)) {
    status.textContent = "รายวิชานี้มีอยู่ในคิวแล้ว จึงไม่เพิ่มงานซ้ำ";
    return;
  }
  items.push({id:crypto.randomUUID(),courseUrl:parsed.href,courseType:type.value,gnTrack:type.value === "GN" ? gnTrack.value : null,credits:Number(credits.value),status:"queued",createdAt:new Date().toISOString(),elapsedMs:0});
  await chrome.storage.local.set({auditQueue:items});
  url.value = "";
  render();
});

document.querySelector("#importCatalog").addEventListener("click", async () => {
  try {
    const file = catalogFile.files?.[0];
    if (!file) throw new Error("กรุณาเลือกไฟล์รายการรายวิชา JSON");
    const parsed = JSON.parse(await file.text());
    const catalog = (Array.isArray(parsed) ? parsed : parsed.courses || []).map(normalizeCatalogCourse)
      .filter((course) => isCourseUrl(course.courseUrl) && ["GN","GR","GS"].includes(course.courseType));
    if (!catalog.length) throw new Error("ไม่พบลิงก์รายวิชา d-Learning หรือ i-Learning ในไฟล์นี้");
    const {auditQueue:items = []} = await state();
    const known = new Set(items.map((item) => courseQueueKey(item.courseUrl)));
    let added = 0;
    for (const course of catalog) {
      const key = courseQueueKey(course.courseUrl);
      if (known.has(key)) continue;
      items.push({id:crypto.randomUUID(),...course,gnTrack:course.courseType === "GN" ? "theory" : null,status:"queued",createdAt:new Date().toISOString(),elapsedMs:0});
      known.add(key);added++;
    }
    await chrome.storage.local.set({auditQueue:items});
    catalogStatus.textContent = `อ่าน ${catalog.length.toLocaleString("th-TH")} วิชา · เพิ่มใหม่ ${added.toLocaleString("th-TH")} วิชา · ในคิวทั้งหมด ${items.length.toLocaleString("th-TH")} วิชา`;
    catalogFile.value = "";
    render();
  } catch (error) { catalogStatus.textContent = error.message || String(error); }
});

document.querySelector("#exportDashboard").addEventListener("click", async () => {
  const {auditQueue:items = []} = await state();
  const completed = items.filter((item) => item.status === "done" && item.reportId);
  const records = [];
  for (const item of completed) {
    const report = await loadStoredReport(item.reportId);
    if (report) records.push(buildDashboardRecord(report));
  }
  if (!records.length) { catalogStatus.textContent = "ยังไม่มีผลตรวจที่เสร็จแล้วสำหรับส่งออก"; return; }
  const blob = new Blob([JSON.stringify(records,null,2)],{type:"application/json;charset=utf-8"});
  const href = URL.createObjectURL(blob), anchor = document.createElement("a");
  anchor.href = href; anchor.download = `SPU-Audit-Dashboard-Batch-${new Date().toISOString().slice(0,10)}.json`; anchor.click();
  setTimeout(() => URL.revokeObjectURL(href),1000);
  catalogStatus.textContent = `ส่งออกผลตรวจ ${records.length.toLocaleString("th-TH")} วิชาแล้ว`;
});

document.querySelector("#run").addEventListener("click", async () => {
  const {auditQueue:items = []} = await state();
  if (!items.some((item) => item.status === "queued")) { status.textContent = "ไม่มีรายการที่รอตรวจ"; return; }
  const granted = await chrome.permissions.request({origins:MEDIA_PROVIDER_ORIGINS});
  if (!granted) { status.textContent = "ต้องอนุญาตสิทธิ์ผู้ให้บริการวิดีโอก่อนเริ่ม"; return; }
  const response = await chrome.runtime.sendMessage({type:"RUN_AUDIT_QUEUE"});
  status.textContent = response?.ok ? "เริ่มคิวแล้ว — ติดตามความคืบหน้าด้านล่าง" : "เริ่มคิวไม่สำเร็จ";
  render();
});

for (const [id, action] of [["pause","pause"],["stop","stop"],["resume","resume"]]) {
  document.querySelector("#" + id).addEventListener("click", async () => {
    const response = await chrome.runtime.sendMessage({type:"QUEUE_CONTROL",action});
    status.textContent = response?.ok ? "รับคำสั่งแล้ว" : "ส่งคำสั่งไม่สำเร็จ";
    render();
  });
}

document.querySelector("#clear").addEventListener("click", async () => {
  const {auditQueue:items = []} = await state();
  await chrome.storage.local.set({auditQueue:items.filter((item) => !["done","empty","failed","cancelled"].includes(item.status))});
  render();
});

list.addEventListener("click", async (event) => {
  const retry = event.target.closest("button[data-retry]");
  if (retry) {
    const {auditQueue:items = []} = await state();
    const item = items[Number(retry.dataset.retry)];
    item.status = "queued";
    item.error = null;
    item.resultMessage = null;
    item.elapsedMs = 0;
    item.attemptElapsedMs = 0;
    item.finishedAt = null;
    await chrome.storage.local.set({auditQueue:items});
    render();
    return;
  }
  const button = event.target.closest("button[data-open]");
  if (!button) return;
  const {auditQueue:items = []} = await state();
  const item = items[Number(button.dataset.open)];
  const report = await loadStoredReport(item.reportId);
  if (!report) { status.textContent = "ไม่พบรายงานในประวัติ"; return; }
  chrome.tabs.create({url:reportPageUrl(chrome.runtime.getURL("report.html"),report.id)});
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.auditProgress) seenProgressAt = Date.now();
  if (changes.auditQueue || changes.auditQueueControl || changes.auditProgress) render();
});
setInterval(() => render(), 1000);
document.querySelector("#diagnostics").onclick = async () => {
  const {auditDiagnostics = []} = await chrome.storage.local.get("auditDiagnostics");
  const payload = {extensionVersion:chrome.runtime.getManifest().version,createdAt:new Date().toISOString(),events:auditDiagnostics};
  const url = URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:"application/json"}));
  const anchor = document.createElement("a"); anchor.href=url; anchor.download="dlearning-audit-diagnostics.json"; anchor.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
};
render();
