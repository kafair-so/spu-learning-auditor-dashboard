import {requiresMediaReview,parsePodcastParts} from "./media-review.js";
import {podcastReviewKey} from "./podcast-review.js";
import {normalizeInstructorDecision} from "./instructor-review.js";
export async function installBatchReview(data) {
  const states=await chrome.storage.local.get(["reviewerChecklist","manualChecklist","reviewDrafts"]);
  const reviewState=JSON.stringify({instructor:normalizeInstructorDecision(states.reviewerChecklist?.[data.courseUrl]),manual:states.manualChecklist?.[data.courseUrl] || {}});
  if(data.finalResult?.reviewState !== reviewState) delete data.finalResult;
  let dirty=false,draftTimer=null;
  const root=document.querySelector("#report"),positionKey=`review-scroll:${data.id}`;
  const position=sessionStorage.getItem(positionKey);
  if(position!==null){sessionStorage.removeItem(positionKey);requestAnimationFrame(()=>scrollTo(0,Number(position)));}
  const toolbar=document.createElement("section");toolbar.className="batch-review-toolbar internal-review";
  toolbar.innerHTML='<button id="save-all-reviews">บันทึกและยืนยันทั้งหมด</button> <span id="draft-status" role="status">ยังไม่มีรายการแก้ไข</span> <button id="finalize-review">ยืนยันผลแจ้งอาจารย์</button>';
  root.prepend(toolbar);
  const message=document.querySelector("#draft-status");
  let scheduleDraft=()=>{};
  const markDirty=()=>{dirty=true;message.textContent="บันทึกฉบับร่างอัตโนมัติแล้ว";scheduleDraft();};
  for(const wrapper of root.querySelectorAll(".podcast-review")){
    const item=data.activities[Number(wrapper.dataset.podcastIndex)],seconds=Number(item.reviewerDurationSeconds||0);
    const m=document.createElement("input"),s=document.createElement("input");
    for(const [input,label,value] of [[m,"นาที",seconds?String(Math.floor(seconds/60)).padStart(2,"0"):""],[s,"วินาที",seconds?String(seconds%60).padStart(2,"0"):""]]){input.className="podcast-part";input.inputMode="numeric";input.maxLength=2;input.placeholder="00";input.setAttribute("aria-label",label);input.value=value;input.disabled=item.mediaType==="video";}
    m.classList.add("podcast-minutes");s.classList.add("podcast-seconds");
    wrapper.querySelector("label").replaceChildren("นาที ",m," : วินาที ",s);
    m.addEventListener("input",()=>{m.value=m.value.replace(/\D/g,"").slice(0,2);if(m.value.length===2){s.focus();s.select();}});
    s.addEventListener("input",()=>{s.value=s.value.replace(/\D/g,"").slice(0,2);});
    s.addEventListener("keydown",event=>{if(event.key==="Backspace"&&!s.value){event.preventDefault();m.focus();m.select();}});
    m.addEventListener("paste",event=>{const digits=event.clipboardData.getData("text").replace(/\D/g,"");if(digits.length===4){event.preventDefault();m.value=digits.slice(0,2);s.value=digits.slice(2);s.focus();wrapper.querySelector(".podcast-confirm").checked=false;markDirty();}});
  }
  // Rows are explicitly identified in report.js, not matched by translated titles.
  const topMediaReviewIndexes=new Set([...root.querySelectorAll(".media-review-choice")].map(select=>select.dataset.activityIndex));
  for(const cell of root.querySelectorAll("[data-media-review-index]")){
    const item=data.activities[Number(cell.dataset.mediaReviewIndex)];if(item.outOfRange||!requiresMediaReview(item))continue;
    if(topMediaReviewIndexes.has(cell.dataset.mediaReviewIndex))continue;
    const select=document.createElement("select");select.className="media-review-choice";select.dataset.activityIndex=cell.dataset.mediaReviewIndex;
    select.setAttribute("aria-label","การใช้เวลาคลิปนี้");
    for(const [value,label] of [["pending","ยังไม่ตัดสิน — ต้องตรวจสอบ"],["use","ใช้เวลาคิดคะแนน (ต้องมีเวลาจริง)"],["recording","ไม่นับ — สอนย้อนหลัง"],["activity","ไม่นับ — ประกอบกิจกรรม"],["supplementary","ไม่นับ — สื่อเสริม"]]){const option=document.createElement("option");option.value=value;option.textContent=label;select.append(option);}
    select.value=item.mediaReviewDecision||"pending";cell.append(document.createElement("br"),select);
    if(item.reviewExcluded){const note=document.createElement("div");note.textContent="ผู้ตรวจเลือกไม่นับเวลา — "+({recording:"สอนย้อนหลัง",activity:"ประกอบกิจกรรม",supplementary:"สื่อเสริม"})[item.mediaReviewDecision];cell.append(note);}
    else if(item.mediaReviewDecision==="use"){const note=document.createElement("div");note.textContent="ผู้ตรวจเลือกใช้เวลาที่อ่านได้คิดคะแนน";cell.append(note);}
  }
  const savedDraft=states.reviewDrafts?.[data.id];
  if(savedDraft){
    for(const wrapper of root.querySelectorAll(".podcast-review")){
      const item=data.activities[Number(wrapper.dataset.podcastIndex)],draft=savedDraft.podcasts?.[podcastReviewKey(item)];if(!draft)continue;
      wrapper.querySelector(".podcast-minutes").value=draft.minutes||"";wrapper.querySelector(".podcast-seconds").value=draft.seconds||"";
      const confirm=wrapper.querySelector(".podcast-confirm");if(!confirm.disabled)confirm.checked=Boolean(draft.confirmed);
    }
    for(const select of root.querySelectorAll(".media-review-choice,.classification-review-choice")){
      const item=data.activities[Number(select.dataset.activityIndex)],value=savedDraft.decisions?.[item?.href];if(value)select.value=value;
    }
    dirty=true;message.textContent="กู้คืนฉบับร่างที่บันทึกอัตโนมัติแล้ว";
  }
  const collectDraft=()=>{
    const podcasts={},decisions={};
    for(const wrapper of root.querySelectorAll(".podcast-review")){
      const item=data.activities[Number(wrapper.dataset.podcastIndex)];podcasts[podcastReviewKey(item)]={minutes:wrapper.querySelector(".podcast-minutes")?.value||"",seconds:wrapper.querySelector(".podcast-seconds")?.value||"",confirmed:Boolean(wrapper.querySelector(".podcast-confirm")?.checked)};
    }
    for(const select of root.querySelectorAll(".media-review-choice,.classification-review-choice")){const item=data.activities[Number(select.dataset.activityIndex)];if(item?.href)decisions[item.href]=select.value;}
    return {podcasts,decisions,updatedAt:Date.now()};
  };
  scheduleDraft=()=>{clearTimeout(draftTimer);draftTimer=setTimeout(async()=>{const {reviewDrafts={}}=await chrome.storage.local.get("reviewDrafts");reviewDrafts[data.id]=collectDraft();await chrome.storage.local.set({reviewDrafts});},350);};
  const panel=document.querySelector(".score-card")?.lastElementChild;
  if(panel&&data.finalResult){panel.replaceChildren();panel.className=`score-result ${data.finalResult.status}`;const result=document.createElement("strong");result.className="score-status-badge";result.innerHTML=`<span aria-hidden="true">${data.finalResult.status==="pass"?"✓":"×"}</span>${data.finalResult.status==="pass"?"ผ่าน":"ไม่ผ่าน"}`;panel.append(result);}
  document.body?.classList.toggle("report-finalized",Boolean(data.finalResult));
  const pending=root.querySelector(".teacher-summary h3");
  if(pending){const internal=document.createElement("section");internal.className="internal-review week-card";const list=pending.nextElementSibling;internal.append(pending);if(list)internal.append(list);root.prepend(internal);}
  root.addEventListener("input",event=>{if(event.target.matches(".podcast-part")){event.target.closest(".podcast-review").querySelector(".podcast-confirm").checked=false;markDirty();}});
  root.addEventListener("change",event=>{if(event.target.matches(".podcast-confirm,.media-review-choice,.classification-review-choice"))markDirty();});
  root.addEventListener("change",event=>{if(event.target.matches(".manual-check,.instructor-decision")){delete data.finalResult;panel?.replaceChildren();document.body?.classList.remove("report-finalized");message.textContent="ข้อมูลผู้ตรวจเปลี่ยน กรุณายืนยันผลแจ้งอาจารย์ใหม่";}});
  window.addEventListener("beforeprint",()=>document.body?.classList.toggle("report-finalized",Boolean(data.finalResult)&&!dirty));
  window.addEventListener("beforeunload",event=>{if(dirty){event.preventDefault();event.returnValue="";}});
  const send=async(type,extra,button)=>{button.disabled=true;try{const response=await chrome.runtime.sendMessage({type,reportId:data.id,courseUrl:data.courseUrl,...extra});if(!response.ok)throw new Error(response.error);clearTimeout(draftTimer);const {reviewDrafts={}}=await chrome.storage.local.get("reviewDrafts");delete reviewDrafts[data.id];await chrome.storage.local.set({reviewDrafts});dirty=false;sessionStorage.setItem(positionKey,String(scrollY));location.reload();}catch(error){message.textContent=error.message;button.disabled=false;}};
  document.querySelector("#save-all-reviews").onclick=async event=>{
    const podcasts=[],videos=[],classifications=[];let invalid=null;
    for(const wrapper of root.querySelectorAll(".podcast-review")){
      const item=data.activities[Number(wrapper.dataset.podcastIndex)];if(item.mediaType==="video")continue;
      const m=wrapper.querySelector(".podcast-minutes"),s=wrapper.querySelector(".podcast-seconds"),confirmed=wrapper.querySelector(".podcast-confirm").checked;
      const seconds=!m.value&&!s.value?0:parsePodcastParts(m.value,s.value);
      if(seconds===null||confirmed&&!seconds){wrapper.querySelector(".podcast-message").textContent="กรอกนาที 00–99 และวินาที 00–59 ให้ครบ";invalid ||= m;continue;}
      podcasts.push({key:podcastReviewKey(item),seconds,confirmed});
    }
    if(invalid){invalid.focus();return;}
    for(const select of root.querySelectorAll(".media-review-choice"))videos.push({key:data.activities[Number(select.dataset.activityIndex)].href,decision:select.value});
    for(const select of root.querySelectorAll(".classification-review-choice"))classifications.push({key:data.activities[Number(select.dataset.activityIndex)].href,decision:select.value});
    await send("SAVE_MEDIA_REVIEW_BATCH",{podcasts,videos,classifications},event.target);
  };
  document.querySelector("#finalize-review").onclick=async event=>{if(dirty){message.textContent="กรุณาบันทึกรายการแก้ไขก่อนยืนยันผล";return;}await send("FINALIZE_REVIEW",{},event.target);};
  return ()=>dirty;
}
