import { classifyActivity, isTeachingPlanFile } from "./classifier.js";
import { learningPlatformName } from "./platform.js";
import { initTheme } from "./theme.js";
import { initI18n, addLanguageMenu } from "./i18n.js";
await initI18n();
await addLanguageMenu();
await initTheme();

const escapeHtml = (value) => String(value || "").replace(/[&<>"]/g, (char) => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"})[char]);
const labels = {video:"วิดีโอล่วงหน้า",video_candidate:"วิดีโอที่ต้องยืนยัน",recording:"บันทึกสอนสด/ย้อนหลัง",activity_video:"วิดีโอประกอบกิจกรรม (ไม่นับ)",podcast:"Podcast (ต้องยืนยันว่าเป็นคลิปเสียง)",pre_quiz:"Pre-test",post_quiz:"Post-test",quiz:"Quiz ภายใน Moodle (ไม่นับเป็น Assignment)",assignment:"Assignment",file:"ไฟล์ PDF/เอกสาร",ai_tutor:"AI Tutor",url:"ลิงก์อื่น"};
const {lastStructureScan: scan} = await chrome.storage.local.get("lastStructureScan");
const course = document.querySelector("#course"), rows = document.querySelector("#rows"), empty = document.querySelector("#empty"), summary = document.querySelector("#summary");
if (!scan?.activities?.length) { empty.hidden=false; document.querySelector("#export").hidden=true; }
else {
  const platformName = scan.platform || learningPlatformName(scan.courseUrl);
  document.title = `ตรวจโครงสร้าง ${platformName}`;
  document.querySelector(".eyebrow").textContent = `${platformName} Read-only Auditor`;
  course.textContent = `${scan.courseTitle} · อ่านเมื่อ ${new Date(scan.capturedAt).toLocaleString("th-TH")}`;
  const coverage = scan.coverage || {};
  const coverageText = coverage.structurallyComplete === false
    ? `โครงสร้างไม่เพียงพอสำหรับตรวจ · พบ Section การสอน ${coverage.courseSectionCount ?? 0} Section และกิจกรรมที่ไม่ใช่ Announcements ${coverage.nonForumActivityCount ?? 0} รายการ`
    : coverage.reachedEnd === true
      ? `อ่านถึงท้ายหน้าแล้ว · พบ Section การสอน ${coverage.courseSectionCount ?? coverage.sectionCount ?? 0} Section`
      : coverage.reachedEnd === false
      ? `ยังอ่านไม่ถึงท้ายหน้า · พบ ${coverage.sectionCount ?? 0} Section (ห้ามใช้ผลนี้ตัดสินว่าไม่มี)`
      : "ข้อมูลนี้มาจากตัวอ่านรุ่นเดิมที่ยังไม่ได้บันทึกความครอบคลุม";
  summary.textContent = `พบ ${scan.activities.length} รายการ · ${coverageText}`;
  summary.classList.add(coverage.structurallyComplete === false || coverage.reachedEnd === false ? "tone-warning" : "tone-success");
  rows.innerHTML = scan.activities.map((item) => {
    const kind = item.href.includes("/mod/resource/") && isTeachingPlanFile(item) ? "แผนการสอน PDF" : (labels[classifyActivity(item)] || "อื่น ๆ");
    return `<tr><td>${escapeHtml(item.section)}</td><td>${escapeHtml(item.groupContext) || '<span class="muted">ไม่มีป้ายกลุ่ม</span>'}</td><td>${escapeHtml(item.title)}</td><td>${escapeHtml(kind)}</td></tr>`;
  }).join("");
}
document.querySelector("#export").addEventListener("click", () => {
  const payload = JSON.stringify(scan, null, 2);
  const url = URL.createObjectURL(new Blob([payload], {type:"application/json"}));
  const platformSlug = learningPlatformName(scan?.courseUrl) === "i-Learning" ? "ilearning" : "dlearning";
  const link = Object.assign(document.createElement("a"), {href:url, download:`${platformSlug}-structure-scan.json`});
  link.click(); URL.revokeObjectURL(url);
});
