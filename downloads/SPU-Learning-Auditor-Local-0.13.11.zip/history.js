import { initTheme } from "./theme.js";
import { initI18n, addLanguageMenu } from "./i18n.js";
import {deleteStoredReport,deleteStoredReports,listStoredReports,reportPageUrl,setStoredReportPinned} from "./report-store.js";
await initI18n(); await addLanguageMenu(); await initTheme();

const list=document.querySelector("#list"),search=document.querySelector("#search"),compare=document.querySelector("#compare"),comparison=document.querySelector("#comparison"),count=document.querySelector("#count");
const selectAll=document.querySelector("#selectAll"),clearSelection=document.querySelector("#clearSelection"),deleteSelected=document.querySelector("#deleteSelected"),selectionStatus=document.querySelector("#selectionStatus");
let recentReports=await listStoredReports();
const selected=new Set();
const esc=value=>String(value||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const reportId=(report,index)=>report.id||`${report.courseUrl||"course"}-${report.createdAt||index}`;
const problems=report=>Number(report.problemCount||0),weeks=report=>Number(report.weekCount||0);

function visibleReports(){const query=search.value.trim().toLowerCase();return recentReports.map((report,index)=>({report,index,id:reportId(report,index)})).filter(({report})=>!query||[report.courseTitle,report.courseUrl,report.courseType,report.courseCode].join(" ").toLowerCase().includes(query));}
function updateSelectionControls(visible){const amount=selected.size;selectionStatus.textContent=amount?`เลือกแล้ว ${amount} รายการ — ลบพร้อมกันได้ หรือเลือกให้เหลือ 2 รายการเพื่อเปรียบเทียบ`:"ยังไม่ได้เลือกรายงาน";compare.disabled=amount!==2;clearSelection.disabled=amount===0;deleteSelected.disabled=amount===0;deleteSelected.textContent=amount?`ลบที่เลือก (${amount})`:"ลบที่เลือก";selectAll.disabled=!visible.length||visible.every(({id})=>selected.has(id));}
function render(){
  const visible=visibleReports();count.textContent=`${recentReports.length} รายการ`;updateSelectionControls(visible);
  if(!visible.length){list.innerHTML='<p class="empty">ยังไม่มีรายงานที่ตรงกับคำค้น</p>';return;}
  list.innerHTML=visible.map(({report,index,id})=>`<section class="card ${report.pinned?"pinned":""} ${selected.has(id)?"selected":""}"><label class="select"><input type="checkbox" data-select="${esc(id)}" ${selected.has(id)?"checked":""}><span>เลือก</span></label><div class="body"><div class="title"><strong>${esc(report.courseTitle||"ไม่ระบุชื่อวิชา")}</strong>${report.pinned?'<span class="badge">ปักหมุด</span>':""}</div><div class="meta">${esc(report.courseType||"Learning")} · ${esc(report.credits||"-")} หน่วยกิต · ${new Date(report.createdAt).toLocaleString("th-TH")}</div><div class="stats"><span>${weeks(report)} ครั้ง</span><span>${problems(report)} จุดที่ต้องตรวจ</span><span>รุ่น ${esc(report.extensionVersion||"-")}</span></div></div><div class="actions"><button data-action="open" data-index="${index}" class="primary">เปิดรายงาน</button><button data-action="pin" data-index="${index}">${report.pinned?"เลิกปักหมุด":"ปักหมุด"}</button><button data-action="delete" data-index="${index}" class="danger">ลบ</button></div></section>`).join("");
}
search.addEventListener("input",render);
list.addEventListener("change",event=>{const input=event.target.closest("input[data-select]");if(!input)return;input.checked?selected.add(input.dataset.select):selected.delete(input.dataset.select);render();});
selectAll.addEventListener("click",()=>{for(const {id} of visibleReports())selected.add(id);render();});
clearSelection.addEventListener("click",()=>{selected.clear();render();});
deleteSelected.addEventListener("click",async()=>{const ids=recentReports.map((report,index)=>({id:report.id,selectionId:reportId(report,index)})).filter(({selectionId})=>selected.has(selectionId)).map(({id})=>id).filter(Boolean);if(!ids.length||!confirm(`ลบประวัติที่เลือก ${ids.length} รายการพร้อมกันหรือไม่`))return;deleteSelected.disabled=true;await deleteStoredReports(ids);selected.clear();recentReports=await listStoredReports();comparison.hidden=true;render();});
list.addEventListener("click",async event=>{const button=event.target.closest("button[data-action]");if(!button)return;const index=Number(button.dataset.index),report=recentReports[index];if(!report)return;if(button.dataset.action==="open")return chrome.tabs.create({url:reportPageUrl(chrome.runtime.getURL("report.html"),report.id)});button.disabled=true;if(button.dataset.action==="pin")await setStoredReportPinned(report.id,!report.pinned);else if(button.dataset.action==="delete"){if(!confirm(`ลบรายงาน “${report.courseTitle||"รายการนี้"}” หรือไม่`)){button.disabled=false;return;}selected.delete(reportId(report,index));await deleteStoredReport(report.id);}recentReports=await listStoredReports();render();});
compare.addEventListener("click",()=>{const reports=recentReports.filter((r,i)=>selected.has(reportId(r,i)));if(reports.length!==2)return;comparison.hidden=false;comparison.innerHTML=`<div class="compare-head"><h2>เปรียบเทียบรายงาน</h2><button id="closeCompare">ปิด</button></div><div class="compare-grid">${reports.map(r=>`<article><strong>${esc(r.courseTitle)}</strong><dl><div><dt>ตรวจเมื่อ</dt><dd>${new Date(r.createdAt).toLocaleString("th-TH")}</dd></div><div><dt>จำนวนครั้ง</dt><dd>${weeks(r)}</dd></div><div><dt>จุดที่ต้องตรวจ</dt><dd>${problems(r)}</dd></div><div><dt>แพลตฟอร์ม</dt><dd>${esc(r.courseType||"-")}</dd></div></dl></article>`).join("")}</div>`;comparison.querySelector("#closeCompare").onclick=()=>{comparison.hidden=true;};});
render();
