const ACTIVE_PRIORITY = {running:4,queued:3,paused:2};

export function courseQueueKey(value) {
  try {
    const url = new URL(String(value || "").trim());
    const host = url.hostname.toLowerCase().replace(/^www\./, "");
    const courseId = String(url.searchParams.get("id") || "").trim();
    if (courseId && /(?:^|\.)(?:dlearning|ilearning)\.spu\.ac\.th$/i.test(host)) {
      return `${host}|course:${courseId}`;
    }
    url.hash = "";
    for (const key of [...url.searchParams.keys()]) {
      if (/^(?:utm_|fbclid|gclid|ref|source)/i.test(key)) url.searchParams.delete(key);
    }
    url.pathname = url.pathname.replace(/\/+$/, "") || "/";
    url.hostname = host;
    url.searchParams.sort();
    return url.href;
  } catch {
    return String(value || "").trim().replace(/[?#].*$/, "").replace(/\/+$/, "").toLowerCase();
  }
}

const timestamp = (item) => {
  const values = [item?.finishedAt,item?.updatedAt,item?.attemptStartedAt,item?.startedAt,item?.createdAt]
    .map((value) => typeof value === "number" ? value : Date.parse(value || ""))
    .filter(Number.isFinite);
  return values.length ? Math.max(...values) : 0;
};

function preferredQueueItem(existing, incoming) {
  const existingPriority = ACTIVE_PRIORITY[existing?.status] || 0;
  const incomingPriority = ACTIVE_PRIORITY[incoming?.status] || 0;
  if (existingPriority !== incomingPriority) return incomingPriority > existingPriority ? incoming : existing;
  // For active duplicates keep the job that entered the queue first. For
  // finished duplicates keep the newest result card; report history remains
  // stored separately and is not removed by queue cleanup.
  if (existingPriority > 0) return timestamp(incoming) && timestamp(incoming) < timestamp(existing) ? incoming : existing;
  return timestamp(incoming) >= timestamp(existing) ? incoming : existing;
}

export function deduplicateAuditQueue(items = []) {
  const result = [];
  const indexByKey = new Map();
  for (const item of Array.isArray(items) ? items : []) {
    const key = courseQueueKey(item?.courseUrl);
    if (!key) { result.push(item); continue; }
    if (!indexByKey.has(key)) {
      indexByKey.set(key,result.length);
      result.push(item);
      continue;
    }
    const index = indexByKey.get(key);
    result[index] = preferredQueueItem(result[index],item);
  }
  return result;
}
