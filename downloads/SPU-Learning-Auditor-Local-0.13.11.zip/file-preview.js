export function filePreviewIssueFromEvidence(value) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  if (/the file is too large to open|please try (?:again )?with a smaller file|file (?:is|was) too large to (?:open|preview)|ไฟล์(?:นี้)?มีขนาดใหญ่เกิน(?:ไป)?(?:ที่จะ)?(?:เปิด|แสดงตัวอย่าง)/i.test(text)) {
    return {
      previewStatus:"file_too_large",
      previewAccessible:false,
      previewNote:"ปลายทางแจ้งว่าไฟล์ใหญ่เกินกว่าจะเปิดดูตัวอย่าง"
    };
  }
  return null;
}
