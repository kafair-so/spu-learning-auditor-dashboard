import { FILE_GROUP_PATTERN, isEndActivityTitle } from "./rules.js";

export const MISPLACED_DOCUMENT_MESSAGE = "พบเอกสารอยู่ใน Assignment ซึ่งเป็นพื้นที่ส่งงาน กรุณาวางเป็น Moodle File (PDF) หรือลิงก์ตรงไปยังไฟล์เอกสาร";

export function looksLikeTeachingDocumentAssignment(activity) {
  if (!/\/mod\/assign\/view\.php/i.test(String(activity?.href || ""))) return false;
  const title = String(activity?.title || "");
  // An explicitly named Assignment remains a task even when its brief contains
  // a PDF/PPTX reference file or it sits below a copied document label.
  if (isEndActivityTitle(title)) return false;
  return FILE_GROUP_PATTERN.test(`${title} ${activity?.groupContext || ""}`);
}
