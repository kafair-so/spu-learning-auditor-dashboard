import { isLmsHost } from "./platform.js";

export function usableExternalTarget(value) {
  try {
    const parsed = new URL(String(value || "").replace(/&amp;/g, "&").replaceAll("\\/", "/"));
    const host = parsed.hostname.toLowerCase();
    if (!/^https?:$/.test(parsed.protocol) || !host || isLmsHost(host)) return null;
    // Facebook's outbound-link page blocks extension-origin fetches with CORS.
    // Its `u` parameter already contains the real destination, so unwrap it
    // locally and never contact the Facebook redirector.
    if (["l.facebook.com", "lm.facebook.com"].includes(host) && parsed.pathname === "/l.php") {
      const target = parsed.searchParams.get("u") || parsed.searchParams.get("url");
      return target && target !== value ? usableExternalTarget(target) : null;
    }
    if (/(?:^|\.)(?:docs\.moodle\.org|googletagmanager\.com|google-analytics\.com|doubleclick\.net|analytics\.google\.com|facebook\.com|connect\.facebook\.net|clarity\.ms|gstatic\.com|googleapis\.com)$/i.test(host)) return null;
    if (/(?:favicon|pixel|spacer|logo|sprite|thumbnail|avatar|loading|spinner)|\.(?:css|js|woff2?|ico)(?:$|[?#])/i.test(parsed.href)) return null;
    return parsed.href;
  } catch { return null; }
}

// A rejected URL such as docs.moodle.org is neither an LMS activity nor an
// auditable external destination. Once usableExternalTarget has rejected such
// an external URL, fetching it cannot reveal a useful redirect and only emits
// a CORS error in chrome://extensions.
export function shouldSkipExternalFetch(value) {
  try {
    const parsed = new URL(String(value || ""));
    return /^https?:$/.test(parsed.protocol) && !isLmsHost(parsed.hostname) && !usableExternalTarget(parsed.href);
  } catch { return true; }
}

export function externalTargetScore(value) {
  const lower = String(value || "").toLowerCase();
  let points = 0;
  if (/photos\.app\.goo\.gl|photos\.google\.com/.test(lower)) points += 140;
  if (/drive\.google\.com\/file\/d\//.test(lower)) points += 130;
  if (/1drv\.ms\/|onedrive\.live\.com\//.test(lower)) points += 130;
  if (/notebook(?:lm)?\.google\.com\/(?:notebook|artifact)/.test(lower)) points += 125;
  if (/docs\.google\.com\/(?:forms|presentation|document|spreadsheets)/.test(lower)) points += 110;
  if (/canva\.link\/|(?:www\.)?canva\.com\/|gamma\.app\//.test(lower)) points += 110;
  if (/loom\.com\/share\//.test(lower)) points += 110;
  if (/youtube|vimeo|vidyard|wistia|kaltura|sharepoint/.test(lower)) points += 90;
  if (/\.(?:pdf|mp4|webm|m4v|mov|m3u8|mp3|m4a)(?:$|[?#])/.test(lower)) points += 80;
  if (/\/(?:file|share|watch|view|artifact)\b/.test(lower)) points += 20;
  return points;
}

export function rankExternalTargets(values) {
  return [...new Set((values || []).map(usableExternalTarget).filter(Boolean))]
    .map((target, index) => ({ target, index, score:externalTargetScore(target) }))
    .sort((left, right) => right.score - left.score || left.index - right.index);
}
