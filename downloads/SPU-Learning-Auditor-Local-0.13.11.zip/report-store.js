// Keep enough reports for three complete snapshots of the 133-course catalog.
// Supabase remains the source of truth; this local history prevents a long
// batch from evicting early reports before the operator exports the batch.
export const REPORT_LIMIT = 500;
const DB_NAME = "spu-learning-auditor";
const DB_VERSION = 1;
const REPORT_STORE = "reports";
const STORAGE_VERSION = 1;
let migrationPromise = null;

export const reportPageUrl = (baseUrl, reportId) => reportId
  ? `${baseUrl}?reportId=${encodeURIComponent(reportId)}` : baseUrl;

// Compatibility helpers for pre-0.11 data and pure tests.
export function reportById(stored, reportId) {
  if (!reportId) return stored.latestReport || null;
  return (stored.recentReports || []).find((report) => report.id === reportId)
    || (stored.latestReport?.id === reportId ? stored.latestReport : null);
}

export function mergedReportHistory(report, recentReports = []) {
  const merged = [report, ...recentReports.filter((item) => item.id !== report.id)];
  const pinned = merged.filter((item) => item.pinned);
  const ordinary = merged.filter((item) => !item.pinned);
  return [...pinned, ...ordinary].slice(0, REPORT_LIMIT);
}

export function compactReport(report) {
  return { ...report, activities:(report.activities || []).map(({html, ...activity}) => activity) };
}

export function reportIndexEntry(report) {
  return {
    id:report.id, courseTitle:report.courseTitle, courseUrl:report.courseUrl,
    courseType:report.courseType, gnTrack:report.gnTrack || null,
    credits:report.credits, createdAt:report.createdAt,
    extensionVersion:report.extensionVersion || report.version || null,
    pinned:Boolean(report.pinned), weekCount:(report.weeks || []).length,
    problemCount:(report.weeks || []).flatMap((week) => week.checklist || []).filter((item) => item.status !== "pass").length
  };
}

export function mergedReportIndex(entry, current = []) {
  const merged = [entry, ...current.filter((item) => item.id !== entry.id)];
  return [...merged.filter((item) => item.pinned), ...merged.filter((item) => !item.pinned)];
}

export function reportRotation(index, incomingId) {
  const kept = [...index], removed = [];
  while (kept.length > REPORT_LIMIT) {
    const candidates = kept.filter((item) => item.id !== incomingId);
    const removable = candidates.filter((item) => !item.pinned);
    const pool = removable.length ? removable : candidates;
    const oldest = [...pool].sort((a, b) => {
      const byDate = String(a.createdAt || "").localeCompare(String(b.createdAt || ""));
      return byDate || kept.indexOf(b) - kept.indexOf(a);
    })[0];
    if (!oldest) break;
    removed.push(oldest);
    kept.splice(kept.findIndex((item) => item.id === oldest.id), 1);
  }
  return {kept, removed};
}

const requestResult = (request) => new Promise((resolve, reject) => {
  request.onsuccess = () => resolve(request.result);
  request.onerror = () => reject(request.error || new Error("อ่านฐานข้อมูลรายงานไม่สำเร็จ"));
});
const transactionDone = (transaction) => new Promise((resolve, reject) => {
  transaction.oncomplete = () => resolve();
  transaction.onabort = () => reject(transaction.error || new Error("ฐานข้อมูลยกเลิกการบันทึก"));
  transaction.onerror = () => reject(transaction.error || new Error("บันทึกฐานข้อมูลรายงานไม่สำเร็จ"));
});

function openReportDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(REPORT_STORE)) {
        const store = database.createObjectStore(REPORT_STORE, {keyPath:"id"});
        store.createIndex("createdAt", "createdAt");
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("เปิดฐานข้อมูลรายงานไม่สำเร็จ"));
  });
}

async function putReports(reports) {
  if (!reports.length) return;
  const database = await openReportDatabase();
  try {
    const transaction = database.transaction(REPORT_STORE, "readwrite");
    const done = transactionDone(transaction);
    const store = transaction.objectStore(REPORT_STORE);
    for (const report of reports) store.put(compactReport(report));
    await done;
  } finally { database.close(); }
}

async function allReports() {
  const database = await openReportDatabase();
  try {
    const transaction = database.transaction(REPORT_STORE, "readonly");
    return await requestResult(transaction.objectStore(REPORT_STORE).getAll());
  } finally { database.close(); }
}

async function getReportDocument(id) {
  if (!id) return null;
  const database = await openReportDatabase();
  try {
    const transaction = database.transaction(REPORT_STORE, "readonly");
    return await requestResult(transaction.objectStore(REPORT_STORE).get(id)) || null;
  } finally { database.close(); }
}

async function deleteReportDocument(id) {
  const database = await openReportDatabase();
  try {
    const transaction = database.transaction(REPORT_STORE, "readwrite");
    const done = transactionDone(transaction);
    transaction.objectStore(REPORT_STORE).delete(id);
    await done;
  } finally { database.close(); }
}

async function deleteReportDocuments(ids) {
  const uniqueIds = [...new Set((ids || []).filter(Boolean))];
  if (!uniqueIds.length) return;
  const database = await openReportDatabase();
  try {
    const transaction = database.transaction(REPORT_STORE, "readwrite");
    const done = transactionDone(transaction);
    const store = transaction.objectStore(REPORT_STORE);
    for (const id of uniqueIds) store.delete(id);
    await done;
  } finally { database.close(); }
}

const quotaError = (error) => /quota|QuotaBytes|QUOTA_EXCEEDED/i.test(String(error?.message || error || ""));
async function writeIndex(values) {
  try { await chrome.storage.local.set(values); }
  catch (error) {
    if (!quotaError(error)) throw error;
    const {auditDiagnostics = []} = await chrome.storage.local.get("auditDiagnostics");
    await chrome.storage.local.remove(["lastStructureScan", "lastH5pInspection"]);
    await chrome.storage.local.set({auditDiagnostics:auditDiagnostics.slice(-40)}).catch(() => {});
    await chrome.storage.local.set(values);
  }
}

export async function ensureReportStoreMigrated() {
  if (typeof indexedDB === "undefined") return false;
  if (migrationPromise) return migrationPromise;
  migrationPromise = (async () => {
    const stored = await chrome.storage.local.get(["reportStorageVersion", "reportIndex", "latestReportId", "latestReport", "recentReports"]);
    const legacy = [];
    for (const report of [stored.latestReport, ...(stored.recentReports || [])]) {
      if (report?.id && !legacy.some((item) => item.id === report.id)) legacy.push(report);
    }
    if (legacy.length) {
      await putReports(legacy);
      let index = stored.reportIndex || [];
      for (const report of [...legacy].reverse()) index = mergedReportIndex(reportIndexEntry(report), index);
      await chrome.storage.local.remove(["latestReport", "recentReports"]);
      await writeIndex({reportStorageVersion:STORAGE_VERSION, reportIndex:index, latestReportId:stored.latestReport?.id || stored.latestReportId || index[0]?.id || null});
    } else if (stored.reportStorageVersion !== STORAGE_VERSION || !Array.isArray(stored.reportIndex)) {
      const reports = (await allReports()).sort((a,b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")));
      await writeIndex({reportStorageVersion:STORAGE_VERSION, reportIndex:reports.map(reportIndexEntry), latestReportId:stored.latestReportId || reports[0]?.id || null});
    }
    // Repair an interrupted two-stage save automatically. A report document
    // committed just before the lightweight index write is recovered here;
    // a stale index left after deletion is removed without touching reports.
    const documents = await allReports();
    const byId = new Map(documents.map((report) => [report.id, report]));
    const current = await chrome.storage.local.get(["reportIndex", "latestReportId"]);
    const orderedIds = (current.reportIndex || []).map((entry) => entry.id).filter((id) => byId.has(id));
    const missing = documents.filter((report) => !orderedIds.includes(report.id)).sort((a,b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")));
    const repaired = [...orderedIds.map((id) => reportIndexEntry(byId.get(id))), ...missing.map(reportIndexEntry)];
    const latestReportId = byId.has(current.latestReportId) ? current.latestReportId : repaired[0]?.id || null;
    await writeIndex({reportStorageVersion:STORAGE_VERSION, reportIndex:repaired, latestReportId});
    return true;
  })().catch((error) => { migrationPromise = null; throw error; });
  return migrationPromise;
}

export async function loadStoredReport(reportId = null) {
  if (typeof indexedDB === "undefined") {
    return reportById(await chrome.storage.local.get(["latestReport", "recentReports"]), reportId);
  }
  await ensureReportStoreMigrated();
  const {latestReportId = null} = await chrome.storage.local.get("latestReportId");
  return getReportDocument(reportId || latestReportId);
}

export async function listStoredReports() {
  if (typeof indexedDB === "undefined") {
    const {recentReports = []} = await chrome.storage.local.get("recentReports");
    return recentReports.map(reportIndexEntry);
  }
  await ensureReportStoreMigrated();
  const {reportIndex = []} = await chrome.storage.local.get("reportIndex");
  if (reportIndex.length) return reportIndex;
  const reports = (await allReports()).sort((a,b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")));
  const rebuilt = reports.map(reportIndexEntry);
  if (rebuilt.length) await writeIndex({reportIndex:rebuilt, latestReportId:rebuilt[0].id});
  return rebuilt;
}

export async function saveStoredReport(report, {promoteLatest = true} = {}) {
  await ensureReportStoreMigrated();
  const compact = compactReport(report);
  const stored = await chrome.storage.local.get(["reportIndex", "latestReportId"]);
  const index = stored.reportIndex || [];
  await putReports([compact]);
  const rotation = reportRotation(mergedReportIndex(reportIndexEntry(compact), index), compact.id);
  const nextIndex = rotation.kept;
  for (const removed of rotation.removed) await deleteReportDocument(removed.id);
  const latestReportId = promoteLatest || stored.latestReportId === compact.id ? compact.id : stored.latestReportId;
  await writeIndex({reportIndex:nextIndex, latestReportId});
  if (rotation.removed.length) {
    const {reviewDrafts = {}} = await chrome.storage.local.get("reviewDrafts");
    let changed = false;
    for (const removed of rotation.removed) if (reviewDrafts[removed.id]) { delete reviewDrafts[removed.id]; changed = true; }
    if (changed) await chrome.storage.local.set({reviewDrafts});
  }
  await updateStorageHealth();
  return compact;
}

export async function assertCanCreateReport() {
  return true;
}

export async function deleteStoredReport(id) {
  return deleteStoredReports([id]);
}

export async function deleteStoredReports(ids) {
  await ensureReportStoreMigrated();
  const uniqueIds = [...new Set((ids || []).filter(Boolean))];
  if (!uniqueIds.length) return 0;
  const removedIds = new Set(uniqueIds);
  const {reportIndex = [], latestReportId = null} = await chrome.storage.local.get(["reportIndex", "latestReportId"]);
  await deleteReportDocuments(uniqueIds);
  const next = reportIndex.filter((item) => !removedIds.has(item.id));
  await writeIndex({reportIndex:next, latestReportId:removedIds.has(latestReportId) ? next[0]?.id || null : latestReportId});
  const {reviewDrafts = {}} = await chrome.storage.local.get("reviewDrafts");
  let draftsChanged = false;
  for (const id of uniqueIds) if (reviewDrafts[id]) { delete reviewDrafts[id]; draftsChanged = true; }
  if (draftsChanged) await chrome.storage.local.set({reviewDrafts});
  await updateStorageHealth();
  return reportIndex.length - next.length;
}

export async function setStoredReportPinned(id, pinned) {
  const report = await loadStoredReport(id);
  if (!report) return null;
  report.pinned = Boolean(pinned);
  await putReports([report]);
  const {reportIndex = []} = await chrome.storage.local.get("reportIndex");
  await writeIndex({reportIndex:mergedReportIndex(reportIndexEntry(report), reportIndex)});
  return report;
}

export async function updateStorageHealth() {
  let estimate = null;
  try { estimate = await navigator.storage?.estimate?.(); } catch { /* health is advisory */ }
  const {reportIndex = []} = await chrome.storage.local.get("reportIndex");
  const health = {reportCount:reportIndex.length, reportLimit:REPORT_LIMIT, usage:Number(estimate?.usage || 0), quota:Number(estimate?.quota || 0), checkedAt:Date.now()};
  health.level = health.quota && health.usage / health.quota >= .9 ? "critical" : health.quota && health.usage / health.quota >= .75 ? "warning" : "ok";
  await chrome.storage.local.set({reportStorageHealth:health}).catch(() => {});
  return health;
}
