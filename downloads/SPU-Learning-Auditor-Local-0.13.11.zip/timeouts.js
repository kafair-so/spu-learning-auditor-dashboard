export class AuditStepTimeoutError extends Error {
  constructor(label, timeoutMs) {
    super(`${label} เกินเวลาที่กำหนด ${Math.ceil(timeoutMs / 1000)} วินาที`);
    this.name = "AuditStepTimeoutError";
    this.code = "AUDIT_STEP_TIMEOUT";
    this.timeoutMs = timeoutMs;
    this.stepLabel = label;
  }
}

// Chrome APIs and third-party pages can occasionally leave a Promise pending
// forever. Every external operation passes through this helper so one resource
// cannot stop a course containing hundreds of items.
export async function withDeadline(task, timeoutMs, label = "ขั้นตอนตรวจ") {
  let timer;
  const operation = typeof task === "function" ? Promise.resolve().then(task) : Promise.resolve(task);
  try {
    return await Promise.race([
      operation,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new AuditStepTimeoutError(label, timeoutMs)), timeoutMs);
      })
    ]);
  } finally {
    clearTimeout(timer);
  }
}

export function isAuditStepTimeout(error) {
  return error?.code === "AUDIT_STEP_TIMEOUT" || error?.name === "AuditStepTimeoutError";
}
