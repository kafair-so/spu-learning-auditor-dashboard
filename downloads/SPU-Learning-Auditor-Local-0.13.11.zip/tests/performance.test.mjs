import assert from "node:assert/strict";
import { createLimiter, interleaveByKey, runBounded } from "../audit-scheduler.js";
import { inspectionGoalStatus, summarizeInspectionTiming } from "../performance-summary.js";

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

let active = 0;
let maximumActive = 0;
const seen = [];
const startedAt = Date.now();
const result = await runBounded(Array.from({ length:12 }, (_, index) => index), async (item) => {
  active += 1;
  maximumActive = Math.max(maximumActive, active);
  await wait(20);
  seen.push(item);
  active -= 1;
}, { concurrency:2 });
const elapsed = Date.now() - startedAt;

assert.equal(result.started, 12);
assert.equal(result.skipped, 0);
assert.equal(maximumActive, 2, "the scheduler must never exceed two simultaneous inspections");
assert.deepEqual([...seen].sort((a, b) => a - b), Array.from({ length:12 }, (_, index) => index), "every activity must be inspected exactly once");
assert.ok(elapsed >= 100 && elapsed < 400, `two workers should reduce 12 × 20 ms wall time; measured ${elapsed} ms`);

const skipped = [];
let falselyStarted = 0;
const budgetResult = await runBounded([1, 2, 3], async () => { falselyStarted += 1; }, {
  concurrency:2,
  deadline:Date.now() - 1,
  onDeadline:async (item) => skipped.push(item)
});
assert.equal(falselyStarted, 0, "expired course budgets must not begin more external work");
assert.deepEqual(skipped, [1, 2, 3]);
assert.equal(budgetResult.skipped, 3);

let tabActive = 0;
let tabMaximum = 0;
const tabLimiter = createLimiter(2);
await Promise.all(Array.from({ length:12 }, () => tabLimiter.run(async () => {
  tabActive += 1;
  tabMaximum = Math.max(tabMaximum, tabActive);
  await wait(10);
  tabActive -= 1;
})));
assert.equal(tabMaximum, 2, "the tab limiter must cap slow player pages independently of metadata workers");
assert.deepEqual(tabLimiter.stats(), {active:0, waiting:0, limit:2}, "every completed tab task must release its slot");

let layeredWorkers = 0;
let layeredWorkerMaximum = 0;
let layeredTabs = 0;
let layeredTabMaximum = 0;
const layeredTabLimiter = createLimiter(2);
const layeredResult = await runBounded(Array.from({ length:60 }, (_, index) => index), async (item) => {
  layeredWorkers += 1;
  layeredWorkerMaximum = Math.max(layeredWorkerMaximum, layeredWorkers);
  await wait(4); // HTTP redirect / metadata phase
  if (item % 5 === 0) {
    await layeredTabLimiter.run(async () => {
      layeredTabs += 1;
      layeredTabMaximum = Math.max(layeredTabMaximum, layeredTabs);
      await wait(14); // only the minority needing a player fallback
      layeredTabs -= 1;
    });
  }
  layeredWorkers -= 1;
}, { concurrency:6 });
assert.equal(layeredResult.started, 60);
assert.equal(layeredWorkerMaximum, 6, "the metadata layer must be able to use all six workers");
assert.equal(layeredTabMaximum, 2, "the same run must never exceed two player tabs");
assert.deepEqual(layeredTabLimiter.stats(), {active:0, waiting:0, limit:2});

const interleaved = interleaveByKey([
  {section:"A", id:"A1"}, {section:"A", id:"A2"}, {section:"A", id:"A3"},
  {section:"B", id:"B1"}, {section:"B", id:"B2"},
  {section:"C", id:"C1"}
], (item) => item.section);
assert.deepEqual(interleaved.map((item) => item.id), ["A1", "B1", "C1", "A2", "B2", "A3"], "large early sections must not starve later weeks");

const timingActivities = [
  {title:"video", kind:"video", readElapsedMs:9000, externalResolveMs:1000, mediaInspectionMs:8000},
  {title:"pdf", kind:"file", readElapsedMs:3000, externalResolveMs:500, fileInspectionMs:2500},
  {title:"forum", kind:"forum", readElapsedMs:1000, forumInspectionMs:1000}
];
const originalOrder = timingActivities.map((item) => item.title);
const timingSummary = summarizeInspectionTiming(timingActivities);
assert.equal(timingSummary.externalResolveWorkMs, 1500);
assert.equal(timingSummary.fileInspectionWorkMs, 2500);
assert.equal(timingSummary.mediaInspectionWorkMs, 8000);
assert.equal(timingSummary.forumInspectionWorkMs, 1000);
assert.deepEqual(timingSummary.slowestActivities.map((item) => item.title), ["video", "pdf", "forum"]);
assert.deepEqual(timingActivities.map((item) => item.title), originalOrder, "bottleneck ranking must not mutate report evidence order");
assert.equal(inspectionGoalStatus({queueElapsedMs:20 * 60 * 1000,targetTotalMs:28 * 60 * 1000},{provisional:false}).key, "confirmed_within_target");
assert.equal(inspectionGoalStatus({queueElapsedMs:20 * 60 * 1000,targetTotalMs:28 * 60 * 1000},{provisional:true}).key, "provisional_within_target");
assert.equal(inspectionGoalStatus({queueElapsedMs:31 * 60 * 1000,targetTotalMs:28 * 60 * 1000},{provisional:false}).key, "confirmed_over_target");
assert.equal(inspectionGoalStatus({queueElapsedMs:31 * 60 * 1000,targetTotalMs:28 * 60 * 1000},{provisional:true}).key, "provisional_over_target");

console.log(`performance scheduler tests passed: baseline workers ${maximumActive}, layered workers ${layeredWorkerMaximum}, layered tabs ${layeredTabMaximum}, elapsed ${elapsed} ms`);
