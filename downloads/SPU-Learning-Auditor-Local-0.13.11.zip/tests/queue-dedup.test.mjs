import assert from "node:assert/strict";
import {courseQueueKey,deduplicateAuditQueue} from "../queue-dedup.js";

assert.equal(
  courseQueueKey("https://dlearning.spu.ac.th/course/view.php?id=19858&utm_source=x#section-2"),
  courseQueueKey("https://dlearning.spu.ac.th/course/view.php?foo=bar&id=19858"),
  "the Moodle course id, not URL decoration, identifies a queued course"
);
assert.notEqual(
  courseQueueKey("https://dlearning.spu.ac.th/course/view.php?id=19858"),
  courseQueueKey("https://dlearning.spu.ac.th/course/view.php?id=19859")
);
assert.notEqual(
  courseQueueKey("https://dlearning.spu.ac.th/course/view.php?id=19858"),
  courseQueueKey("https://ilearning.spu.ac.th/course/view.php?id=19858"),
  "separate LMS hosts must not collide"
);

const oldDone = {id:"old",courseUrl:"https://dlearning.spu.ac.th/course/view.php?id=1",status:"done",finishedAt:"2026-10-05T01:00:00Z",reportId:"report-old"};
const newDone = {id:"new",courseUrl:"https://dlearning.spu.ac.th/course/view.php?id=1&utm_source=again",status:"done",finishedAt:"2026-10-05T02:00:00Z",reportId:"report-new"};
const other = {id:"other",courseUrl:"https://dlearning.spu.ac.th/course/view.php?id=2",status:"done",finishedAt:"2026-10-05T02:00:00Z"};
let cleaned = deduplicateAuditQueue([oldDone,newDone,other]);
assert.deepEqual(cleaned.map((item)=>item.id),["new","other"],"finished duplicates collapse to the newest card");

const queued = {id:"queued",courseUrl:"https://dlearning.spu.ac.th/course/view.php?id=1#week-1",status:"queued",createdAt:"2026-10-05T03:00:00Z"};
cleaned = deduplicateAuditQueue([newDone,queued]);
assert.deepEqual(cleaned.map((item)=>item.id),["queued"],"an active job must survive cleanup instead of an older finished card");

const firstQueued = {id:"first",courseUrl:"https://dlearning.spu.ac.th/course/view.php?id=3",status:"queued",createdAt:"2026-10-05T01:00:00Z"};
const secondQueued = {id:"second",courseUrl:"https://dlearning.spu.ac.th/course/view.php?id=3&utm_source=duplicate",status:"queued",createdAt:"2026-10-05T02:00:00Z"};
cleaned = deduplicateAuditQueue([firstQueued,secondQueued]);
assert.deepEqual(cleaned.map((item)=>item.id),["first"],"duplicate queued jobs must run only once");

console.log("queue dedup tests passed: canonical course identity, newest result card and one active job");
