import assert from "node:assert/strict";
import {applyInstructorDecision,normalizeInstructorDecision} from "../instructor-review.js";
import {finalReviewBlockers} from "../media-review.js";

assert.equal(normalizeInstructorDecision({}),"pending");
assert.equal(normalizeInstructorDecision({instructor_information:true}),"complete","legacy checked state must remain complete");
assert.equal(normalizeInstructorDecision({instructor_information_status:"missing",instructor_information:false}),"missing");

const report={courseType:"GS",weeks:[{checklist:[{status:"pass",detail:"intro"},{status:"needs_review",detail:"ต้องตรวจ"}]}]};
assert.equal(finalReviewBlockers({...report,coverage:{}}),true,"undecided instructor evidence must block finalization");
applyInstructorDecision(report,"missing");
assert.equal(report.weeks[0].checklist[1].status,"fail");
assert.match(report.weeks[0].checklist[1].detail,/รูป ชื่อ และช่องทางติดต่อ/);
assert.equal(finalReviewBlockers({...report,coverage:{}}),false,"confirmed missing evidence is a final failure, not a pending blocker");
applyInstructorDecision(report,"complete");
assert.equal(report.weeks[0].checklist[1].status,"pass");
assert.equal(applyInstructorDecision(report,"pending"),null,"pending must preserve the unresolved scanner result");

const gn={courseType:"GN",weeks:[{checklist:[{status:"needs_review"}]}]};
applyInstructorDecision(gn,"complete");assert.equal(gn.weeks[0].checklist[0].status,"pass","GN uses the first combined instructor row");
console.log("instructor review tests passed: pending, complete, missing and legacy checkbox migration");
