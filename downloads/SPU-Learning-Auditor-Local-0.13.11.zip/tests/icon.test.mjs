import assert from "node:assert/strict";
import fs from "node:fs";

const manifest = JSON.parse(fs.readFileSync(new URL("../manifest.json", import.meta.url), "utf8"));
for (const size of [16, 32, 48, 128]) {
  const relative = manifest.icons[String(size)];
  assert.equal(relative, manifest.action.default_icon[String(size)]);
  const png = fs.readFileSync(new URL(`../${relative}`, import.meta.url));
  assert.deepEqual([...png.subarray(0, 8)], [137, 80, 78, 71, 13, 10, 26, 10]);
  assert.equal(png.readUInt32BE(16), size);
  assert.equal(png.readUInt32BE(20), size);
}
console.log("icon tests passed");
