import assert from "node:assert/strict";
import fs from "node:fs";
import { accessGateFromEvidence } from "../providers.js";
import { durationFromProviderMarkup, unavailableMediaFromProviderMarkup, filterProviderMarkupAccessGate } from "../media-metadata.js";

const target = "https://www.youtube.com/watch?v=mDQWh2r0YX4&feature=youtu.be";
const genericTemplate = accessGateFromEvidence({url:target,bodyText:"This video is unavailable"});
assert.equal(genericTemplate.status,"missing_file","the generic gate demonstrates the false-positive template that caused this report");
assert.equal(filterProviderMarkupAccessGate(genericTemplate,target,target),null,"generic YouTube page templates must not stop the live player probe");

const playableMarkup = `{"playabilityStatus":{"status":"OK"},"videoDetails":{"videoId":"mDQWh2r0YX4","lengthSeconds":"327"},"messages":{"simpleText":"This video is unavailable"}}`;
assert.equal(unavailableMediaFromProviderMarkup(playableMarkup,target),null,"positive metadata for the requested video must outrank an unrelated error template");
assert.equal(durationFromProviderMarkup(playableMarkup,target).durationSeconds,327,"the reported 5:27 YouTube clip must resolve to 327 seconds from requested-video metadata");

const removedMarkup = `{"playabilityStatus":{"status":"ERROR","reason":"This video isn't available anymore"},"videoDetails":{"videoId":"removed123"}}`;
assert.equal(unavailableMediaFromProviderMarkup(removedMarkup,"https://www.youtube.com/watch?v=removed123").mediaStatus,"link_unavailable","a permanent status for the requested video must still fail");

const background = fs.readFileSync(new URL("../background.js",import.meta.url),"utf8");
assert.match(background,/filterProviderMarkupAccessGate\(accessGateFromEvidence/);
console.log("YouTube metadata tests passed: playable 5:27 target, generic error-template suppression and permanent removal detection");
