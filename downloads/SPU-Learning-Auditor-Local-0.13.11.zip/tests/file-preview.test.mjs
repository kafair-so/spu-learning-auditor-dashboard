import assert from "node:assert/strict";
import fs from "node:fs";
import { filePreviewIssueFromEvidence } from "../file-preview.js";

const issue = filePreviewIssueFromEvidence("Google Slides The file is too large to open. Please try with a smaller file.");
assert.equal(issue.previewStatus, "file_too_large");
assert.equal(issue.previewAccessible, false);
assert.match(issue.previewNote, /ไฟล์ใหญ่เกิน/);
assert.equal(filePreviewIssueFromEvidence("Google Slides Presentation ready"), null);

const background = fs.readFileSync(new URL("../background.js", import.meta.url), "utf8");
const report = fs.readFileSync(new URL("../report.js", import.meta.url), "utf8");
assert.match(background, /previewIssue\) return \{\.\.\.direct, \.\.\.previewIssue\}/, "a known preview failure must close through inspectFileTarget finally without further retries");
assert.match(background, /activity\.resource\.previewNote/, "preview failure must be retained on report evidence");
assert.match(report, /item\.resource\?\.previewNote/, "report must show the specific preview failure instead of a generic non-PDF message");

console.log("file-preview tests passed");
