import assert from "node:assert/strict";
import fs from "node:fs";
import { classifyActivity } from "../classifier.js";
import { sectionTopology, groupedByWeek } from "../section-mapping.js";
import { withDeadline, isAuditStepTimeout } from "../timeouts.js";

const url = (id) => `https://dlearning.spu.ac.th/mod/url/view.php?id=${id}`;
const videoNames = (code, week) => [
  `Video ${code} EP${week}_01 URL`,
  `Week ${week} VIDEO_${code}_01 URL`,
  `VDOEP${week}_${code} URL`,
  `วิดีโอ: ${code} บทที่ ${week} URL`,
  `${code} Video Summary Week ${week} URL`,
  `VIDEO–${code}–EP${week} URL`
];
const sectionNames = (week) => [
  `หัวข้อการสอนประจำสัปดาห์ที่ ${week}`,
  `ครั้งที่ ${String(week).padStart(2, "0")} | บทเรียน`,
  `Week ${week} — Topic`,
  `Session ${week}: Lesson`
];

let seed = 0x5a17;
const random = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 0x100000000);
const pick = (list) => list[Math.floor(random() * list.length)];

let activityCount = 0;
const misplacedContexts = [
  "",
  "AI Tutor",
  "แบบทดสอบก่อนเรียน",
  "Post-test",
  "เอกสารประกอบการสอน",
  "กิจกรรมท้ายบทเรียน",
  "Podcast",
  "หัวข้อเนื้อหาประจำสัปดาห์",
  "แบบทดสอบก่อนเรียน วิดีโอบันทึกการสอนล่วงหน้า AI Tutor"
];
for (let course = 1; course <= 600; course += 1) {
  const code = `SYN${String(course).padStart(4, "0")}`;
  const activities = [];
  for (let week = 1; week <= 15; week += 1) {
    const section = pick(sectionNames(week));
    const title = pick(videoNames(code, week));
    const videos = misplacedContexts.map((groupContext, placement) => ({
      title, section, groupContext, href:url(course * 100000 + week * 100 + placement)
    }));
    const live = { title:`LiveRecord_${code}_EP${week}_SEC001`, section, groupContext:"", href:url(course * 100000 + week * 100 + 20) };
    const extra = { title:`Video ${code} reference ${week}`, section, groupContext:"ข้อมูลเพิ่มเติม", href:url(course * 1000 + 200 + week) };
    const liveGroup = { title:`Video ${code} lecture ${week}`, section, groupContext:"วิดีโอบันทึกการสอนสดออนไลน์", href:url(course * 100000 + week * 100 + 21) };
    const pre = { title:"แบบประเมิน", section, groupContext:"แบบทดสอบก่อนเรียน", href:url(course * 1000 + 300 + week) };
    const genericNoLabel = { title:pick(["บรรยายสรุปประจำครั้ง", "External Resource", "แหล่งเรียนรู้เพิ่มเติม"]), section, groupContext:"", href:url(course * 100000 + week * 100 + 22) };
    for (const video of videos) {
      const kind = classifyActivity(video);
      assert.ok(["video", "video_candidate"].includes(kind), `${title} must enter video inspection despite misplaced label '${video.groupContext || "no label"}'`);
    }
    assert.equal(classifyActivity(live), "recording", "LiveRecord without a separator must remain excluded");
    assert.equal(classifyActivity(extra), "video", "an explicit Video title must survive a misplaced supplementary group");
    assert.equal(classifyActivity(liveGroup), "video", "an explicit Video title must survive a misplaced live-teaching label");
    assert.equal(classifyActivity(pre), "pre_quiz", "a clean Pre-test group must still classify a generic assessment");
    assert.equal(classifyActivity(genericNoLabel), "url", "a generic unlabeled URL must not be guessed as teaching video");
    activities.push(...videos, live, extra, liveGroup, pre, genericNoLabel);
    activityCount += videos.length + 5;
  }
  // Scramble DOM order: explicit section headings must keep the 15-session
  // mapping stable even when activities are interleaved by Moodle markup.
  activities.sort(() => random() - 0.5);
  const topology = sectionTopology(activities, 15);
  const weeks = groupedByWeek(activities, topology.mapping);
  for (let week = 1; week <= 15; week += 1) {
    assert.ok((weeks[`ครั้งที่ ${week}`] || []).length >= 4, `${code} week ${week} must remain mapped`);
  }
}

// Whole-course no-label coverage: every primary audit group must still be
// found from the activity's own module, filename, MIME hint, or explicit
// title. Generic links remain unknown instead of being guessed.
let noLabelActivityCount = 0;
for (let course = 601; course <= 900; course += 1) {
  for (let week = 1; week <= 15; week += 1) {
    const base = course * 100000 + week * 100;
    const cases = [
      [{ title:`แผนการสอนครั้งที่ ${week}.pdf`, groupContext:"", fileTypeHint:"pdf", href:`https://dlearning.spu.ac.th/mod/resource/view.php?id=${base + 1}` }, "file"],
      [{ title:`VDO COURSE${course} EP${week}_01`, groupContext:"", href:url(base + 2) }, "video"],
      [{ title:`LIVE RECORD_COURSE${course}_EP${week}`, groupContext:"", href:url(base + 3) }, "recording"],
      [{ title:`Podcast ครั้งที่ ${week}`, groupContext:"", href:url(base + 4) }, "podcast"],
      [{ title:`แบบทดสอบประจำครั้งที่ ${week}`, groupContext:"", href:`https://dlearning.spu.ac.th/mod/quiz/view.php?id=${base + 5}` }, "quiz"],
      [{ title:`Assignment ${week}`, groupContext:"", href:`https://dlearning.spu.ac.th/mod/assign/view.php?id=${base + 6}` }, "assignment"],
      [{ title:`AI Tutor ครั้งที่ ${week}`, groupContext:"", href:url(base + 7) }, "ai_tutor"],
      [{ title:"External Resource", groupContext:"", href:url(base + 8) }, "url"]
    ];
    for (const [activity, expected] of cases) {
      assert.equal(classifyActivity(activity), expected, `no-label ${activity.title} must be ${expected}`);
      noLabelActivityCount += 1;
    }
  }
}

// Misplaced-label matrix: strong item-level evidence wins over an unrelated
// label. Explicit item titles are authoritative; placement is only a fallback
// for generic or ambiguous links.
const wrongLabels = ["AI Tutor", "แบบทดสอบก่อนเรียน", "เอกสารประกอบการสอน", "กิจกรรมท้ายบทเรียน", "Podcast", "วิดีโอบันทึกการสอนล่วงหน้า"];
for (const label of wrongLabels) {
  const suffix = wrongLabels.indexOf(label) + 1;
  assert.equal(classifyActivity({ title:"เอกสารประกอบ.pdf", fileTypeHint:"pdf", groupContext:label, href:`https://dlearning.spu.ac.th/mod/resource/view.php?id=9100${suffix}` }), "file");
  assert.equal(classifyActivity({ title:"VDO MISMATCH EP01", groupContext:label, href:url(92000 + suffix) }), "video");
  assert.equal(classifyActivity({ title:"LIVE RECORD_MISMATCH_EP01", groupContext:label, href:url(93000 + suffix) }), "recording");
  assert.equal(classifyActivity({ title:"Podcast Mismatch", groupContext:label, href:url(94000 + suffix) }), "podcast");
  assert.ok(["pre_quiz", "post_quiz", "quiz"].includes(classifyActivity({ title:"Quiz Mismatch", groupContext:label, href:`https://dlearning.spu.ac.th/mod/quiz/view.php?id=${95000 + suffix}` })));
  assert.equal(classifyActivity({ title:"Assignment Mismatch", groupContext:label, href:`https://dlearning.spu.ac.th/mod/assign/view.php?id=${96000 + suffix}` }), "assignment");
  assert.equal(classifyActivity({ title:"AI Tutor Mismatch", groupContext:label, href:url(97000 + suffix) }), "ai_tutor");
}
assert.equal(classifyActivity({ title:"VDO supplementary reference", groupContext:"ข้อมูลเพิ่มเติม", href:url(98001) }), "supplementary");

assert.equal(await withDeadline(Promise.resolve("ok"), 100, "quick operation"), "ok");
const started = Date.now();
await assert.rejects(
  withDeadline(new Promise(() => {}), 20, "stalled operation"),
  (error) => isAuditStepTimeout(error) && /stalled operation/.test(error.message)
);
assert.ok(Date.now() - started < 500, "a stalled operation must be cut off promptly");

const background = fs.readFileSync(new URL("../background.js", import.meta.url), "utf8");
const report = fs.readFileSync(new URL("../report.js", import.meta.url), "utf8");
assert.match(background, /signal:controller\.signal/, "file-response inspection must be abortable");
assert.match(background, /inspection_timeout/, "media timeouts must be reported separately from broken links");
assert.match(background, /withDeadline\(\(\) => chrome\.scripting\.executeScript/g, "page probes must have a deadline");
for (const label of ["ลิงก์/ไฟล์เอกสาร PDF", "วิดีโอล่วงหน้า", "วิดีโอ Record ย้อนหลัง", "Podcast", "Quiz", "กิจกรรมท้ายบท / Assignment", "AI Tutor"]) {
  assert.match(report, new RegExp(label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")), `report must expose simple group ${label}`);
}
console.log(`stress tests passed: 900 synthetic courses, ${activityCount + noLabelActivityCount} activities including no-label and misplaced-label cases`);
