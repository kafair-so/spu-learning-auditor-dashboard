import assert from "node:assert/strict";
import fs from "node:fs";
import { normalizeMoodleFolderEntries } from "../moodle-folder.js";
import { classifyActivity } from "../classifier.js";

const folderUrl = "https://dlearning.spu.ac.th/mod/folder/view.php?id=101";
const rows = [
  {href:"https://dlearning.spu.ac.th/pluginfile.php/1/mod_folder/content/0/week1.pdf",title:"บรรยายกฎหมายรัฐธรรมนูญ ครั้งที่ 1.pdf",type:"application/pdf"},
  {href:"https://dlearning.spu.ac.th/pluginfile.php/1/mod_folder/content/0/week1.pdf?forcedownload=1",title:"บรรยายกฎหมายรัฐธรรมนูญ ครั้งที่ 1.pdf"},
  {href:"https://dlearning.spu.ac.th/pluginfile.php/1/mod_folder/content/0/nested/slides.pptx",title:"สไลด์ ครั้งที่ 1.pptx",path:"เอกสาร/สไลด์"},
  {href:"https://dlearning.spu.ac.th/pluginfile.php/1/mod_folder/content/0/notes.docx",title:"เอกสารอ่านเพิ่มเติม.docx"},
  {href:"https://dlearning.spu.ac.th/pluginfile.php/1/mod_folder/content/0/audio.mp3",title:"เสียง.mp3",type:"audio/mpeg"},
  {href:"https://dlearning.spu.ac.th/pluginfile.php/1/mod_folder/content/0/cover.png",title:"ภาพปก.png",type:"image/png"},
  {href:"https://dlearning.spu.ac.th/pluginfile.php/1/mod_folder/content/0/archive.zip",title:"Download folder"},
  {href:"https://dlearning.spu.ac.th/course/view.php?id=1",title:"กลับหน้ารายวิชา"},
  {href:"https://evil.example/file.pdf",title:"ไฟล์ภายนอก.pdf"}
];
const files = normalizeMoodleFolderEntries(rows, folderUrl);
assert.equal(files.length, 3, "PDF and common office documents must be found without counting duplicates or unrelated assets");
assert.equal(files.filter((item) => item.isPdf).length, 1, "the PDF inside the folder must be confirmed");
assert.equal(files.find((item) => item.href.includes("slides.pptx"))?.fileVerification, "not_pdf", "PowerPoint must remain valid document evidence while disclosed as non-PDF");
assert.equal(files.find((item) => item.href.includes("slides.pptx"))?.folderPath, "เอกสาร/สไลด์", "nested folder context must be retained");
assert.deepEqual(normalizeMoodleFolderEntries([], folderUrl), [], "an empty folder must not create fabricated evidence");
assert.equal(classifyActivity({title:"PowerPoint การบรรยาย ครั้งที่ 1",href:folderUrl}), "folder", "a Moodle Folder must be inspected as a container");

const content = fs.readFileSync(new URL("../content.js", import.meta.url), "utf8");
const background = fs.readFileSync(new URL("../background.js", import.meta.url), "utf8");
assert.match(content, /const modulePattern = \/\\\/mod\\\/\(\[a-z\]/, "the course scanner must collect Folder and plugin modules through the generic Moodle module path");
assert.match(content, /modulePattern\.test\(url\.pathname\)/, "a folder-only course must still count as auditable course content");
assert.match(background, /inspectMoodleFolder\(activity\.href/, "folder activities must be opened for child-file inspection");
assert.match(background, /linkStatus:"internal_folder_file"/, "each child document must retain traceable folder evidence");
assert.match(background, /section:activity\.section/, "folder children must remain in the source teaching session");

console.log("Moodle folder tests passed: PDF, Office files, nesting, duplicates, mixed assets and empty folders");
