import assert from "node:assert/strict";
import fs from "node:fs";
import { RULES, clock, mediaTimeResult, countedVideoSeconds, podcastComplianceResult, gnCoverageResult } from "../rules.js";
import { classifyActivity, isTeachingPlanFile } from "../classifier.js";
import { applyMediaReviews, isDefinitiveMediaFailure, videoStatusWithFailures, requiresMediaReview } from "../media-review.js";
import { MISPLACED_DOCUMENT_MESSAGE } from "../document-placement.js";
import { buildTeacherSummary } from "../teacher-summary.js";
import vm from "node:vm";

const fileEvidenceContext={};
vm.runInNewContext(fs.readFileSync(new URL("../file-evidence.js",import.meta.url),"utf8"),fileEvidenceContext);
assert.equal(fileEvidenceContext.DLearningFileEvidence.detectMoodleFileTypeEvidence('<img class="activityicon" alt="Video" src="/theme/image.php/core/1/f/video">'),"video","the Moodle player icon used by GAD36367 must prove an internal video");
assert.equal(fileEvidenceContext.DLearningFileEvidence.detectMoodleFileTypeEvidence('activity modtype_videofile activityiconcontainer'),"video","a Moodle video module class must remain usable when its icon has no alt text");

const source = fs.readFileSync(new URL("../background.js", import.meta.url), "utf8");
const helpers = source.slice(source.indexOf("function result("), source.indexOf("async function auditCourse("));
const { checklistForWeek, preliminaryScore } = eval(`(()=>{${helpers};return {checklistForWeek,preliminaryScore};})()`);

const uploaded = {
  kind:"video",
  title:"2 Social Media Marketing คืออะไร",
  href:"https://dlearning.spu.ac.th/mod/resource/view.php?id=99",
  linkStatus:"internal",
  fileTypeHint:"video",
  resource:{isVideo:true,sourceType:"moodle_activity_icon"}
};

assert.equal(classifyActivity({...uploaded,kind:undefined,groupContext:"วิดีโอการสอนล่วงหน้า"}), "video", "a Moodle resource with video MIME/icon evidence must surface as a video even when its title omits the word video");
const pluginVideo={title:"2 Social Media Marketing คืออะไร",href:"https://dlearning.spu.ac.th/mod/videotime/view.php?id=36367",moduleTypeHint:"videotime",groupContext:"วิดีโอการสอนล่วงหน้า"};
assert.equal(classifyActivity(pluginVideo),"video","a Moodle video plugin must surface as an internal video without relying on the title");

const metrics = {status:"fail",knownSeconds:0,requiredSeconds:5400,unknown:0,podcastRequiredSeconds:600,videoCandidates:0,definitiveVideoFailure:false};
const row = checklistForWeek("ครั้งที่ 2", [uploaded], metrics, false, "GS")[2];
assert.equal(row.status, "fail", "an internally uploaded Moodle video must not satisfy the external-video criterion");
assert.match(row.detail, /วิดีโออัปโหลดภายใน Moodle 1 รายการ/);
assert.match(row.detail, /ไม่นับเวลา/);
assert.match(row.detail, /ผู้ให้บริการภายนอก/);

const checklist = Array.from({length:7},()=>({status:"pass",detail:""}));
checklist[2] = row;
const summary = buildTeacherSummary({courseType:"GS",weeks:[{section:"ครั้งที่ 1",checklist:Array.from({length:7},()=>({status:"pass",detail:""}))},{section:"ครั้งที่ 2",checklist}]});
assert.deepEqual(summary.actions,[{
  key:"video_external",
  text:"นำวิดีโอที่อัปโหลดใน Moodle ไปไว้บนผู้ให้บริการภายนอก แล้วเพิ่มเป็นลิงก์วิดีโอในรายวิชา",
  sessions:["ครั้งที่ 2"],
  sessionText:"ครั้งที่ 2"
}]);

const passingRow = {...row,status:"pass",detail:`พบลิงก์วิดีโอภายนอก 1 รายการ · เวลาที่อ่านและนับได้ 1:30:00 / 1:30:00 · ${row.detail}`};
const mixedSummary = buildTeacherSummary({courseType:"GS",weeks:[
  {section:"ครั้งที่ 1",checklist:Array.from({length:7},()=>({status:"pass",detail:""}))},
  {section:"ครั้งที่ 2",checklist:checklist.map((item,index)=>index===2?passingRow:item)}
]});
assert.equal(mixedSummary.actions[0].key,"video_external","an internal upload must remain in teacher guidance even when valid external clips already pass the weekly duration row");

const passing = preliminaryScore([{checklist:Array.from({length:80},()=>({status:"pass"}))}], {reachedEnd:true,structurallyComplete:true,topologyReviewRequired:false,topologyConfidence:"high"}, "GS");
assert.equal(passing.status,"ผ่าน","a completed passing report must use the final label ผ่าน");
assert.match(source,/mediaStatus = "internal_upload"/);
assert.match(source,/activity\.durationSeconds = null/);
assert.match(source,/internalVideoDelivery = "internal_upload"/);
assert.match(source,/const isMoodleUrlActivity = \/\\\/mod\\\/url\\\/view\\\.php\/i/,"Moodle URL activities must have an explicit external-redirect identity");
assert.match(source,/!isH5PVideo && !isMoodleUrlActivity/,"a Video-titled Moodle URL must never enter the internal-upload branch");
assert.match(source,/else if \(isMoodleUrlActivity \|\|/,"Moodle URL activities must reach external target resolution");
assert.match(source,/activity\.kind === "video" && activity\.externalUrl && isLmsHost\(activity\.externalUrl\)/,"a Moodle URL that resolves back to an internal player must be treated as internal delivery");
console.log("internal Moodle video policy and final pass-label tests passed");
