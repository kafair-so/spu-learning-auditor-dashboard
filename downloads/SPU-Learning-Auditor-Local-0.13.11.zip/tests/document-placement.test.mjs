import assert from "node:assert/strict";
import fs from "node:fs";
import {MISPLACED_DOCUMENT_MESSAGE,looksLikeTeachingDocumentAssignment} from "../document-placement.js";

assert.equal(MISPLACED_DOCUMENT_MESSAGE,"พบเอกสารอยู่ใน Assignment ซึ่งเป็นพื้นที่ส่งงาน กรุณาวางเป็น Moodle File (PDF) หรือลิงก์ตรงไปยังไฟล์เอกสาร");
assert.equal(looksLikeTeachingDocumentAssignment({title:"เอกสารประกอบการสอน",href:"https://dlearning.spu.ac.th/mod/assign/view.php?id=1"}),true);
assert.equal(looksLikeTeachingDocumentAssignment({title:"กิจกรรมท้ายบท ให้คำนวณ Factor F",href:"https://dlearning.spu.ac.th/mod/assign/view.php?id=2"}),false,"a genuine assignment with an attached brief must not be reported as misplaced teaching material");
assert.equal(looksLikeTeachingDocumentAssignment({title:"Assignment (40%)",groupContext:"เอกสารประกอบการสอน",href:"https://dlearning.spu.ac.th/mod/assign/view.php?id=4"}),false,"an explicit graded Assignment with a supporting PPTX must remain an Assignment even below a copied document label");
assert.equal(looksLikeTeachingDocumentAssignment({title:"เอกสารประกอบการสอน",href:"https://dlearning.spu.ac.th/mod/resource/view.php?id=3"}),false,"a correctly placed Moodle File must not be flagged");

const background=fs.readFileSync(new URL("../background.js",import.meta.url),"utf8");
assert.match(background,/\/mod_assign\\\/\(\?:intro\|introattachment\)/,"only instructor intro attachments should be inspected, never student submissions");
assert.match(background,/activity\.misplacedDocumentAssignment\s*=\s*placed\.files\.length\s*>\s*0/);
assert.match(background,/!item\.misplacedDocumentAssignment/,"misplaced document containers must not pass the end-activity row");
assert.doesNotMatch(background,/activities\.push\(\.\.\.activity\.assignmentDocumentFiles/,"Assignment attachments must never be promoted into scoreable document rows");

console.log("document placement tests passed: concise guidance, correct Assignment scope and no document/activity credit");
