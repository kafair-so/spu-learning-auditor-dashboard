import assert from "node:assert/strict";
import fs from "node:fs";
import { selectProviderDurationEvidence } from "../media-metadata.js";

const source = fs.readFileSync(new URL("../background.js", import.meta.url), "utf8");
const sharepointSnippet = source.slice(source.indexOf("async function probeSharePointPlayer("), source.indexOf("async function probeMedia("));
const genericSnippet = source.slice(source.indexOf("async function probeMedia("), source.indexOf("async function probePodcastType("));
const withDeadline = async (task) => task();
const oneDriveTransientPlayerError = () => false;
const chrome = {scripting:{executeScript:async ({func,args=[]}) => [{result:await func(...args)}]}};
const probeSharePointPlayer = eval(`(${sharepointSnippet.trim()})`);
const probeMedia = eval(`(${genericSnippet.trim()})`);

const documentFor = ({text="", media=[]}={}) => {
  const shadowRoot = {
    textContent:text,
    querySelectorAll:(selector)=>selector === "video,audio" ? media : []
  };
  const shadowHost = {shadowRoot};
  return {
    readyState:"complete",
    body:{innerText:""},
    documentElement:{innerText:""},
    scripts:[],
    querySelector:() => null,
    querySelectorAll:(selector)=>selector === "*" ? [shadowHost] : []
  };
};

globalThis.document = documentFor({
  text:"0:01 / 4:05",
  media:[{tagName:"VIDEO",duration:10,currentTime:10,readyState:4,paused:false,ended:false}]
});
const visiblePair = await probeSharePointPlayer(1,false);
assert.equal(visiblePair.durationSeconds,245,"the total after the slash must be the clip length");
assert.equal(visiblePair.source,"sharepoint-player-clock");

globalThis.document = documentFor({
  text:"Seek position 10 seconds",
  media:[{tagName:"VIDEO",duration:10,currentTime:10,readyState:4,paused:false,ended:false}]
});
const progressiveBoundary = await probeSharePointPlayer(1,false);
assert.equal(progressiveBoundary.durationSeconds,null,"a current position/progressive boundary must not become duration");

globalThis.document = documentFor({text:"1:17",media:[]});
const singleClock = await probeSharePointPlayer(1,false);
assert.equal(singleClock.durationSeconds,null,"one unlabeled clock is ambiguous and must remain unknown");

globalThis.document = documentFor({
  text:"Seek slider, 1 second of 4 minutes 5 seconds",
  media:[{tagName:"VIDEO",duration:10,currentTime:10,readyState:4,paused:false,ended:false}]
});
const accessibleTotal = await probeSharePointPlayer(1,false);
assert.equal(accessibleTotal.durationSeconds,245,"the total after 'of' must be accepted");
assert.equal(accessibleTotal.source,"sharepoint-accessible-duration");

globalThis.location = {hostname:"spulive-my.sharepoint.com",pathname:"/_layouts/15/stream.aspx",href:"https://spulive-my.sharepoint.com/_layouts/15/stream.aspx?id=video"};
globalThis.document = documentFor({
  text:"Seek position 10 seconds",
  media:[{tagName:"VIDEO",duration:10,currentTime:10,readyState:4,paused:false,ended:false}]
});
const genericProgressiveBoundary = await probeMedia(1,false);
assert.equal(genericProgressiveBoundary.durationSeconds,null,"generic fallback must also reject a SharePoint progressive boundary");

assert.match(source,/stableCandidateCount >= 2/,"non-clock SharePoint duration requires two stable observations");
assert.match(source,/authoritativeOneDriveDuration/,"the initial background probe must not publish one untrusted duration sample");

delete globalThis.document;
delete globalThis.location;
console.log("SharePoint duration tests passed: visible total, accessible total, ambiguous clock and progressive boundary");
