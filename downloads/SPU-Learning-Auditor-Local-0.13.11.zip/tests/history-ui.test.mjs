import assert from "node:assert/strict";
import fs from "node:fs";

const popup=fs.readFileSync(new URL("../popup.js",import.meta.url),"utf8");
const history=fs.readFileSync(new URL("../history.js",import.meta.url),"utf8");
const html=fs.readFileSync(new URL("../history.html",import.meta.url),"utf8");
const store=fs.readFileSync(new URL("../report-store.js",import.meta.url),"utf8");

assert.match(popup,/reports\.length\} รายงานที่บันทึกไว้/);
assert.doesNotMatch(popup,/\/ 20 รายงาน/);
assert.match(history,/recentReports\.length\} รายการ/);
assert.doesNotMatch(history,/\/ 500 รายการ/);
assert.match(html,/id="selectAll"/);
assert.match(html,/id="deleteSelected"/);
assert.match(history,/await deleteStoredReports\(ids\)/);
assert.doesNotMatch(history,/while\(selected\.size>2\)/,"selection must support bulk deletion beyond two reports");
assert.match(store,/export async function deleteStoredReports\(ids\)/);
assert.match(store,/database\.transaction\(REPORT_STORE, "readwrite"\)/,"batch deletion must use an IndexedDB write transaction");
console.log("history count and bulk-delete UI tests passed");
