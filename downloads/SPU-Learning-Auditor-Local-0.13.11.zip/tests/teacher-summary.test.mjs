import assert from "node:assert/strict";
import { buildTeacherSummary } from "../teacher-summary.js";

const checklist = (status, detail = "") => ({ status, detail });
const weekly = (section, overrides = {}) => ({
  section,
  checklist: [
    checklist("pass"), checklist("pass"), checklist("pass"), checklist("pass"),
    checklist("pass"), checklist("pass"), checklist("not_applicable"),
  ].map((item, index) => overrides[index] || item)
});

const summary = buildTeacherSummary({
  courseType:"GS",
  weeks:[
    weekly("ครั้งที่ 1", {3:checklist("fail", "0 ลิงก์ภายนอกที่นับ"), 4:checklist("needs_review")}),
    weekly("ครั้งที่ 2", {2:checklist("fail", "1 ลิงก์ · 1:07:40 / 1:30:00"), 4:checklist("fail", "พบแบบทดสอบ แต่เป็นกิจกรรมภายใน Moodle")}),
    weekly("ครั้งที่ 3", {2:checklist("fail", "1 ลิงก์ · 0:25:00 / 1:30:00"), 5:checklist("fail", "พบแบบทดสอบ แต่เป็นกิจกรรมภายใน Moodle")}),
    weekly("ครั้งที่ 4", {0:checklist("fail", "ไม่พบ File PDF"), 2:checklist("fail", "ติดสิทธิ์ผู้ให้บริการ 2 คลิป")}),
    weekly("ครั้งที่ 5", {3:checklist("fail", "พบ Podcast รูปแบบวิดีโอ 1 รายการ")}),
    weekly("ครั้งที่ 6", {3:checklist("fail", "ปลายทางเป็นวิดีโอ แต่เกณฑ์รับเฉพาะคลิปเสียง")}),
  ]
});

assert.equal(summary.actions.filter((item) => item.key === "video_duration").length, 1, "same video-duration issue must be one list item");
assert.deepEqual(summary.actions.find((item) => item.key === "video_duration").sessions, ["ครั้งที่ 2", "ครั้งที่ 3"]);
assert.equal(summary.actions.filter((item) => item.key === "external_prepost").length, 1, "Pre/Post Moodle Quiz issues must be merged");
assert.deepEqual(summary.actions.find((item) => item.key === "external_prepost").sessions, ["ครั้งที่ 2", "ครั้งที่ 3"]);
assert.equal(summary.actions.filter((item) => item.key === "video_permission").length, 1);
assert.deepEqual(summary.actions.find((item) => item.key === "podcast_video").sessions, ["ครั้งที่ 5", "ครั้งที่ 6"], "video Podcasts from many weeks must become one concise correction");
assert.equal(summary.actions.some((item) => item.key === "assignment"), false, "missing optional assignment must not become an instructor correction");
assert.equal(summary.pending.length, 1, "review-only evidence must be separated from required corrections");

const clean = buildTeacherSummary({courseType:"GS", weeks:[weekly("ครั้งที่ 2")]});
assert.deepEqual(clean, {actions:[], pending:[]});
const mixedShortPodcast = buildTeacherSummary({courseType:"GS", weeks:[weekly("ครั้งที่ 1"), weekly("ครั้งที่ 5", {3:checklist("fail", "1 คลิปเสียงภายนอก · 0:05:00 / 0:10:00 · พบ Podcast รูปแบบวิดีโอ 1 รายการ (ไม่ผ่านและไม่นับเวลา)")})]});
assert.equal(mixedShortPodcast.actions[0].key,"podcast_duration","when audio exists, an accompanying video must not hide the actual audio-duration shortfall");
const absentPodcast=buildTeacherSummary({courseType:"GS",weeks:[weekly("ครั้งที่ 1"),weekly("ครั้งที่ 8",{3:checklist("fail","0 คลิปเสียงภายนอก · ผู้ตรวจยืนยันเวลา 0/0 รายการ · 0:00 / 10:00")}),weekly("ครั้งที่ 9",{3:checklist("fail","0 คลิปเสียงภายนอก · ผู้ตรวจยืนยันเวลา 0/0 รายการ · 0:00 / 10:00")})]});
assert.deepEqual(absentPodcast.actions,[{key:"podcast_missing",text:"เพิ่มคลิปเสียง Podcast ผ่านลิงก์ภายนอกให้ครบตามเกณฑ์",sessions:["ครั้งที่ 8","ครั้งที่ 9"],sessionText:"ครั้งที่ 8–9"}],"zero Podcast clips must request clips, not more time");
const everySession=buildTeacherSummary({courseType:"GS",weeks:Array.from({length:15},(_,index)=>weekly(`ครั้งที่ ${index+1}`,{[index===0?4:3]:checklist("fail","0 คลิปเสียงภายนอก")}))});
assert.equal(everySession.actions.find((item)=>item.key==="podcast_missing").sessionText,"ครั้งที่ 1–15","all consecutive failures must be compressed to one readable range");
console.log("teacher summary tests passed");
