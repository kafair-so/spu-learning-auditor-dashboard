import assert from "node:assert/strict";
import test from "node:test";
import { dashboardDecision, buildDashboardRecord } from "../dashboard-export.js";

const checklist = (status) => ({ status, detail:"วิดีโอรอยืนยัน" });
const report = ({ automatic = 32, reviewWeeks = 1, evidenceCount = 1 } = {}) => ({
  id:"audit-test",
  courseType:"GR",
  courseTitle:"691GR-DES120(TL)-(TT)",
  courseUrl:"https://dlearning.spu.ac.th/course/view.php?id=21256",
  score:{ automatic, manualMax:5, totalMax:110 },
  passScore:80,
  weeks:Array.from({ length:15 }, (_, index) => ({
    checklist:[checklist(index < reviewWeeks ? "needs_review" : "fail")]
  })),
  activities:Array.from({ length:evidenceCount }, (_, index) => ({
    kind:"video", auditSession:1, title:`วิดีโอ ${index + 1}`
  })),
  coverage:{
    reachedEnd:true,
    structurallyComplete:true,
    unresolvedScoringEvidenceCount:evidenceCount,
    unmappedNonForumActivityCount:evidenceCount,
    unresolvedClassificationCount:evidenceCount
  }
});

test("many pending videos in one session can add only one weekly video point", () => {
  const result = dashboardDecision(report({ evidenceCount:93 }));
  assert.equal(result.reviewableCriteria.length,1);
  assert.equal(result.reviewablePoints,6);
  assert.equal(result.possibleScore,38);
  assert.equal(result.internalStatus,"has_content");
});

test("pending video criteria are counted once per session", () => {
  const result = dashboardDecision(report({ evidenceCount:150, reviewWeeks:15 }));
  assert.equal(result.reviewableCriteria.length,15);
  assert.equal(result.reviewablePoints,20);
  assert.equal(result.possibleScore,52);
});

test("a review is requested only when weekly criteria can reach the pass mark", () => {
  const result = dashboardDecision(report({ automatic:75, evidenceCount:20, reviewWeeks:1 }));
  assert.equal(result.possibleScore,81);
  assert.equal(result.internalStatus,"needs_review");
});

test("dashboard records declare the weekly criterion score model", () => {
  const record = buildDashboardRecord(report());
  assert.equal(record.schemaVersion,2);
  assert.equal(record.scoreModel,"weekly_criterion_v2");
  assert.equal(record.possibleScore,38);
  assert.equal(record.evidenceSnapshot.weeks[0].criteria[0].label,"ข้อมูลและแนะนำรายวิชา");
  assert.equal(record.evidenceSnapshot.weeks[1].criteria[0].label,"แผนการสอน");
});
