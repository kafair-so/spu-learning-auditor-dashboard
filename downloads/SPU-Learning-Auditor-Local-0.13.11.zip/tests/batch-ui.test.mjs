import assert from "node:assert/strict";
import {installBatchReview} from "../batch-review-ui.js";
let focused=null,messages=[],reloads=0;
class Node {
  constructor(){this.children=[];this.listeners={};this.className="";this.value="";this.dataset={};this.checked=false;this.disabled=false;this.classList={add:name=>{this.className+=' '+name;}};}
  append(...nodes){this.children.push(...nodes);}
  prepend(...nodes){this.children.unshift(...nodes);}
  replaceChildren(...nodes){this.children=nodes;}
  addEventListener(type,callback){this.listeners[type]=callback;}
  setAttribute(){}
  focus(){focused=this;} select(){this.selected=true;}
  matches(selector){return selector.split(',').some(c=>this.className.split(' ').includes(c.trim().slice(1)));}
  closest(){return this.wrapper;}
}
const button=new Node(),finalButton=new Node(),status=new Node(),panel=new Node(),root=new Node();
const wrappers=Array.from({length:2},(_,i)=>{const wrapper=new Node(),label=new Node(),confirm=new Node(),message=new Node();wrapper.dataset.podcastIndex=String(i);confirm.className="podcast-confirm";wrapper.querySelector=selector=>selector==="label"?label:selector===".podcast-confirm"?confirm:selector===".podcast-message"?message:label.children.find(x=>x instanceof Node&&x.matches(selector));wrapper.label=label;return wrapper;});
root.querySelectorAll=selector=>selector===".podcast-review"?wrappers:[];root.querySelector=()=>null;
globalThis.document={createElement:()=>new Node(),querySelector:selector=>({"#report":root,"#draft-status":status,"#save-all-reviews":button,"#finalize-review":finalButton,".score-card":{lastElementChild:panel}})[selector]};
const saved={};globalThis.sessionStorage={getItem:key=>saved[key]??null,removeItem:key=>delete saved[key],setItem:(key,value)=>saved[key]=value};
globalThis.window={addEventListener(){}};globalThis.scrollY=640;globalThis.scrollTo=()=>{};globalThis.requestAnimationFrame=fn=>fn();globalThis.location={reload:()=>reloads++};
const storageState={};
globalThis.chrome={storage:{local:{get:async keys=>{const list=Array.isArray(keys)?keys:[keys];return Object.fromEntries(list.filter(key=>key in storageState).map(key=>[key,structuredClone(storageState[key])]));},set:async value=>Object.assign(storageState,structuredClone(value))}},runtime:{sendMessage:async message=>{messages.push(message);return {ok:true};}}};
const dirty=await installBatchReview({id:"r",courseUrl:"c",activities:wrappers.map((_,i)=>({kind:"podcast",href:`p${i}`,mediaType:"audio"}))});
for(const [i,digits] of [[0,"1524"],[1,"1030"]]){
 const wrapper=wrappers[i],m=wrapper.querySelector(".podcast-minutes"),s=wrapper.querySelector(".podcast-seconds");m.wrapper=wrapper;s.wrapper=wrapper;
 m.value=digits.slice(0,2);m.listeners.input();assert.equal(focused,s,"two minute digits must auto-advance to seconds");root.listeners.input({target:m});
 s.value=digits.slice(2);s.listeners.input();root.listeners.input({target:s});wrapper.querySelector(".podcast-confirm").checked=true;
}
assert.equal(messages.length,0);assert.equal(reloads,0);assert.equal(dirty(),true);
await new Promise(resolve=>setTimeout(resolve,400));assert.equal(storageState.reviewDrafts.r.podcasts.p0.minutes,"15","an unfinished reviewer edit must be saved automatically without pressing a button");assert.equal(storageState.reviewDrafts.r.podcasts.p1.minutes,"10");
const secondSeconds=wrappers[1].querySelector(".podcast-seconds");secondSeconds.value="60";
await button.onclick({target:button});assert.equal(messages.length,0,"invalid second field must preserve all drafts without any write");
secondSeconds.value="30";await button.onclick({target:button});
assert.equal(messages.length,1);assert.deepEqual(messages[0].podcasts.map(x=>x.seconds),[924,630]);assert.equal(reloads,1);assert.equal(saved["review-scroll:r"],"640");assert.equal(dirty(),false);
assert.equal(storageState.reviewDrafts.r,undefined,"a committed review must clear only its own recovery draft");
secondSeconds.value="";secondSeconds.listeners.keydown({key:"Backspace",preventDefault(){}});assert.equal(focused,wrappers[1].querySelector(".podcast-minutes"));
console.log("batch UI tests passed: automatic focus, uninterrupted drafts, one commit, validation without data loss and saved scroll position");
