import assert from "node:assert/strict";
import fs from "node:fs";
const source=fs.readFileSync(new URL("../background.js",import.meta.url),"utf8");
const snippet=source.slice(source.indexOf("async function closeAuditTab("),source.indexOf("async function recoverOrphanedAuditTabs("));
let released=0,removes=0,exists=true,fail=false,tabSafetyError=null;
const auditTabReleases=new Map();
const persisted=new Set();
const persistedAuditTab=async id=>persisted.has(id)?{tabId:id}:null;
const forgetAuditTab=async id=>persisted.delete(id);
const releaseAuditTab=id=>{auditTabReleases.get(id)?.();auditTabReleases.delete(id);};
const auditTabLimiter={cancelWaiting:()=>{}};
const isTabGoneError=error=>/No tab/.test(error.message);
const wait=async()=>{};
const recordAuditDiagnostic=async()=>{};
const withDeadline=async task=>task();
const chrome={scripting:{executeScript:async()=>{}},tabs:{
  remove:async()=>{removes++;if(fail)throw new Error("Tabs cannot be edited right now");exists=false;},
  get:async()=>{if(!exists)throw new Error("No tab");return {id:1};}
}};
const close=eval(`(${snippet.trim()})`);
auditTabReleases.set(1,()=>released++);
persisted.add(1);
await close(1); assert.equal(released,1);assert.equal(auditTabReleases.size,0);
await close(1); assert.equal(removes,1,"must not close an unowned/user tab");
fail=true;exists=true;auditTabReleases.set(1,()=>released++);
persisted.add(1);
await assert.rejects(close(1),/ปิดแท็บตรวจไม่สำเร็จ/);
assert.equal(released,1,"failed closure must not release capacity");
assert.equal(auditTabReleases.size,1);
assert.ok(tabSafetyError);
exists=false;await close(1);assert.equal(released,2,"confirmed disappearance permits releasing capacity");
exists=true;fail=false;persisted.add(1);await close(1);assert.equal(removes,7,"must close a persistently owned tab after a worker restart");assert.equal(persisted.size,0);
console.log("tab safety tests passed: confirmed closure, retained capacity on failure, owned tabs only");
