import assert from "node:assert/strict";
import fs from "node:fs";
import {selectProviderDurationEvidence as choose} from "../media-metadata.js";
const chosen=choose([{isGooglePhotos:true,controlDurationSeconds:824,durationSeconds:824,durationSource:"google-photos-player-control"}]);
assert.equal(chosen.durationSeconds,824,"Google Photos visible 13:44 player duration must be accepted");

const background=fs.readFileSync(new URL("../background.js",import.meta.url),"utf8");
assert.match(background,/async function readGooglePhotosInForeground\(/,"Google Photos must have a foreground recovery path");
assert.match(background,/isGooglePhotos && !last\.durationSeconds/,"foreground recovery must run only after background probing misses duration");
assert.match(background,/latest = await probeMedia\(tabId, poll > 0\)/,"recovery must retry after starting playback");
assert.match(background,/withTemporaryForeground\(tabId/,"the temporary audit tab must restore the user's tab afterwards");

const snippet=background.slice(background.indexOf("async function probeMedia("),background.indexOf("async function probePodcastType("));
const withDeadline=async(task)=>task();
const oneDriveTransientPlayerError=()=>false;
const selectProviderDurationEvidence=choose;
const clockNode={
  textContent:"",
  getAttribute:(name)=>name==="aria-label" ? "0 Minutes 2 Seconds of 13 Minutes 44 Seconds" : null
};
globalThis.location={
  hostname:"youtube.googleapis.com",
  pathname:"/embed/",
  href:"https://youtube.googleapis.com/embed/?ps=picasaweb&origin=https%3A%2F%2Fphotos.google.com&aria_label=Google+Photos+Video+Player"
};
globalThis.document={
  readyState:"complete",
  body:{innerText:""},
  documentElement:{innerText:""},
  scripts:[],
  querySelector:()=>null,
  querySelectorAll:(selector)=>selector.includes("[aria-label]") ? [clockNode] : []
};
globalThis.chrome={scripting:{executeScript:async({func,args=[]})=>[{result:await func(...args)}]}};
const probeMedia=eval(`(${snippet.trim()})`);
const embedded=await probeMedia(1,false);
assert.equal(embedded.durationSeconds,824,"Google Photos nested player must read its accessible 13:44 total");
assert.equal(embedded.source,"google-photos-player-control");
delete globalThis.chrome;
delete globalThis.document;
delete globalThis.location;
console.log("Google Photos player tests passed: nested iframe permission, accessible 13:44 duration and temporary foreground recovery");
