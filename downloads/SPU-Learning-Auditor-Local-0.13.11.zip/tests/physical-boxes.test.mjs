import assert from "node:assert/strict";
import fs from "node:fs";
import {sectionTopology,canonicalWeek,groupedByWeek} from "../section-mapping.js";
import {classifyActivity} from "../classifier.js";
import {podcastComplianceResult} from "../rules.js";
import {createLimiter,runBounded} from "../audit-scheduler.js";

const boxes = [
  {sectionId:"section-0",sectionIndex:0,section:"COURSE",title:"Announcements",kind:"forum"},
  {sectionId:"section-1",sectionIndex:1,section:"แนะนำรายวิชา",title:"Video introduction",kind:"video"},
  ...Array.from({length:14},(_,i)=>({sectionId:`section-${i+2}`,sectionIndex:i+2,section:i===11?"ครั้งที่ 15 Cloud Kitchen":i===13?"ครั้งที่ 16 กรณีศึกษา":"หัวข้อซ้ำ",title:`Video EP${i+100}`,kind:"video"}))
];
const topology = sectionTopology([...boxes].reverse());
assert.equal(topology.mapping.size,15);
assert.equal(canonicalWeek(boxes[0],topology.mapping),null);
boxes.slice(1).forEach((item,i)=>assert.equal(canonicalWeek(item,topology.mapping),i+1));
assert.equal(canonicalWeek(boxes.at(-1),topology.mapping),15);
const emptyBox={sectionId:"section-2",sectionIndex:2,section:"กล่องว่าง"};
const withEmpty=sectionTopology(boxes.filter(item=>item.sectionId!==emptyBox.sectionId),15,[emptyBox]);
assert.equal(canonicalWeek(boxes[3],withEmpty.mapping),3,"an empty physical teaching box must not shift later sessions");
const iLearningFifteen = [
  {sectionId:"section-1",sectionIndex:1,section:"Course Introduction",title:"Course Description",kind:"file"},
  ...Array.from({length:14},(_,i)=>({sectionId:`section-${i+2}`,sectionIndex:i+2,section:`Lecture ${i+1}`,title:`PODcast ${i+1}`,kind:"podcast"}))
];
const iLearningFifteenTopology = sectionTopology(iLearningFifteen);
iLearningFifteen.forEach((item,index)=>assert.equal(canonicalWeek(item,iLearningFifteenTopology.mapping),index+1,"fifteen i-Learning boxes must map one-to-one by physical order"));
assert.equal(canonicalWeek(iLearningFifteen[1],iLearningFifteenTopology.mapping),2,"Lecture 1 is session 2 when Course Introduction already makes exactly fifteen boxes");
const iLearningPhantomBoundary = {sectionId:"theme-empty-wrapper",sectionIndex:0,section:"Course content wrapper"};
const iLearningFifteenWithThemeWrapper = sectionTopology(iLearningFifteen,15,[iLearningPhantomBoundary]);
assert.equal(canonicalWeek(iLearningFifteen[0],iLearningFifteenWithThemeWrapper.mapping),1,"a theme-only empty wrapper must not make Course Introduction merge with Lecture 1");
assert.equal(canonicalWeek(iLearningFifteen[1],iLearningFifteenWithThemeWrapper.mapping),2,"Lecture 1 must remain session 2 when exactly fifteen visible i-Learning boxes exist");
assert.equal(canonicalWeek(iLearningFifteen.at(-1),iLearningFifteenWithThemeWrapper.mapping),15,"Lecture 14 must remain session 15 despite an extra empty DOM wrapper");
const iLearningOverflow = [iLearningFifteen[0], ...Array.from({length:15},(_,i)=>({sectionId:`overflow-${i+2}`,sectionIndex:i+2,section:`Lecture ${i+1}`,title:`PODcast ${i+1}`,kind:"podcast"}))];
const iLearningOverflowTopology = sectionTopology(iLearningOverflow);
assert.equal(canonicalWeek(iLearningOverflow[0],iLearningOverflowTopology.mapping),1);
assert.equal(canonicalWeek(iLearningOverflow[1],iLearningOverflowTopology.mapping),1,"Course Introduction and Lecture 1 merge only when the course would exceed fifteen boxes");
assert.equal(canonicalWeek(iLearningOverflow.at(-1),iLearningOverflowTopology.mapping),15);
const explicitSessionsAfterIntro = [
  {sectionId:"course-intro",sectionIndex:0,section:"ข้อมูลรายวิชา",title:"Course information",kind:"file"},
  {sectionId:"session-1",sectionIndex:1,section:"ครั้งที่ 1 แนะนำรายวิชา",title:"Lesson plan",kind:"file"},
  ...Array.from({length:6},(_,index)=>({sectionId:"session-2",sectionIndex:2,section:"ครั้งที่ 2 Introduction",title:`Video Introduction Part${index+1}/6`,kind:"video"})),
  ...Array.from({length:8},(_,index)=>({sectionId:"session-3",sectionIndex:3,section:"ครั้งที่ 3 Logistics Flow",title:`Video Logistics Part${index+1}/8`,kind:"video"}))
];
const explicitAfterIntroTopology = sectionTopology(explicitSessionsAfterIntro);
assert.equal(canonicalWeek(explicitSessionsAfterIntro.find(item=>item.sectionId==="session-2"),explicitAfterIntroTopology.mapping),2,"six videos under an explicit session-2 heading must never shift to session 3 because of an introductory box");
assert.equal(canonicalWeek(explicitSessionsAfterIntro.find(item=>item.sectionId==="session-3"),explicitAfterIntroTopology.mapping),3,"eight videos under the following explicit session-3 heading must remain in session 3");
const explicitAfterIntroGroups = groupedByWeek(explicitSessionsAfterIntro, explicitAfterIntroTopology.mapping);
assert.equal(explicitAfterIntroGroups["ครั้งที่ 2"].filter(item=>item.kind==="video").length,6,"session 2 scoring must receive exactly its six videos");
assert.equal(explicitAfterIntroGroups["ครั้งที่ 3"].filter(item=>item.kind==="video").length,8,"session 3 scoring must receive exactly its eight videos");
const sparseExplicitSessions = [
  {sectionId:"sparse-intro",sectionIndex:0,section:"ข้อมูลรายวิชา",title:"Course information",kind:"file"},
  {sectionId:"sparse-2",sectionIndex:1,section:"ครั้งที่ 2 Introduction",title:"Video lesson 2",kind:"video"},
  {sectionId:"sparse-7",sectionIndex:2,section:"ครั้งที่ 7 Special topic",title:"Video lesson 7",kind:"video"},
  {sectionId:"sparse-9",sectionIndex:3,section:"ครั้งที่ 9 Review",title:"Video lesson 9",kind:"video"}
];
const sparseTopology = sectionTopology(sparseExplicitSessions);
assert.equal(canonicalWeek(sparseExplicitSessions[1],sparseTopology.mapping),2,"two or more increasing explicit headings remain authoritative even when meeting numbers have gaps");
assert.equal(canonicalWeek(sparseExplicitSessions[2],sparseTopology.mapping),7,"a sparse explicit session 7 must not collapse to physical box 3");
assert.equal(canonicalWeek(sparseExplicitSessions[3],sparseTopology.mapping),9,"a sparse explicit session 9 must not collapse to physical box 4");
const chapterCourseBoxes = [
  {sectionId:"rules",sectionIndex:0,section:"กฎกติกาในการเรียนรู้"},
  {sectionId:"intro",sectionIndex:1,section:"แนะนำรายวิชาและอาจารย์ผู้สอน"},
  ...Array.from({length:15},(_,index)=>({sectionId:`chapter-${index+1}`,sectionIndex:index+2,section:`ครั้งที่ ${index+2} ${index===0?"Introduction":index===14?"Conclusion":"Lesson"}`}))
];
const chapterCourseActivities = [
  {sectionId:"intro",sectionIndex:1,section:"แนะนำรายวิชาและอาจารย์ผู้สอน",title:"เอกสารแนะนำรายวิชา",kind:"file"},
  ...Array.from({length:15},(_,index)=>({sectionId:`chapter-${index+1}`,sectionIndex:index+2,section:`ครั้งที่ ${index+2} ${index===0?"Introduction":index===14?"Conclusion":"Lesson"}`,title:`Chapter ${index+1} Pre-Test`,kind:"pre_quiz"}))
];
const chapterCourseTopology = sectionTopology(chapterCourseActivities,15,chapterCourseBoxes);
assert.equal(chapterCourseTopology.mapping.has("id:rules"),false,"an opening rules-only card must not consume an academic session");
assert.equal(canonicalWeek(chapterCourseActivities[0],chapterCourseTopology.mapping),1,"course introduction evidence must join session 1");
chapterCourseActivities.slice(1).forEach((item,index)=>assert.equal(canonicalWeek(item,chapterCourseTopology.mapping),index+1,`Chapter ${index+1} must map to academic session ${index+1}`));
assert.equal(chapterCourseTopology.outOfRangeSections.length,0,"Chapter 15 inside a physical box titled session 16 must remain in the 15-session rubric");
assert.match(chapterCourseTopology.diagnostics.find(item=>item.section==="ครั้งที่ 16 Conclusion")?.reason || "",/Chapter 15/,"the mapping must disclose that Chapter 15 overrode physical box ordinal 16");
assert.equal(chapterCourseTopology.reviewRequired,false,"a complete consistent Chapter 1-15 offset must be safe to score automatically");
assert.equal(chapterCourseTopology.mappingRows.length,17,"the report must retain every source box, including ignored prelude cards, for mapping review");
const conflictingTopology = sectionTopology([
  {sectionId:"conflict-a",sectionIndex:0,section:"ครั้งที่ 2",title:"เนื้อหา A",kind:"file"},
  {sectionId:"conflict-b",sectionIndex:1,section:"ครั้งที่ 1",title:"เนื้อหา B",kind:"file"}
]);
assert.equal(conflictingTopology.reviewRequired,true,"a reversed explicit session sequence must block automatic score confirmation");
assert.ok(conflictingTopology.safetyIssues.some((issue)=>/หัวข้อระบุครั้งที่/.test(issue)),"the topology must explain the conflicting declared and selected sessions");
const joinedIntroHeading = {section:"แนะนำรายวิชาและอาจารย์ผู้สอน",title:"เอกสารนำแนะรายวิชาสอน",kind:"file_link",fileTypeHint:"pdf"};
const joinedIntroTopology = sectionTopology([joinedIntroHeading]);
assert.equal(canonicalWeek(joinedIntroHeading,joinedIntroTopology.mapping),1,"an introduction-and-instructor heading without a separating space must map its document to session 1");
const ordinalTopicOverflow = [
  {sectionId:"topic-offset-1",sectionIndex:1,section:"ข้อมูลและแนะนำรายวิชา",title:"คำอธิบายรายวิชา",kind:"file"},
  ...Array.from({length:15},(_,i)=>({sectionId:`topic-offset-${i+2}`,sectionIndex:i+2,section:`ครั้งที่ ${i+2} หัวข้อที่ ${i+1} เรื่อง Topic ${i+1}`,title:`${i+1}.1 เอกสารประกอบการสอน`,kind:"file"}))
];
const ordinalTopicTopology = sectionTopology(ordinalTopicOverflow);
assert.equal(canonicalWeek(ordinalTopicOverflow[0],ordinalTopicTopology.mapping),1,"the introductory physical box starts session 1");
assert.equal(canonicalWeek(ordinalTopicOverflow[1],ordinalTopicTopology.mapping),1,"physical box 2 / topic 1 must merge into session 1");
assert.equal(canonicalWeek(ordinalTopicOverflow.at(-1),ordinalTopicTopology.mapping),15,"physical box 16 / topic 15 must remain scoreable as session 15");
assert.equal(ordinalTopicTopology.diagnostics.some((item)=>/กล่องลำดับที่ 16 เกิน/.test(item.reason)),false,"topic 15 must not be discarded merely because it is physical box 16");
const scanPath = "C:/Users/Administrator/Downloads/dlearning-structure-scan (7).json";
for (const firstHeading of ["ครั้งที่ 1", "สัปดาห์ที่ 1", "Week 1", "Session 1"]) {
  for (const introHeading of ["แนะนำรายวิชา", "ส่วนแนะนำรายวิชา", "LSM202"]) {
    const intro = {sectionId:"section-1",sectionIndex:1,section:introHeading,kind:"video",title:"Video แนะนำการเรียนรายวิชา",text:"แผนการสอน AI Tutor"};
    const first = {sectionId:"section-2",sectionIndex:2,section:firstHeading,kind:"video",title:"Video lesson"};
    const rest = Array.from({length:14},(_,i)=>({sectionId:`section-${i+3}`,sectionIndex:i+3,section:`หัวข้อ ${i}`,kind:"video",title:"Video lesson"}));
    const merged = sectionTopology([intro, first, ...rest].reverse());
    assert.equal(canonicalWeek(intro,merged.mapping),1);
    assert.equal(canonicalWeek(first,merged.mapping),1);
    rest.forEach((item,i)=>assert.equal(canonicalWeek(item,merged.mapping),i+2));
    assert.equal(canonicalWeek(rest.at(-1),merged.mapping),15);
    const ordinary = {...intro,section:"หัวข้อบทเรียน",title:"Video lesson",text:""};
    assert.equal(canonicalWeek(first,sectionTopology([ordinary,first]).mapping),2,"a non-introduction box must not merge with a misnumbered heading");
  }
}
const cybercrimeCourse = [
  {sectionId:"section-0",sectionIndex:0,section:"ICT468 อาชญกรรมไซเบอร์",title:"Announcements",kind:"forum"},
  {sectionId:"section-1",sectionIndex:1,section:"ครั้งที่ 1 แนะนำรายวิชา และอาจารย์ผู้สอน",title:"มคอ.03 รายละเอียดของรายวิชา",kind:"file"},
  {sectionId:"section-2",sectionIndex:2,section:"Introduction to Cybercrimes และ Cybersecurity Overview",title:"แผนการสอนประจำสัปดาห์ที่ 1",kind:"file"},
  {sectionId:"section-2",sectionIndex:2,section:"Introduction to Cybercrimes และ Cybersecurity Overview",title:"Podcast Cybersecurity Overview",kind:"podcast"},
  ...Array.from({length:14},(_,i)=>({sectionId:`section-${i+3}`,sectionIndex:i+3,section:`ครั้งที่ ${i+2} หัวข้อ ${i+2}`,title:`แผนการสอนประจำสัปดาห์ที่ ${i+2}`,kind:"file"}))
];
const cybercrimeTopology = sectionTopology(cybercrimeCourse);
assert.equal(canonicalWeek(cybercrimeCourse[1],cybercrimeTopology.mapping),1,"the explicit session-1 introduction box must be session 1");
assert.equal(canonicalWeek(cybercrimeCourse[2],cybercrimeTopology.mapping),1,"the following topic box with a Week-1 teaching plan must remain session 1");
assert.equal(canonicalWeek(cybercrimeCourse[4],cybercrimeTopology.mapping),2,"the next explicit session-2 box must start session 2 instead of session 3");
assert.equal(canonicalWeek(cybercrimeCourse.at(-1),cybercrimeTopology.mapping),15,"the final explicit box must remain session 15 after merging the split first session");
const zeroAndOneCourse = [
  {sectionId:"section-1",sectionIndex:1,section:"สัปดาห์ที่ O",title:"Video แนะนำรายวิชา LSM23667",kind:"video"},
  {sectionId:"section-1",sectionIndex:1,section:"สัปดาห์ที่ O",title:"Podcast-สัปดาห์ที่ O การจัดการ Cold chain",kind:"podcast"},
  {sectionId:"section-2",sectionIndex:2,section:"สัปดาห์ที่ 1",title:"แผนการสอนประจำสัปดาห์ที่ 1",kind:"file"},
  ...Array.from({length:14},(_,i)=>({sectionId:`section-${i+3}`,sectionIndex:i+3,section:`สัปดาห์ที่ ${i+2}`,title:`แผนการสอนประจำสัปดาห์ที่ ${i+2}`,kind:"file"}))
];
const zeroAndOneTopology = sectionTopology(zeroAndOneCourse);
assert.equal(canonicalWeek(zeroAndOneCourse[0],zeroAndOneTopology.mapping),1,"a mistyped Week O must be read as Week 0 and become the introductory half of session 1");
assert.equal(canonicalWeek(zeroAndOneCourse[2],zeroAndOneTopology.mapping),1,"Week 1 immediately after a mistyped Week O must remain session 1");
assert.equal(canonicalWeek(zeroAndOneCourse[3],zeroAndOneTopology.mapping),2,"Week 2 must start session 2 without a one-week shift");
assert.equal(canonicalWeek(zeroAndOneCourse.at(-1),zeroAndOneTopology.mapping),15,"Week 15 must remain session 15 after merging Week 0 and Week 1");
const mktDeclaredOverflow = [
  {sectionId:"mkt-intro",sectionIndex:0,section:"แนะนำรายวิชา",title:"Course Introduction",kind:"file"},
  ...Array.from({length:15},(_,i)=>({sectionId:`mkt-${i+1}`,sectionIndex:i+1,section:`ครั้งที่ ${i+1} :: ${i===14 ? "สรุปบทเรียนและกรณีศึกษาร่วมสมัย" : `บทเรียน ${i+1}`}`,title:`MKT activity ${i+1}`,kind:"file"}))
];
const mktDeclaredTopology = sectionTopology(mktDeclaredOverflow);
assert.equal(canonicalWeek(mktDeclaredOverflow[0],mktDeclaredTopology.mapping),1,"course introduction must merge into session 1 in a 16-box course");
assert.equal(canonicalWeek(mktDeclaredOverflow[1],mktDeclaredTopology.mapping),1,"explicit session 1 must share the first checklist session");
assert.equal(canonicalWeek(mktDeclaredOverflow.at(-1),mktDeclaredTopology.mapping),15,"MKT physical box 16 explicitly labelled session 15 must be counted as session 15");
assert.equal(mktDeclaredTopology.diagnostics.some((item)=>/เกิน 15/.test(item.reason)),false,"MKT session 15 must not remain in the unmapped appendix");
const genuineSixteenth = Array.from({length:16},(_,index)=>({sectionId:`real-${index+1}`,sectionIndex:index,section:`บทที่ ${index+1} ${index===15?"ประมวลความรู้":"บทเรียน"}`,title:index===15?"Post Test Quiz":`บทเรียน ${index+1}`,kind:index===15?"post_quiz":"file"}));
const genuineOverflow = sectionTopology(genuineSixteenth);
assert.equal(genuineOverflow.mapping.size,15,"a genuine sixteenth teaching box must not be merged into the rubric");
assert.deepEqual(genuineOverflow.outOfRangeSections,["id:real-16"],"only the genuine extra box is excluded from scoring");
assert.equal(genuineOverflow.diagnostics.find(item=>item.section===genuineSixteenth[15].section)?.excluded,true,"a known exclusion must not request reviewer action");
const duplicatedCourseTitleBoxes = [
  {section:"LSM23667 - การจัดการโซ่ความเย็น",sectionId:"section-0",sectionIndex:0},
  {section:"LSM23667 – การจัดการโซ่ความเย็น",sectionId:"section-1",sectionIndex:1},
  ...Array.from({length:16},(_,i)=>({section:i===0?"สัปดาห์ที่ O":`สัปดาห์ที่ ${i}`,sectionId:`section-${i+2}`,sectionIndex:i+2}))
];
const duplicatePreludeActivities = [
  {sectionId:"section-0",sectionIndex:0,section:"LSM23667 - การจัดการโซ่ความเย็น",title:"คำอธิบายรายวิชา และวัตถุประสงค์รายวิชา",kind:"file"},
  {sectionId:"section-2",sectionIndex:2,section:"สัปดาห์ที่ O",title:"แผนการสอน",kind:"file"},
  ...Array.from({length:15},(_,i)=>({sectionId:`section-${i+3}`,sectionIndex:i+3,section:`สัปดาห์ที่ ${i+1}`,title:`Podcast-สัปดาห์ที่ ${i+1}`,kind:"podcast"}))
];
const duplicatePreludeTopology = sectionTopology(duplicatePreludeActivities,15,duplicatedCourseTitleBoxes);
assert.equal(canonicalWeek(duplicatePreludeActivities[1],duplicatePreludeTopology.mapping),1,"Week O must be session 1 after an empty duplicated course-title wrapper is ignored");
assert.equal(canonicalWeek(duplicatePreludeActivities[2],duplicatePreludeTopology.mapping),1,"Week 1 must merge with Week O after the duplicate prelude is ignored");
assert.equal(canonicalWeek(duplicatePreludeActivities.at(-2),duplicatePreludeTopology.mapping),14,"Week 14 must remain inside the rubric");
assert.equal(canonicalWeek(duplicatePreludeActivities.at(-1),duplicatePreludeTopology.mapping),15,"Week 15 must remain inside the rubric");
assert.equal(duplicatePreludeTopology.diagnostics.some((item)=>/เกิน/.test(item.reason)),false,"the duplicated empty course-title wrapper must not create excess sections");
for(let course=0;course<500;course++) {
  const matrix=boxes.map((item,i)=>({...item,sectionId:`course${course}-box${i}`,section:i===0?"Course":`หัวข้อ ${i%3} ครั้งที่ ${99-i}`,title:i===0?"Announcements":`Video COURSE${course} EP${30-i}`}));
  const result=sectionTopology(matrix);
  matrix.slice(1).forEach((item,i)=>assert.equal(canonicalWeek(item,result.mapping),i+1));
}
if(fs.existsSync(scanPath)) {
  const scan = JSON.parse(fs.readFileSync(scanPath,"utf8"));
  const items=scan.activities.map(item=>({...item,kind:classifyActivity(item),sectionIndex:scan.coverage.courseSections.indexOf(item.section)}));
  const real=sectionTopology(items);
  assert.equal(real.mapping.size,15);
  assert.equal(items.filter(item=>item.section!=="LSM13167"&&!canonicalWeek(item,real.mapping)).length,0);
  assert.equal(canonicalWeek(items.find(item=>/Cloud Kitchen/.test(item.section)),real.mapping),13);
  assert.equal(canonicalWeek(items.find(item=>/^ครั้งที่ 16/.test(item.section)),real.mapping),15);
  console.log(`LSM13167: ${items.length} activities, all teaching boxes mapped to 15 sessions`);
}
assert.equal(podcastComplianceResult([{mediaType:"audio",automaticDurationSeconds:1166,durationSeconds:1166}],600),"needs_review","automatic Podcast duration must not pass without reviewer confirmation");
assert.equal(podcastComplianceResult([{mediaType:"audio",reviewerDurationConfirmed:true,durationSeconds:1166}],600),"pass");
assert.equal(podcastComplianceResult([{mediaType:null,automaticDurationSeconds:1166,durationSeconds:1166}],600),"needs_review");
assert.equal(podcastComplianceResult([{mediaType:"video",automaticDurationSeconds:1166,durationSeconds:1166}],600),"fail");
const limiter=createLimiter(1);
const release=await limiter.acquire();
const pending=limiter.acquire();
limiter.cancelWaiting(new Error("safety stop"));
await assert.rejects(pending,/safety stop/);
assert.equal(limiter.stats().active,1);
release();
let siblingFinished=false;
await assert.rejects(runBounded([1,2],async item=>{
  if(item===1) throw new Error("failed");
  await new Promise(resolve=>setTimeout(resolve,30)); siblingFinished=true;
},{concurrency:2}),/failed/);
assert.equal(siblingFinished,true,"failed course must wait for sibling workers before releasing its course lock");
console.log("physical-box, automatic podcast and safety-barrier tests passed");
