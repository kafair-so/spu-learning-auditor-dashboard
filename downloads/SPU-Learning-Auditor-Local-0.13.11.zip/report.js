import { clock } from "./rules.js";
import { initTheme } from "./theme.js";
import { initI18n, addLanguageMenu, translateThai } from "./i18n.js";
import { inspectionGoalStatus } from "./performance-summary.js";
import { buildTeacherSummary } from "./teacher-summary.js";
import { parsePodcastDuration, podcastDurationInput, podcastReviewKey } from "./podcast-review.js";
import { installBatchReview } from "./batch-review-ui.js";
import {friendlyEvidenceTitle,friendlyGroup,noteExcerpt} from "./report-format.js";
import {requiresMediaReview} from "./media-review.js";
import {isCourseUrl,learningPlatformName} from "./platform.js";
import {applyInstructorDecision,normalizeInstructorDecision} from "./instructor-review.js";
import {loadStoredReport} from "./report-store.js";
import {buildDashboardRecord,downloadDashboardRecord} from "./dashboard-export.js";
const requestedReportId = new URLSearchParams(location.search).get("reportId");
const reportLanguageKey = requestedReportId ? `reportLanguage:${requestedReportId}` : "uiLanguage";
const reportLanguage = await initI18n(reportLanguageKey);
await addLanguageMenu(undefined, reportLanguageKey);
await initTheme();
const text = (v) => String(v ?? "").replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
const thai = (s) => ({pass:"ผ่าน",pass_tolerance:"ผ่านแบบผ่อนปรน",fail:"ไม่ผ่าน",needs_review:"ต้องตรวจทาน",not_applicable:"ไม่บังคับ/ไม่มี"})[s]||s;
const statusIcon = (status) => ({pass:"✓",pass_tolerance:"✓",fail:"×",needs_review:"!",not_applicable:"–"})[status] || "•";
const statusBadge = (status,label=thai(status)) => `<span class="status-badge ${status}"><span aria-hidden="true">${statusIcon(status)}</span>${text(label)}</span>`;
const elapsed = (milliseconds) => clock(Math.max(0, Math.round(Number(milliseconds || 0) / 1000)));
const topologyLabel = (mode) => ({explicit_session_headings:"ใช้ชื่อครั้ง/สัปดาห์จากหัวข้อโดยตรง", zero_based_first_session:"เริ่มครั้งที่ 1 จาก Section 0", section_zero_intro:"Section 0 เป็นข้อมูลเกริ่น", one_based_sessions:"เริ่มครั้งที่ 1 จาก Section 1", unresolved:"ยังระบุรูปแบบไม่ได้"})[mode] || mode;
const displayedScoreStatus = (status) => status === "ผ่านเกณฑ์เบื้องต้น" ? "ผ่าน" : status;
const scoreStatusClass = (status) => status === "ผ่าน" || status === "ผ่านเกณฑ์เบื้องต้น" ? "pass" : status === "รอคะแนนตารางที่ 3" || status === "อ่านโครงสร้างไม่ครบ" || status === "ยังจับคู่บางรายการไม่ได้" || status === "ยังยืนยันประเภทรายการไม่ได้" || status === "ยังยืนยันหลักฐานบางรายการไม่ได้" || status === "ยังต้องยืนยันโครงสร้างครั้งเรียน" ? "needs_review" : "fail";
const simpleEvidenceType = (item) => {
  if (item.kind === "file" || item.kind === "file_link") return "ลิงก์/ไฟล์เอกสาร PDF";
  if (item.kind === "video" || item.kind === "video_candidate") return "วิดีโอล่วงหน้า";
  if (item.kind === "recording") return "วิดีโอ Record ย้อนหลัง";
  if (item.kind === "activity_video") return "วิดีโอประกอบกิจกรรม (ไม่นับ)";
  if (item.kind === "podcast") return item.mediaType === "video" ? "Podcast รูปแบบวิดีโอ (ไม่ผ่าน)" : "Podcast";
  if (["pre_quiz", "post_quiz", "quiz"].includes(item.kind)) return "Quiz";
  if (["assignment", "assignment_image_candidate"].includes(item.kind) || item.evidenceType === "assignment_image") return "กิจกรรมท้ายบท / Assignment";
  if (item.kind === "ai_tutor") return "AI Tutor";
  return "อื่น ๆ (ไม่นับ)";
};
const mediaSourceLabel = (source) => ({
  "youtube-metadata":"metadata วิดีโอหลักของ YouTube",
  "drive-metadata":"metadata ของ Google Drive",
  "google-photos-metadata":"metadata ของ Google Photos",
  "onedrive-metadata":"metadata ของ OneDrive/SharePoint",
  "provider-metadata":"metadata ของผู้ให้บริการ",
  "provider-meta-tag":"meta tag ของหน้าเล่น",
  "html-video":"ตัวเล่นวิดีโอ HTML",
  "html-audio":"ตัวเล่นเสียง HTML",
  "drive-player-text":"ข้อมูลบนตัวเล่น Google Drive",
  "google-photos-player-text":"ข้อมูลบนตัวเล่น Google Photos",
  "onedrive-player-text":"ข้อมูลบนตัวเล่น OneDrive",
  "title-declared-duration":"เวลาที่ระบุแบบเจาะจงในชื่อรายการ หลังยืนยันว่าลิงก์เปิดได้",
  "same-course-cache":"ผลที่ยืนยันแล้วจากลิงก์เดียวกันในรายวิชานี้"
  , "notebooklm-audio-overview":"Audio Overview ใน NotebookLM Studio"
  , "notebooklm-video-overview":"Video Overview ใน NotebookLM Studio"
  , "notebooklm-artifact-audio-player":"ตัวเล่นเสียง NotebookLM ที่แชร์"
  , "audio-player-metadata":"เวลาจริงจากตัวเล่นเสียง"
  , "reviewer-confirmed-podcast-time":"เวลาที่ผู้ตรวจกรอกและยืนยัน"
  , "google-drive-audio-filename":"ชื่อไฟล์เสียงจริงบน Google Drive"
  , "drive-player-control":"เวลารวมบนตัวควบคุม Google Drive"
  , "onedrive-player-control":"เวลารวมบนตัวควบคุม OneDrive"
})[source] || source || "หน้าเล่น";
const FIRST_CHECKLIST = ["ข้อมูลและแนะนำรายวิชา", "ข้อมูลผู้สอนและการติดต่อ", "File PDF เอกสารประกอบการสอน", "วิดีโอแนะนำ/บันทึกการสอน", "คลิปเสียง Podcast", "กิจกรรมท้ายบท", "ระบบให้คำปรึกษา AI Tutor"];
const WEEKLY_CHECKLIST = ["File PDF แผนการสอน", "File PDF เอกสารประกอบ", "วิดีโอบันทึกการสอนล่วงหน้า", "คลิปเสียง Podcast", "แบบทดสอบก่อนเรียน", "แบบทดสอบหลังเรียน", "กิจกรรมท้ายบท (ถ้ามี)"];
const GN_FIRST_CHECKLIST = ["ข้อมูลแนะนำรายวิชาและผู้สอน", "File PDF เอกสารประกอบการสอน", "วิดีโอแนะนำ/บันทึกการสอน", "คลิปเสียง Podcast", "ระบบให้คำปรึกษา AI Tutor"];
const GN_WEEKLY_CHECKLIST = ["File PDF แผนการจัดการเรียนการสอน", "File PDF เอกสารประกอบการสอน", "วิดีโอบันทึกการสอนล่วงหน้า", "คลิปเสียง Podcast"];
const data = await loadStoredReport(requestedReportId);
if (data?.id && !requestedReportId) history.replaceState(null,"",`${location.pathname}?reportId=${encodeURIComponent(data.id)}${location.hash}`);
document.querySelector("#pdf").addEventListener("click", () => {
  window.focus();
  setTimeout(() => window.print(), 50);
});
if (!data) {
  document.querySelector("#report").textContent=requestedReportId ? "ไม่พบรายงานฉบับนี้ในประวัติ กรุณาเปิดจากหน้าคิวหรือประวัติอีกครั้ง" : "ยังไม่มีผลตรวจ กรุณากลับไปกดเริ่มตรวจจากหน้ารายวิชา";
  document.querySelector("#dashboard-export").disabled=true;
}
else {
  const platformName = data.platform || learningPlatformName(data.courseUrl);
  document.querySelector("header h1").textContent = `รายงานตรวจ ${platformName}`;
  const courseLink = document.querySelector("#course");
  if (courseLink && isCourseUrl(data.courseUrl)) {
    courseLink.href = data.courseUrl;
    const label = courseLink.querySelector("span");
    if (label) label.textContent = `เปิดหน้ารายวิชา ${platformName}`;
    else courseLink.textContent = `เปิดหน้ารายวิชา ${platformName}`;
    const logo = courseLink.querySelector("img");
    if (logo) logo.hidden = platformName !== "d-Learning";
    courseLink.setAttribute("aria-label",`เปิดหน้ารายวิชา ${platformName} ในแท็บใหม่`);
    courseLink.hidden = false;
  }
  const courseCode = (String(data.courseTitle || "").match(/\b[A-Z]{2,}\s*\d{3,}[A-Z0-9-]*\b/i) || ["ไม่ระบุรหัสวิชา"])[0].replace(/\s+/g, "");
  const exportBaseName = translateThai("สรุปผลการตรวจสอบรายวิชา_ประเภท",reportLanguage) + "_" + data.courseType + "_" + courseCode;
  document.querySelector("#dashboard-export").onclick=()=>{
    const record=buildDashboardRecord(data);
    downloadDashboardRecord(record,`SPU-Audit-Dashboard_${data.courseType}_${courseCode}.json`);
  };
  document.title = exportBaseName;
  const gnTrackLabel = data.courseType === "GN" ? ` | ${data.gnTrack === "practical" ? "วิชาปฏิบัติ" : "วิชาทฤษฎี"}` : "";
  const reportLocale = ({th:"th-TH",en:"en-GB","zh-CN":"zh-CN",ja:"ja-JP"})[reportLanguage] || "th-TH";
  document.querySelector("#meta").textContent=`${data.courseTitle} | ${data.courseType}${gnTrackLabel} | ${data.credits} หน่วยกิต | Extension ${data.extensionVersion || "รุ่นเดิมไม่ระบุ"} | ตรวจเมื่อ ${new Date(data.createdAt).toLocaleString(reportLocale)} | รอบ ${data.runId?.slice(0,8) || data.id.slice(0,8)} | ${data.rubric}`;
  const candidates = data.activities.filter((item) => !item.outOfRange && item.kind === "video_candidate");
  const assignmentImageCandidates = data.activities.filter((item) => !item.outOfRange && item.kind === "assignment_image_candidate");
  const reviewCandidates = [...candidates, ...assignmentImageCandidates];
  const score = data.score || {automatic:0,automaticMax:105,manualCurrent:0,manualMax:5,totalCurrent:0,totalMax:110,remainingToPass:80,status:"ยังไม่ผ่านเกณฑ์"};
  const coverage = data.coverage || {};
  const { reviewerChecklist = {} } = await chrome.storage.local.get("reviewerChecklist");
  const reviewerState = reviewerChecklist[data.courseUrl] || {};
  let instructorDecision = normalizeInstructorDecision(reviewerState);
  let instructorConfirmed = instructorDecision === "complete";
  let manualConfirmed = 0;
  // Keep the review appendix about auditable ambiguity, not every ordinary URL
  // in a Moodle page.  This prevents navigation/support links from producing
  // many irrelevant report pages.
  const reviewItems = data.activities.filter((item) =>
    !item.outOfRange && !item.titleAlternativeOf && (item.kind === "video_candidate" || item.kind === "assignment_image_candidate" || requiresMediaReview(item) || item.classification?.contextConflict && (!item.mediaReviewRequired || item.mediaReviewDecision === "pending"))
  );
  const unmappedItems = data.activities.filter((item) => item.kind !== "forum" && !item.auditSession && !item.outOfRange);
  const weekCards = data.weeks.map((w, index) => {
    const first = index === 0 || w.section === "ครั้งที่ 1";
    const labels = data.courseType === "GN" ? (first ? GN_FIRST_CHECKLIST : GN_WEEKLY_CHECKLIST) : (first ? FIRST_CHECKLIST : WEEKLY_CHECKLIST);
    const weekTone = w.checklist.some((item) => item.status === "fail") ? "tone-danger" : w.checklist.some((item) => item.status === "needs_review") ? "tone-warning" : "tone-success";
    return `<section class="week-card ${weekTone}"><h2>${text(w.section)} — ตรวจองค์ประกอบ${first ? "ครั้งที่ 1" : "ครั้งที่ 2–15"}</h2><table><tr><th class="no">#</th><th>หัวข้อที่ต้องตรวจ</th><th>ผลตรวจ/หลักฐาน</th><th>สถานะ</th></tr>${w.checklist.map((item,i)=>{
      const instructorRow = first && (data.courseType === "GN" ? i === 0 : i === 1);
      const rowStatus = instructorRow ? instructorDecision === "complete" ? "pass" : instructorDecision === "missing" ? "fail" : item.status : item.status;
      const control = instructorRow ? `<div class="instructor-review"><label>ผลตรวจข้อมูลผู้สอน <select class="instructor-decision"><option value="pending"${instructorDecision === "pending" ? " selected" : ""}>ยังไม่ได้ตัดสิน</option><option value="complete"${instructorDecision === "complete" ? " selected" : ""}>มีรูป ชื่อ และช่องทางติดต่อครบ — ผ่าน</option><option value="missing"${instructorDecision === "missing" ? " selected" : ""}>ไม่มีหรือไม่ครบ — ไม่ผ่าน</option></select></label><span class="instructor-message muted">${instructorDecision === "missing" ? "บันทึกเป็นไม่ผ่าน และไม่ถือเป็นรายการค้างตรวจ" : instructorDecision === "complete" ? "ผู้ตรวจยืนยันว่าข้อมูลครบ" : "กรุณาเลือกผลหลังตรวจหลักฐาน"}</span></div>` : "";
      return `<tr${instructorRow ? ' data-instructor-row' : ''}><td>${i+1}</td><td>${labels[i]}</td><td>${text(item.detail)}${control}</td><td>${statusBadge(rowStatus)}</td></tr>`;
    }).join('')}</table></section>`;
  }).join('');
  const evidenceKinds = ['video','video_candidate','recording','activity_video','podcast','ai_tutor','pre_quiz','post_quiz','quiz','file','file_link','assignment','assignment_image_candidate','supplementary','url'];
  const evidenceRows = data.activities.filter((item) => evidenceKinds.includes(item.kind)).map((item) => {
    const candidateIndex = reviewCandidates.indexOf(item);
    const imageEvidence = item.evidenceType === "assignment_image";
    const baseNote = item.titleAlternativeOf
      ? item.accessNote || "ชื่อซ้ำใน Section เดียวกัน — ตรวจหลักฐานแล้วและไม่นับเวลาซ้ำ"
      : item.kind === "podcast" && item.mediaType === "video"
      ? "ไม่ผ่าน — ปลายทางเป็นวิดีโอ แต่เกณฑ์ Podcast รับเฉพาะคลิปเสียง (ไม่นับเวลา)"
      : item.kind === "podcast" && !item.mediaType && item.durationSeconds
      ? "อ่านเวลาได้ แต่ยังยืนยันไม่ได้ว่าปลายทางเป็นคลิปเสียง จึงยังไม่นับ"
      : item.kind === "activity_video"
      ? "พบวิดีโอประกอบกิจกรรม — ไม่นับเป็นวิดีโอการสอนล่วงหน้าและไม่อ่านเวลา"
      : ["quiz", "pre_quiz", "post_quiz"].includes(item.kind) && /\/mod\/quiz\/view\.php/i.test(item.href || "")
      ? "พบ Quiz ในระบบ Moodle — แสดงเป็นหลักฐาน แต่ไม่นับเป็นกิจกรรมท้ายบท/Assignment"
      : item.kind === "supplementary"
      ? "ข้อมูลเพิ่มเติม (ไม่นับ) — ไม่เปิดลิงก์สื่อ"
      : item.kind === "url" && item.linkStatus === "skipped_unclassified"
      ? "URL ไม่มีป้ายหรือหลักฐานระบุประเภทที่ชัดเจน — ไม่นับและไม่เปิดลิงก์"
      : imageEvidence
      ? (item.ocrStatus === "confirmed" ? `อ่านข้อความในภาพได้${item.ocrConfidence !== null ? ` (ความเชื่อมั่น ${item.ocrConfidence}%)` : ""}: ${item.ocrReason}` : `ภาพคำสั่งกิจกรรม: ${item.ocrReason || "ต้องตรวจทาน"}`)
      : item.accessNote || item.resource?.error || ((item.kind==='file_link'||item.kind==='file') ? (item.isPdf ? 'ยืนยันว่าเป็น PDF แล้ว' : 'เปิดลิงก์ได้ แต่ไม่ยืนยันว่าเป็น PDF') : item.durationSeconds ? `อ่านเวลาสำเร็จจาก ${mediaSourceLabel(item.source)}` : 'ไม่ต้องอ่านเวลา');
    const note = (item.outOfRange ? `เกินกรอบ 15 ครั้ง — แสดงหลักฐานแต่ไม่นับคะแนน${baseNote ? ` · ${baseNote}` : ''}` : baseNote) + (item.durationSeconds && item.kind === "podcast" ? ` · ${mediaSourceLabel(item.source)}` : '') + (item.hiddenFromStudents ? ' · ซ่อนจากผู้เรียน' : '') + (item.countingEligible === false && !item.reviewExcluded ? ' · ซ้ำ (ไม่นับเวลา)' : '');
    const destination = item.titleAlternativeOf ? (item.externalUrl ? `<a href="${text(item.externalUrl)}">เปิดลิงก์หลักฐาน</a>` : "ตรวจแล้ว — ไม่นับรายการชื่อซ้ำ")
      : item.externalUrl ? `<a href="${text(item.externalUrl)}">เปิดลิงก์</a>`
      : item.recordingInspection === 'fast_path' ? 'ไม่เปิดลิงก์ (ไม่นับเวลา)'
      : item.kind === 'supplementary' || item.kind === 'activity_video' || item.linkStatus === 'skipped_unclassified' ? 'ไม่เปิดลิงก์ (ไม่นับ)'
      : item.kind.includes('quiz') ? 'Moodle Quiz ภายใน'
      : item.kind === 'video_candidate' ? `<button class="decision" data-candidate="${candidateIndex}" data-decision="pre_recorded">นับเป็นสอนล่วงหน้า</button><button class="decision no" data-candidate="${candidateIndex}" data-decision="recording">ไม่นับเป็น Rec</button>`
      : ["assignment_text", "assessment_text"].includes(item.evidenceType) ? `<a href="${text(item.href)}" target="_blank" rel="noopener noreferrer">ดูคำสั่งใน Moodle</a>`
      : item.kind === 'assignment_image_candidate' ? `<a href="${text(item.imageUrl || item.href)}">เปิดภาพ</a><button class="decision" data-candidate="${candidateIndex}" data-decision="assignment">ยืนยันเป็นกิจกรรม</button>`
      : imageEvidence ? `<a href="${text(item.imageUrl || item.href)}">เปิดภาพคำสั่ง</a>`
      : (item.kind==='file'||item.kind==='file_link') ? `<a href="${text(item.href)}">ไฟล์ใน Moodle</a>` : 'ตรวจปลายทางไม่ได้';
    const type = simpleEvidenceType(item);
    const ocrDetail = imageEvidence && item.ocrText ? `<div class="muted">ข้อความที่อ่านได้: ${text(item.ocrText)}</div>` : '';
    const activityIndex = data.activities.indexOf(item);
    const friendlyTitle=friendlyEvidenceTitle(item.title);
    const titleDetail=friendlyTitle.rawUrl?`<details class="url-detail"><summary>ดู URL</summary><code>${text(friendlyTitle.rawUrl)}</code></details>`:"";
    const groupLabel=friendlyGroup(item.groupContext);
    const noteSummary=noteExcerpt(note);
    const noteDetail=note!==noteSummary?`<details class="evidence-details"><summary>ดูรายละเอียด</summary><div>${text(note)}</div></details>`:"";
    const podcastControl = item.kind === "podcast" && item.linkStatus === "external" && item.podcastDelivery !== "internal_upload" && !item.outOfRange ? `<div class="podcast-review" data-podcast-index="${activityIndex}"><label>กรอกเวลา <input class="podcast-time" inputmode="numeric" placeholder="นาที:วินาที" value="${podcastDurationInput(item.reviewerDurationSeconds)}"${item.mediaType === "video" ? " disabled" : ""}></label><label><input class="podcast-confirm" type="checkbox"${item.reviewerDurationConfirmed ? " checked" : ""}${item.mediaType !== "audio" ? " disabled" : ""}> ผู้ตรวจยืนยันเวลา</label><span class="podcast-message muted">${item.mediaType === "video" ? "เป็นวิดีโอ จึงไม่สามารถยืนยันเวลาได้" : item.mediaType !== "audio" ? "กรอกเวลาร่างได้ แต่จะยืนยันได้เมื่อระบบตรวจว่าเป็นคลิปเสียง" : "ระบบยืนยันชนิดเสียงแล้ว กรุณากรอกและยืนยันเวลา"}</span></div>` : "";
    const evidenceGroup = ["file","file_link"].includes(item.kind) ? "documents" : ["video","video_candidate"].includes(item.kind) ? "videos" : item.kind === "recording" ? "recordings" : item.kind === "podcast" ? "podcasts" : ["pre_quiz","post_quiz","quiz"].includes(item.kind) ? "quizzes" : ["assignment","assignment_image_candidate"].includes(item.kind) ? "assignments" : item.kind === "ai_tutor" ? "ai_tutor" : "other";
    return `<tr data-evidence-kind="${evidenceGroup}"><td data-label="ครั้ง">${text(item.section)}</td><td data-label="รายการ"><strong>${text(friendlyTitle.label)}</strong>${titleDetail}${groupLabel?`<div class="muted evidence-group">กลุ่ม: ${text(groupLabel)}</div>`:''}${ocrDetail}</td><td data-label="ประเภท"><span class="evidence-type">${type}</span></td><td data-label="ปลายทาง" class="evidence-destination">${destination}</td><td data-label="เวลาสื่อ">${item.durationSeconds?clock(item.durationSeconds):'-'}</td><td data-label="เวลาอ่าน">${item.readElapsedMs === undefined ? '-' : elapsed(item.readElapsedMs)}</td><td data-label="หมายเหตุ" data-media-review-index="${activityIndex}"><div class="evidence-note-summary">${text(noteSummary)}</div>${noteDetail}${podcastControl}</td></tr>`;
  }).join('');
  const gnCoverage = data.mediaCoverage;
  const simpleCounts = {
    documents: data.activities.filter((item) => item.kind === "file" || item.kind === "file_link").length,
    videos: data.activities.filter((item) => !item.titleAlternativeOf && (item.kind === "video" || item.kind === "video_candidate")).length,
    recordings: data.activities.filter((item) => item.kind === "recording" && !item.titleAlternativeOf).length,
    activityVideos: data.activities.filter((item) => item.kind === "activity_video").length,
    podcasts: data.activities.filter((item) => item.kind === "podcast").length,
    videoPodcasts: data.activities.filter((item) => item.kind === "podcast" && item.mediaType === "video").length,
    quizzes: data.activities.filter((item) => ["pre_quiz", "post_quiz", "quiz"].includes(item.kind)).length,
    assignments: data.activities.filter((item) => ["assignment", "assignment_image_candidate"].includes(item.kind) || item.evidenceType === "assignment_image").length,
    aiTutors: data.activities.filter((item) => item.kind === "ai_tutor").length
  };
  const performance = inspectionGoalStatus(data.timing, score);
  const summaryData = {...data,weeks:(data.weeks || []).map((week)=>({...week,checklist:(week.checklist || []).map((item)=>({...item}))}))};
  applyInstructorDecision(summaryData,instructorDecision);
  const teacherSummary = buildTeacherSummary(summaryData);
  const teacherActions = teacherSummary.actions.length
    ? `<ol>${teacherSummary.actions.map((item) => `<li><span>${text(item.text)}</span>${item.sessionText ? ` <strong class="fix-location">ต้องแก้ไข: ${text(item.sessionText)}</strong>` : ""}</li>`).join("")}</ol>`
    : `<p class="pass"><strong>ไม่พบจุดที่ต้องแก้ไขตามเกณฑ์ที่ระบบตรวจได้</strong></p>`;
  const visibleTeacherPending = teacherSummary.pending;
  const teacherPending = visibleTeacherPending.length
    ? `<h3>รายการที่ยังตรวจสอบไม่ได้</h3><ul>${visibleTeacherPending.map((item) => `<li data-pending-key="${text(item.key)}"><span>${text(item.text)}</span>${item.sessionText ? ` <strong class="review-location">ต้องตรวจสอบ: ${text(item.sessionText)}</strong>` : ""}</li>`).join("")}</ul>`
    : "";
  const teacherSummarySection = `<section class="week-card teacher-summary${scoreStatusClass(score.status) === "pass" ? " print-hide-when-passed" : ""}"><h2>สรุปจุดที่ควรแก้ไขสำหรับอาจารย์ผู้สอน</h2><p><strong>${text(data.courseTitle)}</strong></p>${teacherActions}${teacherPending}</section>`;
  const slowestRows = (data.timing?.slowestActivities || []).map((item) => `<tr><td>${text(item.section || "-")}</td><td>${text(item.title)}</td><td>${text(simpleEvidenceType(item))}</td><td>${elapsed(item.elapsedMs)}</td><td>${text(item.mediaStatus || item.source || "-")}</td></tr>`).join("");
  const gnCoverageSection = data.courseType === "GN" && gnCoverage ? `<section class="week-card"><h2>ตารางที่ 4 — ความครอบคลุมสื่อตลอด 15 ครั้ง</h2><table><tr><th>ลักษณะวิชา</th><th>เกณฑ์</th><th>วิดีโอผ่าน</th><th>Podcast ผ่าน</th><th>ผ่านครบทั้งคู่</th><th>ผล</th></tr><tr><td>${gnCoverage.track === "practical" ? "ปฏิบัติ" : "ทฤษฎี"}</td><td>${gnCoverage.track === "practical" ? "อย่างน้อย" : "ครบ"} ${gnCoverage.requiredSessions} จาก ${gnCoverage.expectedSessions} ครั้ง</td><td>${gnCoverage.videoSessions} ครั้ง</td><td>${gnCoverage.podcastSessions} ครั้ง</td><td>${gnCoverage.completeSessions} ครั้ง${gnCoverage.reviewSessions.length ? ` · รอตรวจทานครั้งที่ ${gnCoverage.reviewSessions.join(", ")}` : ""}</td><td>${statusBadge(gnCoverage.status)}</td></tr></table></section>` : "";
  const topologyRows = coverage.topologyMappingRows || [];
  const sessionOptions = (selected) => `<option value="0"${!selected ? " selected" : ""}>ไม่นับเป็นครั้งเรียน</option>${Array.from({length:coverage.expectedSessions || 15},(_,index)=>`<option value="${index+1}"${selected===index+1?" selected":""}>ครั้งที่ ${index+1}</option>`).join("")}`;
  const topologyMappingSection = topologyRows.length ? `<section class="week-card topology-mapping" data-panel="${coverage.topologyReviewRequired ? "tasks" : "system"}"><h2>ตรวจสอบการแบ่งครั้งเรียน</h2><p class="${coverage.topologyReviewRequired ? "needs_review" : "muted"}">${coverage.topologyReviewRequired ? "ระบบพบความขัดแย้งและระงับการสรุปคะแนน กรุณาตรวจตารางนี้ก่อน" : coverage.topologyManuallyConfirmed ? "ผู้ตรวจยืนยันการแบ่งครั้งเรียนแล้ว ระบบจะจำรูปแบบนี้ตราบใดที่โครงสร้างรายวิชาไม่เปลี่ยน" : "ระบบตรวจความสอดคล้องของทั้งรายวิชาก่อนคิดคะแนน"}</p>${coverage.topologySafetyIssues?.length ? `<ul class="mapping-issues">${coverage.topologySafetyIssues.map((issue)=>`<li>${text(issue)}</li>`).join("")}</ul>`:""}<table class="mapping-table"><tr><th>กล่องต้นทาง</th><th>ครั้งที่เลือก</th><th>เหตุผล</th></tr>${topologyRows.map((row)=>`<tr><td>${text(row.section)}</td><td><select class="session-mapping-choice" data-section-key="${encodeURIComponent(row.key)}">${sessionOptions(row.chosenSession)}</select></td><td>${text(row.reason)}</td></tr>`).join("")}</table><button id="save-session-mapping" type="button">ยืนยันการแบ่งครั้งและคำนวณใหม่</button><span id="session-mapping-message" class="muted"></span></section>` : "";
  const scoreMain = score.suppressed ? `<span>ระงับการสรุปคะแนน</span><strong>รอตรวจการแบ่งครั้ง</strong><small>ระบบเก็บหลักฐานครบแล้ว แต่จะไม่แสดงคะแนนจนกว่าจะยืนยันโครงสร้างครั้งเรียน</small>` : `<span>${score.provisional ? "คะแนนชั่วคราวจากข้อมูลที่อ่านได้" : "คะแนนเบื้องต้นจากระบบ"}</span><strong>${score.totalCurrent} / ${score.totalMax}</strong><small>ระบบยืนยันแล้ว ${score.automatic} / ${score.automaticMax} คะแนน · ตารางที่ 3 รอผู้ตรวจ ${score.manualCurrent} / ${score.manualMax} คะแนน</small>`;
  document.querySelector("#report").innerHTML=`
    <section class="score-card"><div>${scoreMain}</div><div class="score-result ${scoreStatusClass(score.status)}"><strong class="score-status-badge"><span aria-hidden="true">${statusIcon(scoreStatusClass(score.status))}</span>${text(displayedScoreStatus(score.status))}</strong><small>${score.status === "ยังจับคู่บางรายการไม่ได้" ? `คำนวณคะแนนชั่วคราวแล้ว · จับคู่ได้ ${coverage.mappedNonForumActivityCount ?? 0} รายการ · รอจับคู่อีก ${coverage.unmappedNonForumActivityCount ?? 0} รายการ` : score.status === "ยังยืนยันหลักฐานบางรายการไม่ได้" ? `ยังไม่ยืนยันผลผ่าน · รอหลักฐานที่มีผลต่อคะแนน ${coverage.unresolvedScoringEvidenceCount || 0} รายการ` : score.status === "ยังต้องยืนยันโครงสร้างครั้งเรียน" ? "ยังไม่สรุปคะแนนจนกว่าการแบ่งครั้งจะได้รับการยืนยัน" : score.provisional ? `ผลยังเป็นข้อมูลชั่วคราวจาก ${coverage.sectionCount ?? 0} Section ที่อ่านได้` : score.remainingToPass ? `ต้องการอีก ${score.remainingToPass} คะแนนเพื่อถึง 80` : "ถึงเกณฑ์ 80 คะแนนแล้ว"}</small></div></section>
    <p class="muted coverage-note">ความครอบคลุมโครงสร้าง: ${coverage.structurallyComplete === false ? `โครงสร้างไม่เพียงพอสำหรับตัดสินผล · พบ Section การสอน ${coverage.courseSectionCount ?? 0} Section และกิจกรรมที่ไม่ใช่ Announcements ${coverage.nonForumActivityCount ?? 0} รายการ` : coverage.reachedEnd === true ? `อ่านถึงท้ายหน้าแล้ว · พบ Section การสอน ${coverage.courseSectionCount ?? coverage.sectionCount ?? 0} Section${coverage.unmappedNonForumActivityCount ? ` · ยังจับคู่ไม่ได้ ${coverage.unmappedNonForumActivityCount} รายการ` : ""}${coverage.excludedOutOfRangeActivityCount ? ` · เกินกรอบ 15 ครั้งและไม่นับคะแนน ${coverage.excludedOutOfRangeActivityCount} รายการ` : ""}` : coverage.reachedEnd === false ? `ยังอ่านไม่ถึงท้ายหน้า · พบ ${coverage.sectionCount ?? 0} Section (ผลจึงเป็นข้อมูลชั่วคราว)` : "รายงานเดิมไม่มีข้อมูลความครอบคลุม"}</p>
    ${coverage.topologyMode ? `<p class="muted topology-note">รูปแบบครั้งเรียน: ${text(topologyLabel(coverage.topologyMode))} · ความเชื่อมั่น ${text(coverage.topologyConfidence || "ไม่ระบุ")} · กรอบเกณฑ์ ${coverage.expectedSessions || 15} ครั้ง${coverage.topologyDiagnostics?.length ? ` · ข้อยกเว้น: ${text(coverage.topologyDiagnostics.map((item)=>`${item.section}: ${item.reason}`).join(" | "))}` : ""}</p>` : ""}${topologyMappingSection}
    ${teacherSummarySection}
    <h2>สรุปภาพรวม</h2><table><tr><th>ลิงก์/ไฟล์เอกสาร PDF</th><th>วิดีโอล่วงหน้า</th><th>วิดีโอ Record ย้อนหลัง</th><th>Podcast</th><th>Quiz</th><th>กิจกรรมท้ายบท / Assignment</th><th>AI Tutor</th></tr><tr><td>${simpleCounts.documents}</td><td>${simpleCounts.videos}</td><td>${simpleCounts.recordings}</td><td>${simpleCounts.podcasts}</td><td>${simpleCounts.quizzes}</td><td>${simpleCounts.assignments}</td><td>${simpleCounts.aiTutors}</td></tr></table>
    <p class="muted">ชื่อหมวดในสรุปถูกย่อให้อ่านง่าย ส่วนผลผ่าน/ไม่ผ่านและหลักฐานยังตรวจตามเกณฑ์เดิม · Podcast รูปแบบวิดีโอ ${simpleCounts.videoPodcasts} รายการ (ไม่ผ่านและไม่นับเวลา) · วิดีโอ Record ย้อนหลังที่ยืนยันจากชื่อได้จะข้ามเปิดลิงก์ (${data.summary.recordingsSkipped || 0} รายการ) · วิดีโอประกอบกิจกรรมพบ ${simpleCounts.activityVideos} รายการ (แสดงหลักฐาน แต่ไม่นับและไม่อ่านเวลา)</p>
    <h2>เวลาที่ใช้ตรวจ</h2><table><tr><th>ระยะเวลารอบตรวจล่าสุด</th><th>อ่านโครงสร้างหน้าเรียน</th><th>เปิดและอ่านลิงก์/ไฟล์</th><th>เวลารวมของรายงาน</th><th>รายการที่ตรวจ</th><th>เฉลี่ยต่อรายการ</th></tr><tr><td>${elapsed(data.timing?.queueElapsedMs ?? data.timing?.totalElapsedMs)}</td><td>${elapsed(data.timing?.structureScanMs)}</td><td>${elapsed(data.timing?.linkInspectionMs)}</td><td>${elapsed(data.timing?.totalElapsedMs)}</td><td>${data.timing?.linkedItemCount ?? 0}</td><td>${elapsed(data.timing?.averageLinkedItemMs)}</td></tr></table>
    <p class="${performance.className}"><strong>${performance.label}</strong> · ใช้จริง ${elapsed(performance.measuredTotalMs)} / เป้าหมาย ${elapsed(performance.targetTotalMs)} · ${performance.scoreConfirmed ? "คะแนนไม่มีหลักฐานสำคัญค้าง" : `ยังมีหลักฐานที่มีผลต่อคะแนนค้าง ${coverage.unresolvedScoringEvidenceCount || 0} รายการ`}</p>
    <table><tr><th>แกะปลายทางลิงก์ (งานสะสม)</th><th>ตรวจ PDF (งานสะสม)</th><th>อ่านวิดีโอ/Podcast (งานสะสม)</th><th>ตรวจ Forum (งานสะสม)</th></tr><tr><td>${elapsed(data.timing?.externalResolveWorkMs)}</td><td>${elapsed(data.timing?.fileInspectionWorkMs)}</td><td>${elapsed(data.timing?.mediaInspectionWorkMs)}</td><td>${elapsed(data.timing?.forumInspectionWorkMs)}</td></tr></table>
    <p class="muted">เวลางานสะสมใช้หาคอขวดและอาจมากกว่าเวลารวม เพราะหลายรายการทำพร้อมกัน</p>
    ${slowestRows ? `<h3>รายการที่ใช้เวลานานที่สุด</h3><table><tr><th>ครั้ง/Section</th><th>รายการ</th><th>ประเภท</th><th>เวลา</th><th>ผลจากผู้ให้บริการ</th></tr>${slowestRows}</table>` : ""}
    <p class="muted">เป้าหมายต่อรายวิชา ${elapsed(data.timing?.targetTotalMs || 28 * 60 * 1000)} · อ่านจาก metadata โดยไม่เปิด Preview ${data.timing?.metadataFastPathCount || 0} รายการ · ใช้ player fallback ${data.timing?.playerFallbackCount || 0} รายการ${data.timing?.courseTimeBudgetCount ? ` · ยังไม่เสร็จเมื่อถึงงบเวลา ${data.timing.courseTimeBudgetCount} รายการ` : ""}</p>
    <p class="muted">วิดีโอคำนวณจากเวลาที่ระบบอ่านได้ ส่วน Podcast ระบบตรวจเฉพาะว่าเป็นคลิปเสียง และให้ผู้ตรวจกรอกพร้อมยืนยันเวลา</p>${gnCoverageSection}${weekCards}
    <h2>หลักฐานลิงก์</h2><div class="evidence-filter"><label>กรองประเภท <select id="evidence-filter"><option value="all">ทั้งหมด</option><option value="documents">เอกสาร</option><option value="videos">วิดีโอล่วงหน้า</option><option value="recordings">วิดีโอย้อนหลัง</option><option value="podcasts">Podcast</option><option value="quizzes">Pre/Post/Quiz</option><option value="assignments">กิจกรรม/Assignment</option><option value="ai_tutor">AI Tutor</option><option value="other">อื่น ๆ</option></select></label></div><table class="evidence-table"><colgroup><col><col><col><col><col><col><col></colgroup><tr><th>ครั้ง</th><th>รายการ</th><th>ประเภท</th><th>ปลายทาง</th><th>เวลาสื่อ</th><th>เวลาอ่าน</th><th>หมายเหตุ</th></tr>${evidenceRows}</table>`;
  if (score.scoringMode === "gn_checklist") {
    const scoreCard = document.querySelector(".score-card");
    const mediaStatus = data.mediaCoverage?.status || "needs_review";
    const mediaDetail = data.mediaCoverage ? `สื่อผ่านครบทั้งวิดีโอและ Podcast ${data.mediaCoverage.completeSessions} / ${data.mediaCoverage.requiredSessions} ครั้งตามเกณฑ์ ${data.mediaCoverage.track === "practical" ? "ปฏิบัติ" : "ทฤษฎี"}` : "รายงานรุ่นเดิมไม่มีผลความครอบคลุมสื่อ";
    if (scoreCard) scoreCard.innerHTML = score.suppressed ? `<div><span>ระงับการสรุป Checklist GN</span><strong>รอตรวจการแบ่งครั้ง</strong><small>กรุณายืนยันตารางแบ่งครั้งเรียนก่อน</small></div>` : `<div><span>ผลตรวจ Checklist GN</span><strong>ไม่มีคะแนน 110</strong><small>ตรวจโครงสร้างครบกรอบ 15 ครั้ง</small></div><div class="${mediaStatus}"><strong>${thai(mediaStatus)}</strong><small>${text(mediaDetail)} · ผู้ตรวจยังต้องสรุปข้อที่ใช้ดุลยพินิจ</small></div>`;
  }
  const updateGrGsTotal = () => {
    if (score.scoringMode !== "grgs_110" || score.suppressed) return;
    const instructorAlreadyCounted = ["pass","pass_tolerance"].includes(data.weeks[0]?.checklist?.[1]?.status);
    const automatic = Math.min(Number(score.automaticMax || 105), Number(score.automatic || 0) + (instructorConfirmed && !instructorAlreadyCounted ? 1 : 0));
    const card = document.querySelector(".score-card strong");
    if (card) card.textContent = (automatic + manualConfirmed) + " / 110";
    const detail = document.querySelector(".score-card small");
    if (detail) detail.textContent = "ระบบและผู้ตรวจยืนยันแล้ว " + automatic + " / 105 คะแนน · ตารางที่ 3 ผู้ตรวจยืนยัน " + manualConfirmed + " / 5 คะแนน";
  };
  document.querySelector("#save-session-mapping")?.addEventListener("click", async (event) => {
    const button = event.currentTarget;
    const message = document.querySelector("#session-mapping-message");
    const mappings = Object.fromEntries([...document.querySelectorAll(".session-mapping-choice")].map((select) => [decodeURIComponent(select.dataset.sectionKey),Number(select.value)]));
    button.disabled = true;
    if (message) message.textContent = "กำลังบันทึกและคำนวณผลใหม่…";
    const response = await chrome.runtime.sendMessage({type:"SAVE_SESSION_MAPPING",reportId:data.id,courseUrl:data.courseUrl,mappings}).catch((error) => ({ok:false,error:error.message}));
    if (!response?.ok) {
      button.disabled = false;
      if (message) message.textContent = response?.error || "บันทึกไม่สำเร็จ";
      return;
    }
    location.reload();
  });
  document.querySelector(".instructor-decision")?.addEventListener("change", async (event) => {
    instructorDecision = event.target.value;
    instructorConfirmed = instructorDecision === "complete";
    reviewerState.instructor_information_status = instructorDecision;
    reviewerState.instructor_information = instructorConfirmed;
    reviewerChecklist[data.courseUrl] = reviewerState;
    await chrome.storage.local.set({reviewerChecklist});
    const statusCell = event.target.closest("tr")?.lastElementChild;
    const rowStatus = instructorDecision === "complete" ? "pass" : instructorDecision === "missing" ? "fail" : "needs_review";
    if (statusCell) statusCell.innerHTML = statusBadge(rowStatus);
    const message = event.target.closest(".instructor-review")?.querySelector(".instructor-message");
    if (message) message.textContent = instructorDecision === "missing" ? "บันทึกเป็นไม่ผ่าน และไม่ถือเป็นรายการค้างตรวจ" : instructorDecision === "complete" ? "ผู้ตรวจยืนยันว่าข้อมูลครบ" : "กรุณาเลือกผลหลังตรวจหลักฐาน";
    updateGrGsTotal();
  });
  if (score.scoringMode === "grgs_110") {
    const manualChecks = [
      ["student_meetings", "การจัดให้มีการพบนักศึกษา", "กำหนดตารางพบนักศึกษารวม 3 ครั้ง"],
      ["video_quality", "คุณภาพวิดีโอบันทึกการสอน", "ระดับ B+ ขึ้นไป (รายวิชานอกแผน ระดับ B ขึ้นไป)"],
      ["media_placement", `การวางสื่อใน ${platformName}`, "วิดีโอและ Podcast เป็นลิงก์ ไม่อัปโหลดไฟล์โดยตรง"],
      ["submission_policy", "การส่งงานของนักศึกษา", `ไม่กำหนดให้นำส่งงานภายใน ${platformName}`],
      ["backup", "การสำรองเนื้อหา", "จัดเก็บเนื้อหาและวิดีโอตามช่วงเวลาที่มหาวิทยาลัยกำหนด"]
    ];
    const { manualChecklist = {} } = await chrome.storage.local.get("manualChecklist");
    const state = manualChecklist[data.courseUrl] || {};
    const section = document.createElement("section");
    section.className = "week-card";
    section.innerHTML = "<h2>ตารางที่ 3 — ข้อกำหนดภาพรวม (ผู้ตรวจบันทึกเอง)</h2><p class='muted'>ข้อละ 1 คะแนน ระบบไม่ตรวจแทน เพราะต้องใช้ดุลยพินิจหรือข้อมูลนอกหน้าเรียน</p><table><tr><th>#</th><th>หัวข้อ</th><th>เกณฑ์ย่อ</th><th>ผู้ตรวจยืนยัน</th></tr>" + manualChecks.map((item, index) => "<tr><td>" + (index + 1) + "</td><td>" + item[1] + "</td><td>" + item[2] + "</td><td><input class='manual-check' type='checkbox' data-key='" + item[0] + "'" + (state[item[0]] ? " checked" : "") + "></td></tr>").join("") + "</table>";
    document.querySelector("#report").append(section);
    const updateManualTotal = () => {
      manualConfirmed = manualChecks.filter((item) => state[item[0]]).length;
      updateGrGsTotal();
    };
    updateManualTotal();
    section.addEventListener("change", async (event) => {
      const input = event.target.closest(".manual-check");
      if (!input) return;
      state[input.dataset.key] = input.checked;
      manualChecklist[data.courseUrl] = state;
      await chrome.storage.local.set({manualChecklist});
      updateManualTotal();
    });
  }
  if (reviewItems.length) {
    const reviewRows = reviewItems.map((item) => {
      const activityIndex = data.activities.indexOf(item);
      const reason = item.kind === "video" && requiresMediaReview(item)
        ? item.durationSeconds ? `ระบบอ่านเวลาได้ ${clock(item.durationSeconds)} — ให้ผู้ตรวจเลือกว่าจะนำไปใช้หรือไม่นับ` : "เปิดคลิปได้แต่ยังไม่มีเวลาจริง — ต้องเปิดคลิปและดึงเวลาให้สำเร็จก่อน จึงจะเลือกใช้เวลาคิดคะแนนได้"
        : item.classification?.contextConflict ? "ชื่อรายการและป้ายกลุ่มขัดกัน จึงต้องตรวจทาน" : "ไม่มีหลักฐานจากชื่อหรือป้ายที่ยืนยันประเภทได้";
      const control = item.classification?.contextConflict
        ? `<div><select class="classification-review-choice" data-activity-index="${activityIndex}" aria-label="ยืนยันประเภท ${text(item.title)}"><option value="pending">ยังไม่ตัดสิน</option><option value="confirm_current">ยืนยันตามชื่อรายการ — ${text(simpleEvidenceType(item))}</option><option value="pre_recorded">เปลี่ยนเป็นวิดีโอการสอนล่วงหน้า</option><option value="exclude">ไม่นับรายการนี้</option></select></div>`
        : item.kind === "video_candidate"
        ? `<div><select class="classification-review-choice" data-activity-index="${activityIndex}" aria-label="ยืนยันประเภท ${text(item.title)}"><option value="pending">ยังไม่ตัดสิน</option><option value="pre_recorded">นับเป็นวิดีโอการสอนล่วงหน้า</option><option value="exclude">ไม่นับรายการนี้</option></select></div>`
        : item.kind === "video" && requiresMediaReview(item)
        ? `<div><select class="media-review-choice" data-activity-index="${activityIndex}" aria-label="การใช้เวลาคลิป ${text(item.title)}"><option value="pending"${!item.mediaReviewDecision || item.mediaReviewDecision === "pending" ? " selected" : ""}>ยังไม่ตัดสิน</option><option value="use"${item.mediaReviewDecision === "use" ? " selected" : ""}${item.durationSeconds ? "" : " disabled"}>ใช้เวลาที่อ่านได้คิดคะแนน</option><option value="recording"${item.mediaReviewDecision === "recording" ? " selected" : ""}>ไม่นับ — สอนย้อนหลัง</option><option value="activity"${item.mediaReviewDecision === "activity" ? " selected" : ""}>ไม่นับ — ประกอบกิจกรรม</option><option value="supplementary"${item.mediaReviewDecision === "supplementary" ? " selected" : ""}>ไม่นับ — สื่อเสริม</option></select>${!item.durationSeconds && item.externalUrl ? `<a class="inline-action" href="${text(item.externalUrl)}" target="_blank" rel="noopener">เปิดคลิปเพื่อให้ระบบอ่านเวลา</a>` : ""}</div>`
        : "";
      return `<tr><td>${text(item.section)}</td><td>${text(item.title)}</td><td>${reason}${control}</td></tr>`;
    }).join("");
    const reviewSection = document.createElement("section");
    reviewSection.innerHTML = "<h2>รายการที่ต้องยืนยันประเภท</h2><table><tr><th>Week/Section</th><th>รายการ</th><th>เหตุผลที่ยังไม่ชัด</th></tr>" + reviewRows + "</table>";
    document.querySelector("#report").prepend(reviewSection);
  }
  if (unmappedItems.length) {
    const rows = unmappedItems.map((item) => `<tr><td>${text(item.section || "ไม่ระบุ")}</td><td>${text(item.title)}</td><td>${text(item.kind)}</td><td>${text(item.mappingIssue || "ไม่ใช้คำนวณจนกว่าจะระบุครั้งเรียนได้")}</td></tr>`).join("");
    const section = document.createElement("section");
    section.innerHTML = `<h2>รายการที่ยังจับคู่ครั้งเรียนไม่ได้</h2><table><tr><th>Section เดิม</th><th>รายการ</th><th>ประเภท</th><th>ผลต่อรายงาน</th></tr>${rows}</table>`;
    document.querySelector("#report").prepend(section);
  }
  const evidenceActivities = data.activities.filter((item) => evidenceKinds.includes(item.kind));
  const reportTables = [...document.querySelectorAll("#report > table")];
  const evidenceTable = reportTables.at(-1);
  if (evidenceTable) {
    const evidenceFilter = document.querySelector("#evidence-filter");
    evidenceFilter?.addEventListener("change", () => {
      const chosen = evidenceFilter.value;
      for (const row of evidenceTable.querySelectorAll("tr[data-evidence-kind]")) {
        row.hidden = chosen !== "all" && row.dataset.evidenceKind !== chosen;
      }
    });
    evidenceActivities.forEach((item, index) => {
      if (item.kind !== "file" && item.kind !== "file_link") return;
      const state = item.fileVerification || (item.isPdf ? "pdf" : "");
      const message = item.resource?.previewNote || (state === "pdf" ? (item.resource?.sourceType === "moodle_activity_icon" ? "ยืนยันว่าเป็น PDF จากไอคอนชนิดไฟล์ของ Moodle" : "ยืนยันว่าเป็น PDF จากปลายทางไฟล์แล้ว") : state === "not_pdf" ? "ยืนยันแล้วว่าไฟล์ปลายทางไม่ใช่ PDF" : state === "unresolved" ? "เปิดรายการได้ แต่ยังตามชนิดไฟล์ปลายทางไม่ถึง — ต้องตรวจทาน" : "");
      if (!message) return;
      const cell = evidenceTable.rows[index + 1]?.cells[6];
      const firstText = [...(cell?.childNodes || [])].find((node) => node.nodeType === Node.TEXT_NODE);
      if (firstText) firstText.textContent = message;
    });
    evidenceActivities.forEach((item, index) => {
      const evidence = item.classification?.evidence || [];
      if (!evidence.length && !item.classification?.contextConflict) return;
      const cell = evidenceTable.rows[index + 1]?.cells[6];
      if (!cell) return;
      const detail = document.createElement("div");
      detail.className = "muted";
      const reasons = evidence.map((entry) => entry.source + ": " + entry.value).join(" · ");
      detail.textContent = "หลักฐานการจัดประเภท: " + reasons + (item.classification?.contextConflict ? " · ป้ายกลุ่มต่างจากชนิดรายการ" : "");
      cell.append(detail);
    });
  }
  document.querySelector("#report").addEventListener("click", async (event) => {
    const button = event.target.closest("button.decision");
    if (!button) return;
    const activity = reviewCandidates[Number(button.dataset.candidate)];
    if (!activity) return;
    if (activity.evidenceType === "assignment_image") {
      const { activityOverrides = {} } = await chrome.storage.local.get("activityOverrides");
      activityOverrides[data.courseUrl] ||= {};
      activityOverrides[data.courseUrl][activity.href] = button.dataset.decision;
      await chrome.storage.local.set({ activityOverrides });
      button.closest("td").textContent = "บันทึกแล้ว — กรุณารันตรวจรายวิชานี้ใหม่เพื่อคำนวณผล";
      return;
    }
    const { videoOverrides = {} } = await chrome.storage.local.get("videoOverrides");
    videoOverrides[data.courseUrl] ||= {};
    videoOverrides[data.courseUrl][activity.href] = button.dataset.decision;
    await chrome.storage.local.set({ videoOverrides });
    button.closest("td").textContent = "บันทึกแล้ว — กรุณารันตรวจรายวิชานี้ใหม่เพื่อคำนวณเวลา";
  });
  await installBatchReview(data);
  installReportWorkspace(data, unmappedItems);
  document.querySelector("#csv").onclick=()=>{const tr=value=>translateThai(String(value??""),reportLanguage);const rows=[[tr("ครั้ง"),tr("รายการ"),tr("ประเภท"),"URL",tr("เวลาสื่อ"),tr("เวลาอ่าน"),tr("ผล")],...data.activities.map(a=>[tr(a.section),a.title,tr(simpleEvidenceType(a)),a.externalUrl||"",a.durationSeconds||"",a.readElapsedMs ?? "",tr(a.accessNote||a.linkStatus||"")])];const csv=rows.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(',')).join('\n');const url=URL.createObjectURL(new Blob(["\uFEFF"+csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download=exportBaseName+".csv";a.click();URL.revokeObjectURL(url);};
}

function installReportWorkspace(data, unmappedItems) {
  const root=document.querySelector("#report"),tabs=document.querySelector("#report-tabs"); if(!root||!tabs)return;
  const tasks=[];
  const sessionNumber=(value)=>{const match=String(value||"").match(/(?:ครั้งที่\s*|Week\s*|Lecture\s*)(\d+)/i);return match?Number(match[1]):0;};
  const addTask=(session,title,detail,source,kind,url="")=>tasks.push({session,title,detail,source,kind,url});
  const instructor=root.querySelector(".instructor-decision");
  if(instructor?.value==="pending")addTask(1,"ยืนยันข้อมูลผู้สอน","ตรวจรูป ชื่อ และช่องทางติดต่อ แล้วเลือกผล",instructor,"select");
  for(const selector of [".classification-review-choice",".media-review-choice"]){
    for(const select of root.querySelectorAll(selector)){
      if(select.value!=="pending")continue;
      const item=data.activities[Number(select.dataset.activityIndex)];
      addTask(item?.auditSession||sessionNumber(item?.section),item?.title||"ยืนยันประเภทรายการ",select.getAttribute("aria-label")||"เลือกผลการตรวจ",select,"select");
    }
  }
  for(const wrapper of root.querySelectorAll(".podcast-review")){
    const confirm=wrapper.querySelector(".podcast-confirm");
    if(confirm?.checked||confirm?.disabled)continue;
    const item=data.activities[Number(wrapper.dataset.podcastIndex)];
    addTask(item?.auditSession||sessionNumber(item?.section),`Podcast: ${item?.title||"คลิปเสียง"}`,"กรอกเวลาจากตัวเล่นและยืนยัน ก่อนกดบันทึกทั้งหมด",wrapper,"podcast",item?.externalUrl);
  }
  const dashboard=document.createElement("section");dashboard.className="task-dashboard";dashboard.dataset.panel="tasks";
  dashboard.innerHTML=`<div class="task-heading"><div><span class="eyebrow">งานที่ผู้ตรวจต้องยืนยัน</span><h2>${tasks.length?`${tasks.length} รายการที่รอคำตัดสิน`:"ไม่มีรายการรอยืนยัน"}</h2></div><span class="task-total">${tasks.length}</span></div><p class="task-help">เลือกผลหรือยืนยันเวลาในหน้านี้ แล้วกด “บันทึกและยืนยันทั้งหมด” ผลจะสะท้อนในรายงานหลังบันทึก ข้อที่ระบบตรวจว่าไม่ผ่านยังคงเป็นไม่ผ่าน และไม่รวมในรายการรอยืนยัน</p>`;
  const groups=new Map();
  for(const [index,task] of tasks.entries()){
    const key=task.session>=1&&task.session<=15?task.session:0;
    if(!groups.has(key)){const group=document.createElement("details");group.className="task-session";group.open=groups.size===0;group.innerHTML=`<summary>${key?`ครั้งที่ ${key}`:"โครงสร้าง / ยังไม่ทราบครั้ง"} <span class="task-session-count"></span></summary><div class="task-list"></div>`;groups.set(key,group);dashboard.append(group);}
    const article=document.createElement("article");article.className="task-item";
    const copy=document.createElement("div");copy.className="task-copy";
    const heading=document.createElement("strong");heading.textContent=task.title;
    const detail=document.createElement("p");detail.textContent=task.detail;
    copy.append(heading,detail);article.append(copy);
    if(task.kind==="select"&&task.source){
      const select=task.source.cloneNode(true);select.className="task-choice";select.removeAttribute("data-activity-index");
      select.addEventListener("change",()=>{task.source.value=select.value;task.source.dispatchEvent(new Event("change",{bubbles:true}));article.classList.toggle("task-item-resolved",select.value!=="pending");});
      article.append(select);
    }else if(task.kind==="podcast"&&task.source){
      const controls=document.createElement("div");controls.className="task-podcast";
      let minutesInput=null,secondsInput=null;
      for(const className of ["podcast-minutes","podcast-seconds"]){
        const original=task.source.querySelector(`.${className}`),input=original?.cloneNode(true);
        if(!input)continue;input.className="task-time-part";input.addEventListener("input",()=>{input.value=input.value.replace(/\D/g,"").slice(0,2);original.value=input.value;original.dispatchEvent(new Event("input",{bubbles:true}));const originalConfirm=task.source.querySelector(".podcast-confirm");originalConfirm.checked=false;originalConfirm.dispatchEvent(new Event("change",{bubbles:true}));article.querySelector(".task-confirm").checked=false;if(className==="podcast-minutes"&&input.value.length===2&&secondsInput){secondsInput.focus();secondsInput.select();}});
        if(className==="podcast-minutes")minutesInput=input;else{secondsInput=input;input.addEventListener("keydown",event=>{if(event.key==="Backspace"&&!input.value&&minutesInput){minutesInput.focus();minutesInput.select();}});}
        const label=document.createElement("label");label.textContent=className==="podcast-minutes"?"นาที ":"วินาที ";label.append(input);controls.append(label);
      }
      const originalConfirm=task.source.querySelector(".podcast-confirm"),label=document.createElement("label"),confirm=originalConfirm.cloneNode(true);
      confirm.className="task-confirm";confirm.addEventListener("change",()=>{originalConfirm.checked=confirm.checked;originalConfirm.dispatchEvent(new Event("change",{bubbles:true}));article.classList.toggle("task-item-resolved",confirm.checked);});label.append(confirm," ยืนยันเวลา");controls.append(label);article.append(controls);
      if(task.url){const link=document.createElement("a");link.href=task.url;link.target="_blank";link.rel="noopener";link.textContent="เปิดคลิปเสียง";article.append(link);}
    }
    groups.get(key).querySelector(".task-list").append(article);
  }
  for(const group of groups.values())group.querySelector(".task-session-count").textContent=`${group.querySelectorAll(".task-item").length} รายการ`;
  for(const [index,[,group]] of [...groups.entries()].sort((a,b)=>(a[0]||99)-(b[0]||99)).entries()){group.open=index===0;dashboard.append(group);}
  if(!tasks.length){const done=document.createElement("p");done.className="task-done";done.textContent="ไม่มีรายการที่รอคำตัดสินเรื่องข้อมูลผู้สอน ประเภท หรือเวลา Podcast (ข้อไม่ผ่านยังดูได้ในผลรายครั้ง และตารางที่ 3 อยู่ด้านล่าง)";dashboard.append(done);}
  root.prepend(dashboard);
  let mode="overview";
  for(const child of [...root.children]){
    const heading=child.tagName==="H2"?child.textContent.trim():"";
    if(child===dashboard){child.dataset.panel="tasks";continue;}
    if(child.matches(".batch-review-toolbar,.internal-review")||child.querySelector?.(".manual-check")){child.dataset.panel="tasks";continue;}
    if(child.querySelector?.(".classification-review-choice,.media-review-choice")){child.dataset.panel="evidence";continue;}
    if(heading.startsWith("รายการที่ต้อง")||heading.startsWith("รายการที่ยังจับคู่"))mode="tasks";
    else if(heading==="หลักฐานลิงก์")mode="evidence";
    else if(heading==="เวลาที่ใช้ตรวจ")mode="system";
    else if(heading==="สรุปภาพรวม")mode="overview";
    if(child.classList.contains("teacher-summary"))mode="overview";
    else if(child.classList.contains("week-card")&&!child.classList.contains("teacher-summary"))mode="sessions";
    if(child.classList.contains("evidence-filter")||child.classList.contains("evidence-table"))mode="evidence";
    child.dataset.panel ||= mode;
  }
  const labels={overview:"ภาพรวม",tasks:"งานที่ต้องทำ",sessions:"ผลรายครั้ง",evidence:"หลักฐาน",system:"การทำงานระบบ"};
  tabs.innerHTML=Object.entries(labels).map(([key,label])=>`<button data-tab="${key}">${label}${key==="tasks"&&tasks.length?` <span>${tasks.length}</span>`:""}</button>`).join("");tabs.hidden=false;
  const show=(panel)=>{for(const child of root.children)child.hidden=child.dataset.panel!==panel;for(const button of tabs.querySelectorAll("button"))button.classList.toggle("active",button.dataset.tab===panel);history.replaceState(null,"",`#${panel}`);scrollTo({top:tabs.offsetTop-8,behavior:"smooth"});};
  tabs.addEventListener("click",event=>{const button=event.target.closest("button[data-tab]");if(button)show(button.dataset.tab);});
  show(location.hash.slice(1) in labels?location.hash.slice(1):(tasks.length?"tasks":"overview"));
}
