export const SUPPORTED_LANGUAGES = Object.freeze(["th", "en", "zh-CN", "ja"]);

const UI = {
  "ศูนย์รวมการตรวจรายวิชา": {en:"Course audit center", "zh-CN":"课程审核中心", ja:"コース監査センター"},
  "เปิดคิวตรวจรายวิชา": {en:"Open course audit queue", "zh-CN":"打开课程审核队列", ja:"コース監査キューを開く"},
  "กำลังอ่านสถานะคิว…": {en:"Reading queue status…", "zh-CN":"正在读取队列状态…", ja:"キューの状態を確認中…"},
  "รายงานผลย้อนหลัง": {en:"Saved reports", "zh-CN":"历史报告", ja:"保存済みレポート"},
  "กำลังอ่านจำนวนรายงาน…": {en:"Counting saved reports…", "zh-CN":"正在统计报告…", ja:"レポート数を確認中…"},
  "ตรวจโครงสร้างรายวิชานี้": {en:"Check this course structure", "zh-CN":"检查本课程结构", ja:"このコース構成を確認"},
  "กำลังตรวจสอบหน้าที่เปิดอยู่…": {en:"Checking the open page…", "zh-CN":"正在检查当前页面…", ja:"開いているページを確認中…"},
  "การตรวจสื่อ รวมถึง H5P และ YouTube ทำงานจากคิวในเบื้องหลังอัตโนมัติ": {en:"Media checks, including H5P and YouTube, run automatically from the background queue.", "zh-CN":"媒体检查（包括 H5P 和 YouTube）会在后台队列中自动运行。", ja:"H5P と YouTube を含むメディア検査は、バックグラウンドのキューで自動実行されます。"},
  "คิวตรวจรายวิชา": {en:"Course audit queue", "zh-CN":"课程审核队列", ja:"コース監査キュー"},
  "ตรวจหลายวิชาอย่างเป็นลำดับและติดตามสถานะได้ในหน้าเดียว": {en:"Audit multiple courses in order and track them on one page.", "zh-CN":"按顺序审核多个课程，并在一个页面中跟踪状态。", ja:"複数のコースを順番に監査し、1ページで進捗を確認できます。"},
  "เพิ่มรายวิชา": {en:"Add course", "zh-CN":"添加课程", ja:"コースを追加"},
  "ลิงก์รายวิชา d-Learning หรือ i-Learning": {en:"d-Learning or i-Learning course URL", "zh-CN":"d-Learning 或 i-Learning 课程链接", ja:"d-Learning または i-Learning のコースURL"},
  "ประเภท": {en:"Type", "zh-CN":"类型", ja:"種別"},
  "หน่วยกิต": {en:"Credits", "zh-CN":"学分", ja:"単位"},
  "ลักษณะวิชา GN": {en:"GN course track", "zh-CN":"GN 课程类型", ja:"GN コース区分"},
  "ทฤษฎี — 15 ครั้ง": {en:"Theory — 15 sessions", "zh-CN":"理论 — 15 次", ja:"理論 — 15回"},
  "ปฏิบัติ — อย่างน้อย 7 ครั้ง": {en:"Practical — at least 7 sessions", "zh-CN":"实践 — 至少 7 次", ja:"実習 — 7回以上"},
  "เพิ่มเข้าคิว": {en:"Add to queue", "zh-CN":"添加到队列", ja:"キューに追加"},
  "ควบคุมคิว": {en:"Queue controls", "zh-CN":"队列控制", ja:"キュー操作"},
  "เริ่มตรวจตามคิว": {en:"Start queue", "zh-CN":"开始审核", ja:"監査を開始"},
  "พักคิว": {en:"Pause", "zh-CN":"暂停", ja:"一時停止"},
  "หยุดคิว": {en:"Stop", "zh-CN":"停止", ja:"停止"},
  "เริ่มต่อ": {en:"Resume", "zh-CN":"继续", ja:"再開"},
  "ล้างรายการที่จบแล้ว": {en:"Clear completed", "zh-CN":"清除已完成项", ja:"完了項目を消去"},
  "เครื่องมือวิเคราะห์": {en:"Diagnostic tools", "zh-CN":"诊断工具", ja:"診断ツール"},
  "บันทึกข้อมูลวิเคราะห์การตรวจ": {en:"Export audit diagnostics", "zh-CN":"导出审核诊断数据", ja:"監査診断データを保存"},
  "เก็บเฉพาะขั้นตอนตรวจและจำนวนแท็บในเครื่อง ไม่ส่งข้อมูลออกอัตโนมัติ": {en:"Stores only local audit steps and tab counts; no data is sent automatically.", "zh-CN":"仅保存本机审核步骤和标签页数量，不会自动发送数据。", ja:"端末内の監査手順とタブ数だけを保存し、データは自動送信しません。"},
  "คิวยังไม่เริ่มทำงาน": {en:"The queue has not started", "zh-CN":"队列尚未开始", ja:"キューはまだ開始されていません"},
  "รายการในคิว": {en:"Queued courses", "zh-CN":"队列中的课程", ja:"キュー内のコース"},
  "ประวัติรายงาน": {en:"Report history", "zh-CN":"报告历史", ja:"レポート履歴"},
  "เก็บผลตรวจล่าสุด 20 รายงาน เมื่อมีรายงานที่ 21 ระบบจะแทนที่รายงานเก่าที่สุดโดยอัตโนมัติ": {en:"The latest 20 reports are kept. When report 21 is created, the oldest report is replaced automatically.", "zh-CN":"保留最近 20 份报告。生成第 21 份报告时，系统会自动替换最旧的报告。", ja:"最新20件を保存します。21件目を作成すると、最も古いレポートを自動で入れ替えます。"},
  "ค้นหา": {en:"Search", "zh-CN":"搜索", ja:"検索"},
  "เปรียบเทียบที่เลือก": {en:"Compare selected", "zh-CN":"比较所选项", ja:"選択項目を比較"},
  "ผลตรวจโครงสร้างหน้าเว็บ": {en:"Page structure check", "zh-CN":"页面结构检查结果", ja:"ページ構成の検査結果"},
  "Week/Lecture/Section": {en:"Week/Lecture/Section", "zh-CN":"周/讲次/章节", ja:"週/講義/セクション"},
  "ป้ายกลุ่มที่ระบบเห็น": {en:"Detected group label", "zh-CN":"检测到的分组标签", ja:"検出したグループラベル"},
  "รายการที่ระบบอ่าน": {en:"Detected item", "zh-CN":"检测到的项目", ja:"検出した項目"},
  "ชนิด": {en:"Type", "zh-CN":"类型", ja:"種類"},
  "ดาวน์โหลดข้อมูลตรวจโครงสร้าง": {en:"Download structure data", "zh-CN":"下载结构数据", ja:"構成データをダウンロード"},
  "รายงานตรวจ SPU Learning": {en:"SPU Learning audit report", "zh-CN":"SPU Learning 审核报告", ja:"SPU Learning 監査レポート"},
  "เปิดหน้ารายวิชา": {en:"Open course", "zh-CN":"打开课程", ja:"コースを開く"},
  "พิมพ์ / บันทึก PDF": {en:"Print / Save PDF", "zh-CN":"打印 / 保存 PDF", ja:"印刷 / PDF保存"},
  "ดาวน์โหลด CSV": {en:"Download CSV", "zh-CN":"下载 CSV", ja:"CSVをダウンロード"},
  "กำลังเปิดรายงาน…": {en:"Opening report…", "zh-CN":"正在打开报告…", ja:"レポートを開いています…"},
  "กำลังตรวจรายวิชา": {en:"Auditing course", "zh-CN":"正在审核课程", ja:"コースを監査中"},
  "กำลังเตรียมข้อมูล…": {en:"Preparing data…", "zh-CN":"正在准备数据…", ja:"データを準備中…"},
  "กำลังเริ่มงาน…": {en:"Starting…", "zh-CN":"正在启动…", ja:"開始しています…"},
  "หยุดตรวจ": {en:"Stop audit", "zh-CN":"停止审核", ja:"監査を停止"},
  "เปิดรายงาน": {en:"Open report", "zh-CN":"打开报告", ja:"レポートを開く"},
  "สลับธีม": {en:"Switch theme", "zh-CN":"切换主题", ja:"テーマを切り替え"}
};

Object.assign(UI, {
  "โหมดสว่าง":{en:"Light mode","zh-CN":"浅色模式",ja:"ライトモード"}, "โหมดมืด":{en:"Dark mode","zh-CN":"深色模式",ja:"ダークモード"},
  "ต้องการอีก":{en:"Needs","zh-CN":"还需要",ja:"あと"}, "คะแนนเพื่อถึง 80":{en:"points to reach 80","zh-CN":"分即可达到 80 分",ja:"点で80点に到達"},
  "คะแนนไม่มีหลักฐานสำคัญค้าง":{en:"No scoring evidence is pending","zh-CN":"没有影响评分的待确认信息",ja:"採点に影響する未確認根拠はありません"}, "ยังมีหลักฐานที่มีผลต่อคะแนนค้าง":{en:"Scoring evidence still pending","zh-CN":"仍有影响评分的证据待确认",ja:"採点に影響する根拠が未確認です"},
  "รายงานตรวจ":{en:"Audit report","zh-CN":"审核报告",ja:"監査レポート"}, "รุ่น":{en:"Version","zh-CN":"版本",ja:"バージョン"}, "ตรวจเมื่อ":{en:"Audited","zh-CN":"审核时间",ja:"監査日時"}, "รอบ":{en:"Run","zh-CN":"批次",ja:"実行"},
  "ไม่มีงานค้าง — เพิ่มรายวิชาได้ในหน้าคิว":{en:"No pending work — add a course in the queue.","zh-CN":"没有待处理任务 — 可在队列中添加课程。",ja:"保留中の作業はありません。キューでコースを追加できます。"},
  "รายงานที่บันทึกไว้":{en:"saved reports","zh-CN":"份已保存报告",ja:"件の保存済みレポート"}, "เปิดหน้ารายวิชา d-Learning หรือ i-Learning ก่อน":{en:"Open a d-Learning or i-Learning course page first.","zh-CN":"请先打开 d-Learning 或 i-Learning 课程页面。",ja:"先に d-Learning または i-Learning のコースページを開いてください。"},
  "ภาพรวม":{en:"Overview","zh-CN":"概览",ja:"概要"}, "งานที่ต้องทำ":{en:"Required actions","zh-CN":"待处理事项",ja:"対応が必要な項目"},
  "ผลรายครั้ง":{en:"Session results","zh-CN":"各次结果",ja:"各回の結果"}, "หลักฐาน":{en:"Evidence","zh-CN":"证据",ja:"根拠"}, "การทำงานระบบ":{en:"System activity","zh-CN":"系统运行",ja:"システム動作"},
  "สรุปจุดที่ควรแก้ไขสำหรับอาจารย์ผู้สอน":{en:"Required corrections for the instructor","zh-CN":"教师需要修改的项目",ja:"担当教員が修正すべき項目"},
  "ไม่พบจุดที่ต้องแก้ไขตามเกณฑ์ที่ระบบตรวจได้":{en:"No required corrections were found by the automated checks.","zh-CN":"自动检查未发现需要修改的项目。",ja:"自動検査では修正が必要な項目は見つかりませんでした。"},
  "รายการที่ยังตรวจสอบไม่ได้":{en:"Items requiring review","zh-CN":"需要人工确认的项目",ja:"確認が必要な項目"},
  "ต้องแก้ไข:":{en:"Fix required:","zh-CN":"需要修改：",ja:"要修正："}, "ต้องตรวจสอบ:":{en:"Review required:","zh-CN":"需要确认：",ja:"要確認："},
  "ส่วนแนะนำรายวิชา":{en:"course introduction","zh-CN":"课程介绍部分",ja:"コース紹介"},
  "คะแนนเบื้องต้นจากระบบ":{en:"Preliminary automated score","zh-CN":"系统初步评分",ja:"システムによる暫定得点"},
  "คะแนนชั่วคราวจากข้อมูลที่อ่านได้":{en:"Provisional score from available evidence","zh-CN":"根据已读取证据计算的暂定分数",ja:"取得済み根拠による暫定得点"},
  "ยังไม่ผ่านเกณฑ์":{en:"Below the required score","zh-CN":"尚未达到标准",ja:"基準未達"}, "ผ่านเกณฑ์เบื้องต้น":{en:"Preliminary pass","zh-CN":"初步通过",ja:"暫定合格"},
  "ผ่าน":{en:"Pass","zh-CN":"通过",ja:"合格"}, "ไม่ผ่าน":{en:"Fail","zh-CN":"不通过",ja:"不合格"}, "ต้องตรวจทาน":{en:"Review required","zh-CN":"需要复核",ja:"要確認"},
  "สรุปภาพรวม":{en:"Overview summary","zh-CN":"总体概览",ja:"全体概要"}, "เวลาที่ใช้ตรวจ":{en:"Audit timing","zh-CN":"审核用时",ja:"監査時間"},
  "หลักฐานลิงก์":{en:"Link evidence","zh-CN":"链接证据",ja:"リンクの根拠"}, "กรองประเภท":{en:"Filter by type","zh-CN":"按类型筛选",ja:"種類で絞り込み"},
  "ทั้งหมด":{en:"All","zh-CN":"全部",ja:"すべて"}, "เอกสาร":{en:"Documents","zh-CN":"文档",ja:"文書"}, "วิดีโอล่วงหน้า":{en:"Pre-recorded video","zh-CN":"预录教学视频",ja:"事前収録動画"},
  "วิดีโอย้อนหลัง":{en:"Recorded live class","zh-CN":"直播录播",ja:"ライブ授業録画"}, "กิจกรรม/Assignment":{en:"Activity/Assignment","zh-CN":"活动/作业",ja:"活動/課題"}, "อื่น ๆ":{en:"Other","zh-CN":"其他",ja:"その他"},
  "ครั้ง":{en:"Session","zh-CN":"课次",ja:"回"}, "รายการ":{en:"Item","zh-CN":"项目",ja:"項目"}, "ปลายทาง":{en:"Destination","zh-CN":"目标链接",ja:"リンク先"},
  "เวลาสื่อ":{en:"Media duration","zh-CN":"媒体时长",ja:"メディア時間"}, "เวลาอ่าน":{en:"Read time","zh-CN":"读取时间",ja:"読取時間"}, "หมายเหตุ":{en:"Notes","zh-CN":"备注",ja:"注記"},
  "ผล":{en:"Result","zh-CN":"结果",ja:"結果"}, "เกณฑ์":{en:"Requirement","zh-CN":"标准",ja:"基準"}, "หัวข้อ":{en:"Criterion","zh-CN":"检查项",ja:"項目"},
  "ผู้ตรวจยืนยัน":{en:"Reviewer confirmation","zh-CN":"审核人确认",ja:"確認者の承認"}, "ยังไม่ตัดสิน":{en:"Not decided","zh-CN":"尚未决定",ja:"未決定"},
  "ไม่นับรายการนี้":{en:"Exclude this item","zh-CN":"不计入此项目",ja:"この項目を除外"}, "ใช้เวลาที่อ่านได้คิดคะแนน":{en:"Use detected duration for scoring","zh-CN":"使用检测到的时长计分",ja:"検出時間を採点に使用"},
  "ไม่นับ — สอนย้อนหลัง":{en:"Exclude — recorded live class","zh-CN":"不计入 — 直播录播",ja:"除外 — ライブ授業録画"}, "ไม่นับ — ประกอบกิจกรรม":{en:"Exclude — activity material","zh-CN":"不计入 — 活动材料",ja:"除外 — 活動用"},
  "ไม่นับ — สื่อเสริม":{en:"Exclude — supplementary material","zh-CN":"不计入 — 补充材料",ja:"除外 — 補足資料"},
  "งานที่ผู้ตรวจต้องยืนยัน":{en:"Items requiring reviewer confirmation","zh-CN":"需要审核人确认的项目",ja:"確認者の判断が必要な項目"},
  "ไม่มีรายการรอยืนยัน":{en:"No pending confirmations","zh-CN":"没有待确认项目",ja:"確認待ちはありません"},
  "บันทึกและยืนยันทั้งหมด":{en:"Save and confirm all","zh-CN":"保存并全部确认",ja:"すべて保存して確定"}, "ยืนยันผลแจ้งอาจารย์":{en:"Finalize instructor report","zh-CN":"确认教师报告",ja:"教員向け結果を確定"},
  "นาที":{en:"minutes","zh-CN":"分钟",ja:"分"}, "วินาที":{en:"seconds","zh-CN":"秒",ja:"秒"}, "ยืนยันเวลา":{en:"Confirm duration","zh-CN":"确认时长",ja:"時間を確認"},
  "เปิดคลิปเสียง":{en:"Open audio","zh-CN":"打开音频",ja:"音声を開く"}, "รายการที่ต้องยืนยันประเภท":{en:"Items requiring type confirmation","zh-CN":"需要确认类型的项目",ja:"種類の確認が必要な項目"},
  "รายการที่ยังจับคู่ครั้งเรียนไม่ได้":{en:"Items not mapped to a session","zh-CN":"尚未匹配课次的项目",ja:"授業回に未対応の項目"},
  "เพิ่มข้อมูลผู้สอนให้ครบ ได้แก่ รูป ชื่อ และช่องทางติดต่อ":{en:"Add complete instructor information: photo, name, and contact channel.","zh-CN":"补充完整的教师信息：照片、姓名和联系方式。",ja:"教員情報（写真、氏名、連絡先）をすべて追加してください。"},
  "เพิ่มข้อมูลแนะนำรายวิชาให้ครบ":{en:"Complete the course introduction.","zh-CN":"补充完整的课程介绍。",ja:"コース紹介を完成してください。"},
  "เพิ่มลิงก์ภายนอกสำหรับ AI Tutor":{en:"Add an external AI Tutor link.","zh-CN":"添加 AI Tutor 外部链接。",ja:"AI Tutor の外部リンクを追加してください。"},
  "เพิ่มกิจกรรมท้ายบท/Assignment จริง (Quiz ใน Moodle ไม่นับ)":{en:"Add an actual end activity/assignment; a Moodle Quiz does not count.","zh-CN":"添加实际的章末活动/作业；Moodle 测验不计入。",ja:"実際の章末活動／課題を追加してください。Moodle Quiz は対象外です。"},
  "เพิ่มเอกสารแผนการสอนที่เปิดตรวจสอบได้":{en:"Add an accessible teaching-plan document.","zh-CN":"添加可访问的教学计划文档。",ja:"確認可能な授業計画書を追加してください。"},
  "เพิ่มเอกสารประกอบการสอนที่เปิดตรวจสอบได้":{en:"Add accessible teaching materials.","zh-CN":"添加可访问的教学材料。",ja:"確認可能な講義資料を追加してください。"},
  "เพิ่มวิดีโอการสอนล่วงหน้า":{en:"Add a pre-recorded teaching video.","zh-CN":"添加预录教学视频。",ja:"事前収録の授業動画を追加してください。"},
  "เพิ่มเวลารวมของวิดีโอการสอนล่วงหน้าให้ครบตามเกณฑ์":{en:"Increase the total pre-recorded video duration to meet the requirement.","zh-CN":"增加预录教学视频总时长以达到标准。",ja:"事前収録動画の合計時間を基準まで増やしてください。"},
  "เพิ่มคลิปเสียง Podcast ผ่านลิงก์ภายนอกให้ครบตามเกณฑ์":{en:"Add external Podcast audio links to meet the requirement.","zh-CN":"添加符合标准的外部 Podcast 音频链接。",ja:"基準を満たす外部 Podcast 音声リンクを追加してください。"},
  "เปลี่ยน Podcast เป็นลิงก์ภายนอกที่เปิดตรวจสอบได้":{en:"Replace the uploaded Podcast with an accessible external link.","zh-CN":"将上传的 Podcast 改为可访问的外部链接。",ja:"アップロードした Podcast を確認可能な外部リンクに変更してください。"},
  "เพิ่มหรือเปลี่ยน Pre-test/Post-test เป็นลิงก์ภายนอก เช่น Google Form":{en:"Add or change the Pre-test/Post-test to an external link such as Google Forms.","zh-CN":"添加或将前测/后测改为外部链接，例如 Google 表单。",ja:"Pre-test／Post-test を Google フォームなどの外部リンクで追加または変更してください。"}
});

Object.assign(UI, {
  "ผ่านแบบผ่อนปรน":{en:"Pass within tolerance","zh-CN":"容差范围内通过",ja:"許容範囲内で合格"}, "ไม่บังคับ/ไม่มี":{en:"Not required/none","zh-CN":"不要求/无",ja:"対象外／なし"},
  "ใช้ชื่อครั้ง/สัปดาห์จากหัวข้อโดยตรง":{en:"Session/week taken directly from headings","zh-CN":"直接使用标题中的课次/周次",ja:"見出しの回／週を直接使用"}, "เริ่มครั้งที่ 1 จาก Section 0":{en:"Session 1 starts at Section 0","zh-CN":"第 1 次从 Section 0 开始",ja:"第1回は Section 0 から開始"},
  "Section 0 เป็นข้อมูลเกริ่น":{en:"Section 0 is introductory information","zh-CN":"Section 0 为介绍信息",ja:"Section 0 は導入情報"}, "เริ่มครั้งที่ 1 จาก Section 1":{en:"Session 1 starts at Section 1","zh-CN":"第 1 次从 Section 1 开始",ja:"第1回は Section 1 から開始"}, "ยังระบุรูปแบบไม่ได้":{en:"Mapping pattern unresolved","zh-CN":"尚无法确定映射模式",ja:"対応形式を特定できません"},
  "รอคะแนนตารางที่ 3":{en:"Awaiting Table 3 score","zh-CN":"等待表 3 评分",ja:"表3の得点待ち"}, "อ่านโครงสร้างไม่ครบ":{en:"Course structure incomplete","zh-CN":"课程结构读取不完整",ja:"コース構成の読取が不完全"}, "ยังจับคู่บางรายการไม่ได้":{en:"Some items are not mapped","zh-CN":"部分项目尚未匹配",ja:"一部の項目が未対応"},
  "ยังยืนยันประเภทรายการไม่ได้":{en:"Some item types are unconfirmed","zh-CN":"部分项目类型尚未确认",ja:"一部の項目種別が未確認"}, "ยังยืนยันหลักฐานบางรายการไม่ได้":{en:"Some evidence is unconfirmed","zh-CN":"部分证据尚未确认",ja:"一部の根拠が未確認"}, "ยังต้องยืนยันโครงสร้างครั้งเรียน":{en:"Session structure requires confirmation","zh-CN":"课次结构需要确认",ja:"授業回構成の確認が必要"},
  "ลิงก์/ไฟล์เอกสาร PDF":{en:"PDF link/file","zh-CN":"PDF 链接/文件",ja:"PDF リンク／ファイル"}, "วิดีโอ Record ย้อนหลัง":{en:"Recorded live video","zh-CN":"直播录播视频",ja:"ライブ授業録画"}, "วิดีโอประกอบกิจกรรม (ไม่นับ)":{en:"Activity video (excluded)","zh-CN":"活动视频（不计入）",ja:"活動用動画（対象外）"}, "Podcast รูปแบบวิดีโอ (ไม่ผ่าน)":{en:"Video Podcast (fail)","zh-CN":"视频型 Podcast（不通过）",ja:"動画 Podcast（不合格）"}, "อื่น ๆ (ไม่นับ)":{en:"Other (excluded)","zh-CN":"其他（不计入）",ja:"その他（対象外）"},
  "หน้าเล่น":{en:"player page","zh-CN":"播放页面",ja:"再生ページ"}, "ตัวเล่นวิดีโอ HTML":{en:"HTML video player","zh-CN":"HTML 视频播放器",ja:"HTML 動画プレーヤー"}, "ตัวเล่นเสียง HTML":{en:"HTML audio player","zh-CN":"HTML 音频播放器",ja:"HTML 音声プレーヤー"}, "metadata ของผู้ให้บริการ":{en:"provider metadata","zh-CN":"服务商元数据",ja:"プロバイダーのメタデータ"},
  "เวลาจริงจากตัวเล่นเสียง":{en:"duration from audio player","zh-CN":"音频播放器时长",ja:"音声プレーヤーの時間"}, "เวลาที่ผู้ตรวจกรอกและยืนยัน":{en:"reviewer-confirmed duration","zh-CN":"审核人确认的时长",ja:"確認者が承認した時間"}, "เวลารวมบนตัวควบคุม OneDrive":{en:"duration from OneDrive controls","zh-CN":"OneDrive 控件中的总时长",ja:"OneDrive コントロールの合計時間"},
  "ไม่พบรายงานฉบับนี้ในประวัติ กรุณาเปิดจากหน้าคิวหรือประวัติอีกครั้ง":{en:"This report was not found. Open it again from the queue or report history.","zh-CN":"未找到此报告，请从队列或报告历史重新打开。",ja:"このレポートが見つかりません。キューまたは履歴から開き直してください。"}, "ยังไม่มีผลตรวจ กรุณากลับไปกดเริ่มตรวจจากหน้ารายวิชา":{en:"No audit result is available. Start an audit from the course page.","zh-CN":"尚无审核结果，请从课程页面开始审核。",ja:"監査結果がありません。コースページから監査を開始してください。"},
  "ไม่ระบุรหัสวิชา":{en:"course-code-unknown","zh-CN":"课程代码未知",ja:"科目コード不明"}, "สรุปผลการตรวจสอบรายวิชา_ประเภท":{en:"course_audit_summary_type", "zh-CN":"课程审核摘要_类型", ja:"コース監査概要_種別"}, "วิชาปฏิบัติ":{en:"practical course","zh-CN":"实践课程",ja:"実習科目"}, "วิชาทฤษฎี":{en:"theory course","zh-CN":"理论课程",ja:"理論科目"}, "หน่วยกิต":{en:"credits","zh-CN":"学分",ja:"単位"}, "รุ่นเดิมไม่ระบุ":{en:"legacy version unknown","zh-CN":"旧版本未注明",ja:"旧版（不明）"},
  "มีรูป ชื่อ และช่องทางติดต่อครบ — ผ่าน":{en:"Photo, name, and contact channel are complete — Pass","zh-CN":"照片、姓名及联系方式完整 — 通过",ja:"写真、氏名、連絡先が揃っています — 合格"}, "ไม่มีหรือไม่ครบ — ไม่ผ่าน":{en:"Missing or incomplete — Fail","zh-CN":"缺失或不完整 — 不通过",ja:"不足または不完全 — 不合格"}, "ยังไม่ได้ตัดสิน":{en:"Not decided","zh-CN":"尚未决定",ja:"未決定"},
  "บันทึกเป็นไม่ผ่าน และไม่ถือเป็นรายการค้างตรวจ":{en:"Saved as fail; this is no longer pending review.","zh-CN":"已记录为不通过，不再列为待审核。",ja:"不合格として保存し、確認待ちから除外しました。"}, "ผู้ตรวจยืนยันว่าข้อมูลครบ":{en:"Reviewer confirmed the information is complete.","zh-CN":"审核人确认信息完整。",ja:"確認者が情報の完備を確認しました。"}, "กรุณาเลือกผลหลังตรวจหลักฐาน":{en:"Select a result after reviewing the evidence.","zh-CN":"查看证据后请选择结果。",ja:"根拠を確認して結果を選択してください。"},
  "ยืนยันว่าเป็น PDF แล้ว":{en:"Confirmed as PDF","zh-CN":"已确认为 PDF",ja:"PDF と確認済み"}, "เปิดลิงก์ได้ แต่ไม่ยืนยันว่าเป็น PDF":{en:"Link opens, but PDF type is unconfirmed","zh-CN":"链接可打开，但尚未确认为 PDF",ja:"リンクは開けますが PDF は未確認"}, "ไม่ต้องอ่านเวลา":{en:"Duration not required","zh-CN":"无需读取时长",ja:"時間の読取は不要"},
  "ซ่อนจากผู้เรียน":{en:"hidden from students","zh-CN":"对学生隐藏",ja:"学生には非表示"}, "ซ้ำ (ไม่นับเวลา)":{en:"duplicate (duration excluded)","zh-CN":"重复（不计时长）",ja:"重複（時間は対象外）"}, "เปิดลิงก์หลักฐาน":{en:"Open evidence link","zh-CN":"打开证据链接",ja:"根拠リンクを開く"}, "เปิดลิงก์":{en:"Open link","zh-CN":"打开链接",ja:"リンクを開く"},
  "ตรวจปลายทางไม่ได้":{en:"Destination could not be inspected","zh-CN":"无法检查目标链接",ja:"リンク先を確認できません"}, "ดู URL":{en:"View URL","zh-CN":"查看 URL",ja:"URLを表示"}, "ดูรายละเอียด":{en:"View details","zh-CN":"查看详情",ja:"詳細を表示"}, "กรอกเวลา":{en:"Enter duration","zh-CN":"输入时长",ja:"時間を入力"},
  "กลุ่ม:":{en:"Group:","zh-CN":"分组：",ja:"グループ："}, "ลักษณะวิชา":{en:"Course track","zh-CN":"课程类型",ja:"科目区分"}, "วิดีโอผ่าน":{en:"Video passed","zh-CN":"视频通过",ja:"動画合格"}, "Podcast ผ่าน":{en:"Podcast passed","zh-CN":"Podcast 通过",ja:"Podcast 合格"}, "ผ่านครบทั้งคู่":{en:"Both passed","zh-CN":"两项均通过",ja:"両方合格"},
  "ถึงเกณฑ์ 80 คะแนนแล้ว":{en:"The 80-point threshold has been reached.","zh-CN":"已达到 80 分标准。",ja:"80点の基準に達しました。"}, "รายงานเดิมไม่มีข้อมูลความครอบคลุม":{en:"The legacy report has no coverage data.","zh-CN":"旧报告没有覆盖数据。",ja:"旧レポートには網羅性データがありません。"}, "รายการที่ใช้เวลานานที่สุด":{en:"Slowest items","zh-CN":"耗时最长的项目",ja:"時間のかかった項目"}, "ผลจากผู้ให้บริการ":{en:"Provider result","zh-CN":"服务商结果",ja:"プロバイダー結果"}
});

Object.assign(UI, {
  "ข้อมูลและแนะนำรายวิชา":{en:"Course information and introduction","zh-CN":"课程信息与介绍",ja:"コース情報と紹介"}, "ข้อมูลผู้สอนและการติดต่อ":{en:"Instructor and contact information","zh-CN":"教师及联系方式",ja:"教員・連絡先情報"},
  "File PDF เอกสารประกอบการสอน":{en:"PDF teaching materials","zh-CN":"PDF 教学材料",ja:"PDF 講義資料"}, "วิดีโอแนะนำ/บันทึกการสอน":{en:"Introductory/recorded teaching video","zh-CN":"介绍/录播教学视频",ja:"紹介／収録授業動画"},
  "คลิปเสียง Podcast":{en:"Podcast audio","zh-CN":"Podcast 音频",ja:"Podcast 音声"}, "กิจกรรมท้ายบท":{en:"End activity","zh-CN":"章末活动",ja:"章末活動"}, "ระบบให้คำปรึกษา AI Tutor":{en:"AI Tutor support","zh-CN":"AI Tutor 辅导",ja:"AI Tutor サポート"},
  "File PDF แผนการสอน":{en:"PDF teaching plan","zh-CN":"PDF 教学计划",ja:"PDF 授業計画"}, "File PDF เอกสารประกอบ":{en:"PDF supporting document","zh-CN":"PDF 辅助材料",ja:"PDF 補助資料"},
  "วิดีโอบันทึกการสอนล่วงหน้า":{en:"Pre-recorded teaching video","zh-CN":"预录教学视频",ja:"事前収録授業動画"}, "แบบทดสอบก่อนเรียน":{en:"Pre-test","zh-CN":"课前测验",ja:"事前テスト"}, "แบบทดสอบหลังเรียน":{en:"Post-test","zh-CN":"课后测验",ja:"事後テスト"},
  "ระบบยืนยันแล้ว":{en:"Automatically confirmed","zh-CN":"系统已确认",ja:"システム確認済み"}, "ตารางที่ 3 รอผู้ตรวจ":{en:"Table 3 awaiting reviewer","zh-CN":"表 3 等待审核人确认",ja:"表3は確認者待ち"},
  "ความครอบคลุมโครงสร้าง:":{en:"Structure coverage:","zh-CN":"结构覆盖：",ja:"構成の網羅性："}, "รูปแบบครั้งเรียน:":{en:"Session mapping:","zh-CN":"课次映射：",ja:"授業回の対応："}, "ความเชื่อมั่น":{en:"Confidence","zh-CN":"置信度",ja:"信頼度"}, "กรอบเกณฑ์":{en:"Required frame","zh-CN":"标准范围",ja:"基準範囲"},
  "อ่านถึงท้ายหน้าแล้ว":{en:"Reached the end of the page","zh-CN":"已读取至页面末尾",ja:"ページ末尾まで読取済み"}, "ยังจับคู่ไม่ได้":{en:"not yet mapped","zh-CN":"尚未匹配",ja:"未対応"}, "เกินกรอบ 15 ครั้งและไม่นับคะแนน":{en:"outside the 15-session frame and excluded from scoring","zh-CN":"超出 15 次范围，不计分",ja:"15回の範囲外のため採点対象外"},
  "ระยะเวลารอบตรวจล่าสุด":{en:"Latest audit duration","zh-CN":"最近审核用时",ja:"直近の監査時間"}, "อ่านโครงสร้างหน้าเรียน":{en:"Read course structure","zh-CN":"读取课程结构",ja:"コース構成の読取"}, "เปิดและอ่านลิงก์/ไฟล์":{en:"Open and inspect links/files","zh-CN":"打开并检查链接/文件",ja:"リンク／ファイルの確認"}, "เวลารวมของรายงาน":{en:"Total report time","zh-CN":"报告总用时",ja:"レポート合計時間"}, "เฉลี่ยต่อรายการ":{en:"Average per item","zh-CN":"每项平均",ja:"項目平均"},
  "ชื่อหมวดในสรุปถูกย่อให้อ่านง่าย":{en:"Category names are shortened for readability","zh-CN":"摘要中的类别名称已简化以便阅读",ja:"概要の分類名は読みやすく短縮しています"},
  "พบคลิปเสียง Podcast ที่อัปโหลดภายใน Moodle — ไม่นับเวลาและไม่ผ่านเกณฑ์ที่กำหนดให้ใช้ลิงก์ภายนอก":{en:"Podcast audio was uploaded inside Moodle; its duration is excluded and it fails the external-link requirement.","zh-CN":"检测到上传至 Moodle 内部的 Podcast 音频；不计时长，且不符合外部链接要求。",ja:"Moodle 内にアップロードされた Podcast 音声を検出しました。時間は算入せず、外部リンク要件を満たしません。"}
});

export function browserLanguage(value = navigator.language) {
  const locale = String(value || "th").toLowerCase();
  if (locale.startsWith("zh")) return "zh-CN";
  if (locale.startsWith("ja")) return "ja";
  if (locale.startsWith("en")) return "en";
  return "th";
}

export async function getLanguage(storageKey = "uiLanguage") {
  const stored = await chrome.storage.local.get([storageKey,"uiLanguage"]);
  return SUPPORTED_LANGUAGES.includes(stored[storageKey]) ? stored[storageKey] : SUPPORTED_LANGUAGES.includes(stored.uiLanguage) ? stored.uiLanguage : browserLanguage();
}

export function translateThai(text, language) {
  if (language === "th") return text;
  if (UI[text]?.[language]) return UI[text][language];
  let translated = String(text);
  for (const key of Object.keys(UI).sort((a,b)=>b.length-a.length)) {
    const value = UI[key]?.[language];
    if (["ครั้ง","รายการ","ผล","เกณฑ์","หัวข้อ","ผ่าน","ไม่ผ่าน","นาที","วินาที","ทั้งหมด","เอกสาร","ประเภท"].includes(key)) continue;
    if (value && translated.includes(key)) translated = translated.replaceAll(key,value);
  }
  if (language === "en") translated = translated.replace(/ครั้งที่\s*([\d, –-]+)/g,"Session $1").replace(/(\d+)\s*รายการ/g,"$1 items").replace(/(\d+)\s*คะแนน/g,"$1 points");
  if (language === "zh-CN") translated = translated.replace(/ครั้งที่\s*([\d, –-]+)/g,"第$1次").replace(/(\d+)\s*รายการ/g,"$1 项").replace(/(\d+)\s*คะแนน/g,"$1 分");
  if (language === "ja") translated = translated.replace(/ครั้งที่\s*([\d, –-]+)/g,"第$1回").replace(/(\d+)\s*รายการ/g,"$1件").replace(/(\d+)\s*คะแนน/g,"$1点");
  if (language === "zh-CN" || language === "ja") translated = translated.replace(/([。；：])\s+/g,"$1");
  return translated;
}

export async function initI18n(storageKey = "uiLanguage") {
  const language = await getLanguage(storageKey);
  document.documentElement.lang = language;
  const translate = (root = document) => {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      if (["SCRIPT", "STYLE"].includes(node.parentElement?.tagName)) continue;
      const raw = node.nodeValue;
      const trimmed = raw.trim();
      const translated = translateThai(trimmed, language);
      if (trimmed && translated !== trimmed) node.nodeValue = raw.replace(trimmed, translated);
    }
    for (const element of root.querySelectorAll?.("[aria-label], [placeholder], title") || []) {
      for (const attribute of ["aria-label", "placeholder"]) {
        if (element.hasAttribute?.(attribute)) element.setAttribute(attribute, translateThai(element.getAttribute(attribute), language));
      }
      if (element.tagName === "TITLE") element.textContent = translateThai(element.textContent.trim(), language);
    }
  };
  translate();
  new MutationObserver((records) => records.forEach((record) => record.addedNodes.forEach((node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      const value = node.nodeValue.trim();
      const translated = translateThai(value, language);
      if (translated !== value) node.nodeValue = node.nodeValue.replace(value, translated);
    } else if (node.nodeType === Node.ELEMENT_NODE) translate(node);
  }))).observe(document.documentElement, {childList:true, subtree:true});
  return language;
}

export async function addLanguageMenu(container = document.querySelector(".page-head, header"), storageKey = "uiLanguage") {
  if (!container || document.querySelector("#ui-language")) return;
  if (!document.querySelector("#i18n-style")) {
    const style = document.createElement("style");
    style.id = "i18n-style";
    style.textContent = ".language-control{display:inline-flex;align-items:center;gap:6px;margin-left:auto;padding:5px 7px;border:1px solid var(--ui-border,#c6d3e2);border-radius:9px;background:var(--ui-surface,#fff);color:inherit;font-size:12px;white-space:nowrap}.language-control select{max-width:112px;border:0;background:transparent;color:inherit;font:inherit;cursor:pointer}.language-control option{color:#15263b;background:#fff}";
    document.head.append(style);
  }
  const current = await getLanguage(storageKey);
  const label = document.createElement("label");
  label.className = "language-control";
  label.setAttribute("aria-label", "Language / 语言 / 言語 / ภาษา");
    label.innerHTML = '<span class="language-icon" aria-hidden="true">🌐</span><select id="ui-language"><option value="th">ไทย</option><option value="en">English</option><option value="zh-CN">简体中文</option><option value="ja">日本語</option></select>';
  label.querySelector("select").value = current;
  label.querySelector("select").addEventListener("change", async (event) => {
    await chrome.storage.local.set({uiLanguage:event.target.value,[storageKey]:event.target.value});
    location.reload();
  });
  (container.querySelector(".head-controls") || container).append(label);
}
