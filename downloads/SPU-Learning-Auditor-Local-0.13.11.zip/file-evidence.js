(() => {
  function detectMoodleFileTypeEvidence(value) {
    const evidence = String(value || "");
    if (/(?:\/|%2f)f(?:\/|%2f)pdf\b|file[-_ ]?pdf|application\/pdf|fa-file-pdf/i.test(evidence)) return "pdf";
    if (/(?:\/|%2f)f(?:\/|%2f)audio\b|file[-_ ]?audio|audio\/(?:mpeg|mp4|ogg|wav)|fa-file-audio/i.test(evidence)) return "audio";
    if (/(?:\/|%2f)f(?:\/|%2f)video\b|file[-_ ]?video|video\/(?:mp4|webm|ogg|quicktime)|fa-file-video|modtype_(?:video|videofile|videotime|mediagallery)|\/mod\/(?:video|videofile|videotime|mediagallery)\/view\.php|(?:alt|title|aria-label)=["'][^"']*(?:video|วิดีโอ|วีดีโอ)[^"']*["']|(?:^|[\/_-])video(?:\.(?:svg|png|gif)|[\/_-])/i.test(evidence)) return "video";
    return "";
  }

  globalThis.DLearningFileEvidence = Object.freeze({ detectMoodleFileTypeEvidence });
})();
