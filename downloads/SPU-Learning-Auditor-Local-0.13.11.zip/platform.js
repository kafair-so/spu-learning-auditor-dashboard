export const LMS_HOSTS = Object.freeze(["dlearning.spu.ac.th", "ilearning.spu.ac.th"]);

export function lmsHost(value) {
  try { return new URL(String(value || "")).hostname.toLowerCase(); }
  catch { return String(value || "").toLowerCase(); }
}

export function isLmsHost(value) {
  return LMS_HOSTS.includes(lmsHost(value));
}

export function isCourseUrl(value) {
  try {
    const url = new URL(String(value || ""));
    return isLmsHost(url.hostname) && url.pathname === "/course/view.php";
  } catch { return false; }
}

export function learningPlatformName(value) {
  return lmsHost(value) === "ilearning.spu.ac.th" ? "i-Learning" : "d-Learning";
}

export function isClearlyEmptyCourseCoverage(coverage) {
  const sectionCount = Math.max(
    Number(coverage?.courseSectionCount ?? coverage?.sectionBoxes?.length ?? 0),
    Number(coverage?.declaredAuditableSectionCount ?? 0)
  );
  // Prefer the scanner's rubric-relevant count. A hidden profile/control URL
  // can be a non-forum link without being course content and must not turn an
  // otherwise empty shell into a scored 1/110 report.
  const activityCount = Number(coverage?.auditableActivityCount ?? coverage?.nonForumActivityCount ?? -1);
  return coverage?.reachedEnd === true && sectionCount > 1 && activityCount === 0;
}
