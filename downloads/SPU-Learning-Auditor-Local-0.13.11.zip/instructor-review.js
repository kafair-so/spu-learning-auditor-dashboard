export const INSTRUCTOR_DECISIONS = ["pending", "complete", "missing"];

export function normalizeInstructorDecision(state = {}) {
  if (INSTRUCTOR_DECISIONS.includes(state.instructor_information_status)) return state.instructor_information_status;
  return state.instructor_information === true ? "complete" : "pending";
}

export function applyInstructorDecision(report, decision) {
  if (!report?.weeks?.[0]?.checklist || !INSTRUCTOR_DECISIONS.includes(decision) || decision === "pending") return null;
  const index = report.courseType === "GN" ? 0 : 1;
  const row = report.weeks[0].checklist[index];
  if (!row) return null;
  if (decision === "complete") {
    row.status = "pass";
    row.detail = "ผู้ตรวจยืนยันข้อมูลผู้สอนครบ ได้แก่ รูป ชื่อ และช่องทางติดต่อ";
  } else {
    row.status = "fail";
    row.detail = "ผู้ตรวจยืนยันว่าไม่มีหรือข้อมูลผู้สอนไม่ครบ — ต้องเพิ่มรูป ชื่อ และช่องทางติดต่อ";
  }
  return row;
}
