const THEME_KEY = "auditTheme";

function resolvedTheme(value) {
  if (value === "dark" || value === "light") return value;
  return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

export async function initTheme() {
  const stored = await chrome.storage.local.get(THEME_KEY);
  let selected = stored[THEME_KEY] || "system";
  const toggle = document.querySelector("#theme");
  const apply = (value) => {
    const resolved = resolvedTheme(value);
    document.documentElement.dataset.theme = resolved;
    if (toggle?.tagName === "BUTTON") {
      const next = resolved === "dark" ? "สว่าง" : "มืด";
      toggle.innerHTML = `<span class="theme-icon" aria-hidden="true">${resolved === "dark" ? "☀" : "☾"}</span><span>โหมด${next}</span>`;
      toggle.setAttribute("aria-label",`สลับเป็นโหมด${next}`);
      toggle.title = `สลับเป็นโหมด${next}`;
      toggle.setAttribute("aria-pressed",String(resolved === "dark"));
    }
  };
  apply(selected);
  if (toggle?.tagName === "BUTTON") toggle.addEventListener("click", async () => {
    selected = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
    apply(selected);
    await chrome.storage.local.set({ [THEME_KEY]: selected });
  });
  chrome.storage.onChanged?.addListener((changes, area) => {
    if (area !== "local" || !changes[THEME_KEY]) return;
    selected = changes[THEME_KEY].newValue || "system";
    apply(selected);
  });
  window.matchMedia?.("(prefers-color-scheme: dark)").addEventListener?.("change", () => {
    if (selected === "system") apply("system");
  });
}
