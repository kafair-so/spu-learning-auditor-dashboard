export const CURRENT_TERM_CODE = "691";
export const MOODLE_QUIZ_TOLERANCE_LAST_WEEK = 10;
export const MOODLE_QUIZ_TOLERANCE_START = "2569-08-24";
export const MOODLE_QUIZ_TOLERANCE_END = "2569-11-01";

export function courseTermCode(value = "") {
  return String(value || "").trim().match(/^(\d{3})(?:GN|GR|GS)-/i)?.[1] || "";
}

export function moodleQuizTolerance({courseProfile = "", auditSession = 0, kind = "", groupContext = "", title = ""} = {}) {
  const week = Number(auditSession || 0);
  const allowedWeek = Number.isInteger(week) && week >= 1 && week <= MOODLE_QUIZ_TOLERANCE_LAST_WEEK;
  const allowedTerm = courseTermCode(courseProfile) === CURRENT_TERM_CODE;
  const context = `${title} ${groupContext}`;
  const role = kind === "pre_quiz" || /(?:pre\s*[-–—]?\s*test|แบบ\s*ทดสอบ\s*ก่อน\s*เรียน|ทดสอบ\s*ก่อน\s*เรียน)/i.test(context) ? "pre_quiz"
    : kind === "post_quiz" || /(?:post\s*[-–—]?\s*test|แบบ\s*ทดสอบ\s*หลัง\s*เรียน|ทดสอบ\s*หลัง\s*เรียน)/i.test(context) ? "post_quiz"
      : /กิจกรรม(?:ท้าย\s*บท(?:เรียน)?|ประจำ\s*(?:สัปดาห์|บท))|after[ -]?class\s*activity|assignment|homework|worksheet|work\s*sheet/i.test(context) ? "assignment" : "";
  return {eligible:Boolean(allowedTerm && allowedWeek && role), role, week, allowedTerm, allowedWeek};
}
