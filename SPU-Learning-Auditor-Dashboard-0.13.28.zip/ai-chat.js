export const AI_CHAT_PROVIDER_ORIGINS = [
  "https://chatgpt.com/*", "https://chat.openai.com/*", "https://poe.com/*",
  "https://gemini.google.com/*", "https://copilot.microsoft.com/*", "https://claude.ai/*",
  "https://perplexity.ai/*", "https://www.perplexity.ai/*", "https://character.ai/*",
  "https://*.botpress.cloud/*", "https://*.chatbase.co/*", "https://*.voiceflow.com/*",
  "https://udify.app/*", "https://*.udify.app/*", "https://*.dify.ai/*", "https://*.coze.com/*",
  "https://spuai.spu.ac.th/*", "https://spu-km.jib-ai.com/*"
];

export function aiChatOriginsForUrl(targetUrl) {
  let host;
  try { host = new URL(targetUrl).hostname.toLowerCase(); } catch { return []; }
  if (host === "chatgpt.com") return ["https://chatgpt.com/*"];
  if (host === "chat.openai.com") return ["https://chat.openai.com/*"];
  if (host === "poe.com") return ["https://poe.com/*"];
  if (host === "gemini.google.com") return ["https://gemini.google.com/*"];
  if (host === "copilot.microsoft.com") return ["https://copilot.microsoft.com/*"];
  if (host === "claude.ai") return ["https://claude.ai/*"];
  if (host === "perplexity.ai") return ["https://perplexity.ai/*"];
  if (host === "www.perplexity.ai") return ["https://www.perplexity.ai/*"];
  if (host === "character.ai" || host.endsWith(".character.ai")) return ["https://character.ai/*"];
  if (host.endsWith(".botpress.cloud")) return ["https://*.botpress.cloud/*"];
  if (host.endsWith(".chatbase.co")) return ["https://*.chatbase.co/*"];
  if (host.endsWith(".voiceflow.com")) return ["https://*.voiceflow.com/*"];
  if (host === "udify.app") return ["https://udify.app/*"];
  if (host.endsWith(".udify.app")) return ["https://*.udify.app/*"];
  if (host.endsWith(".dify.ai")) return ["https://*.dify.ai/*"];
  if (host.endsWith(".coze.com")) return ["https://*.coze.com/*"];
  if (host === "spuai.spu.ac.th") return ["https://spuai.spu.ac.th/*"];
  if (host === "spu-km.jib-ai.com") return ["https://spu-km.jib-ai.com/*"];
  return [];
}

export function knownAiChatProvider(targetUrl) {
  return aiChatOriginsForUrl(targetUrl).length > 0;
}

export function trustedSpuAiProvider(targetUrl) {
  try {
    const host = new URL(targetUrl).hostname.toLowerCase();
    return host === "spuai.spu.ac.th" || host === "spu-km.jib-ai.com";
  } catch {
    return false;
  }
}

export function evaluateAiChatEvidence(evidence = {}) {
  const knownProvider = knownAiChatProvider(evidence.url || "");
  const hasComposer = Number(evidence.composerCount || 0) > 0;
  const hasSendAction = Number(evidence.sendActionCount || 0) > 0;
  const hasConversation = Number(evidence.conversationRegionCount || 0) > 0 || Boolean(evidence.assistantSignal);
  if (hasComposer && (hasSendAction || hasConversation || knownProvider)) {
    return {status:"confirmed", confirmed:true, reason:"พบช่องพิมพ์และองค์ประกอบสนทนากับ AI"};
  }
  if (evidence.loaded && !hasComposer && (Boolean(evidence.marketingSignal) || knownProvider)) {
    return {status:"not_chat", confirmed:false, reason:"ปลายทางเปิดได้ แต่ไม่พบหน้าแชทหรือช่องพิมพ์ข้อความ"};
  }
  return {status:"unresolved", confirmed:false, reason:"เปิดปลายทางได้ แต่ยังยืนยันโครงสร้างหน้าแชทไม่ได้"};
}
