import assert from "node:assert/strict";
import { applyPodcastReviews, parsePodcastDuration, podcastDurationInput, podcastEvidenceFingerprint } from "../podcast-review.js";

assert.equal(parsePodcastDuration("10:31"), 631);
assert.equal(parsePodcastDuration("1:02:15"), 3735);
assert.equal(parsePodcastDuration("10:99"), null);
assert.equal(parsePodcastDuration(""), null);
assert.equal(podcastDurationInput(631), "10:31");
assert.equal(podcastDurationInput(3735), "1:02:15");

const audio = {kind:"podcast",href:"moodle:audio",mediaType:"audio",durationSeconds:999,mediaStatus:"podcast_audio",accessNote:"ยืนยันว่าเป็นคลิปเสียง"};
const video = {kind:"podcast",href:"moodle:video",mediaType:"video",durationSeconds:999,mediaStatus:"podcast_video",accessNote:"ปลายทางเป็นวิดีโอ"};
const unknown = {kind:"podcast",href:"moodle:unknown",mediaType:null,durationSeconds:999,mediaStatus:"podcast_type_unverified"};
applyPodcastReviews([audio, video, unknown], {
  "moodle:audio":{seconds:631,confirmed:true},
  "moodle:video":{seconds:3600,confirmed:true},
  "moodle:unknown":{seconds:3600,confirmed:true}
});
assert.equal(audio.durationSeconds, 631, "reviewer-confirmed Podcast time must replace legacy automatic time");
assert.equal(audio.automaticDurationSeconds, null);
assert.equal(audio.reviewerDurationConfirmed, true);
assert.equal(video.durationSeconds, null, "a video Podcast can never be overridden into passing");
assert.equal(video.reviewerDurationConfirmed, false);
assert.equal(unknown.durationSeconds, null, "an unverified media type cannot receive a scoring duration");
assert.equal(unknown.reviewerDurationSeconds, 3600, "unknown media type must preserve a time draft without counting it");
assert.equal(unknown.reviewerDurationConfirmed, false);
const draft = {kind:"podcast",href:"draft",mediaType:"audio"};
applyPodcastReviews([draft], {draft:{seconds:615,confirmed:false}});
assert.equal(draft.reviewerDurationSeconds, 615);
assert.equal(draft.durationSeconds, null);

applyPodcastReviews([audio], {});
assert.equal(audio.durationSeconds, null, "removing reviewer confirmation must revoke Podcast scoring time");
assert.equal(audio.accessNote, "ยืนยันว่าเป็นคลิปเสียง", "removing confirmation must restore type evidence");
applyPodcastReviews([draft], {draft:{seconds:615,confirmed:true}});
assert.equal(draft.durationSeconds,615);
assert.equal(draft.reviewerDurationConfirmed,true);
applyPodcastReviews([draft], {});
assert.equal(draft.durationSeconds,null,"manual-only duration must be revoked when unconfirmed");
const internalUpload={kind:"podcast",href:"moodle:uploaded",linkStatus:"internal",podcastDelivery:"internal_upload",mediaType:"audio",accessNote:"อัปโหลดภายใน Moodle"};
applyPodcastReviews([internalUpload],{"moodle:uploaded":{seconds:900,confirmed:true}});
assert.equal(internalUpload.durationSeconds,null,"an internal Moodle upload must ignore stale confirmed Podcast time");
assert.equal(internalUpload.reviewerDurationSeconds,null,"an internal Moodle upload must not restore a manual time draft");
assert.equal(internalUpload.reviewerDurationConfirmed,false);
const original={kind:"podcast",href:"moodle:same",externalUrl:"https://drive.google.com/file/d/OLD/view",mediaType:"audio",title:"Podcast 1",auditSession:1};
const changed={...original,externalUrl:"https://drive.google.com/file/d/NEW/view"};
const signed={seconds:600,confirmed:true,fingerprint:podcastEvidenceFingerprint(original)};
applyPodcastReviews([changed],{"moodle:same":signed});
assert.equal(changed.reviewerDurationConfirmed,false,"a changed final target must invalidate the old confirmation");
assert.equal(changed.previousPodcastReviewInvalidated,true);
const renamed={...original,href:"moodle:new-wrapper",title:"Podcast renamed",auditSession:9};
applyPodcastReviews([renamed],{"moodle:old-wrapper":{seconds:600,confirmed:true,confirmedAt:"2026-10-30T10:00:00Z",targetUrl:original.externalUrl,fingerprint:podcastEvidenceFingerprint(original)}});
assert.equal(renamed.reviewerDurationConfirmed,true,"the same final Podcast destination must reuse confirmation across a renamed or moved Moodle item");
assert.equal(renamed.reviewReused,true);
console.log("podcast review tests passed: reviewer-only time, video rejection, drafts, revocation and internal-upload exclusion");
