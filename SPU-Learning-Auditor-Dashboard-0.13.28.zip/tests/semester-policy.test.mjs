import assert from "node:assert/strict";
import test from "node:test";
import {moodleQuizTolerance} from "../semester-policy.js";

test("Moodle Quiz tolerance is limited to term 1/2569 weeks 1-10", () => {
  assert.equal(moodleQuizTolerance({courseProfile:"691GR-ABC101(T)-(T)",auditSession:1,kind:"pre_quiz"}).eligible,true);
  assert.equal(moodleQuizTolerance({courseProfile:"691GS-ABC101(T)-(T)",auditSession:10,kind:"post_quiz"}).eligible,true);
  assert.equal(moodleQuizTolerance({courseProfile:"691GR-ABC101(T)-(T)",auditSession:11,kind:"pre_quiz"}).eligible,false);
  assert.equal(moodleQuizTolerance({courseProfile:"692GR-ABC101(T)-(T)",auditSession:1,kind:"pre_quiz"}).eligible,false);
});

test("ordinary Moodle Quiz needs an explicit end-activity label", () => {
  assert.equal(moodleQuizTolerance({courseProfile:"691GR-ABC101(T)-(T)",auditSession:4,kind:"quiz",groupContext:"กิจกรรมท้ายบทเรียน"}).role,"assignment");
  assert.equal(moodleQuizTolerance({courseProfile:"691GR-ABC101(T)-(T)",auditSession:4,kind:"quiz",groupContext:"แบบฝึกหัดทั่วไป"}).eligible,false);
});

test("the role may come from either the item name or its enclosing label", () => {
  assert.equal(moodleQuizTolerance({courseProfile:"691GR-ABC101(T)-(T)",auditSession:2,kind:"quiz",title:"แบบทดสอบ Pre-test"}).role,"pre_quiz");
  assert.equal(moodleQuizTolerance({courseProfile:"691GR-ABC101(T)-(T)",auditSession:2,kind:"quiz",groupContext:"Post test"}).role,"post_quiz");
});
