import assert from "node:assert/strict";
import fs from "node:fs";
import {AI_CHAT_PROVIDER_ORIGINS, aiChatOriginsForUrl, evaluateAiChatEvidence, trustedSpuAiProvider} from "../ai-chat.js";

assert.deepEqual(aiChatOriginsForUrl("https://chatgpt.com/g/g-example/course-tutor"), ["https://chatgpt.com/*"]);
assert.deepEqual(aiChatOriginsForUrl("https://course.botpress.cloud/webchat"), ["https://*.botpress.cloud/*"]);
assert.deepEqual(aiChatOriginsForUrl("https://example.com/ai"), [], "an arbitrary AI-themed site must not be auto-confirmed");
assert.equal(evaluateAiChatEvidence({url:"https://chatgpt.com/g/g-example",loaded:true,composerCount:1,sendActionCount:1}).status,"confirmed");
assert.equal(evaluateAiChatEvidence({url:"https://poe.com/about",loaded:true,composerCount:0,marketingSignal:true}).status,"not_chat");
assert.equal(evaluateAiChatEvidence({url:"https://example.com/bot",loaded:true,composerCount:1,sendActionCount:0,conversationRegionCount:0}).status,"unresolved","a generic text field alone must not prove an AI chat");
assert.equal(trustedSpuAiProvider("https://spuai.spu.ac.th/chat/example"),true,"SPU AI may pass without a reviewer login");
assert.equal(trustedSpuAiProvider("https://spu-km.jib-ai.com/bot/example"),true,"the SPU-managed JIB AI host is also trusted");
assert.equal(trustedSpuAiProvider("https://chatgpt.com/g/example"),false,"external providers must still expose a real chat page");

const manifest = JSON.parse(fs.readFileSync(new URL("../manifest.json",import.meta.url),"utf8"));
for (const origin of AI_CHAT_PROVIDER_ORIGINS) assert.ok(manifest.optional_host_permissions.includes(origin),`manifest must declare ${origin}`);
const worker = fs.readFileSync(new URL("../background.js",import.meta.url),"utf8");
assert.match(worker,/inspectAiChatTarget\(activity\.externalUrl/);
assert.match(worker,/ปลายทางไม่ใช่หน้าแชทกับ AI/);
console.log("AI chat tests passed");
