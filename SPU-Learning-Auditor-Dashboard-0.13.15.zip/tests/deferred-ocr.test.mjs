import assert from "node:assert/strict";
import fs from "node:fs";

const content = fs.readFileSync(new URL("../content.js", import.meta.url), "utf8");
const background = fs.readFileSync(new URL("../background.js", import.meta.url), "utf8");

const structureStart = content.indexOf("const collectEntireCourse = async () =>");
const structureEnd = content.indexOf("const collectDeferredOcrEvidence = async () =>");
const structureScanner = content.slice(structureStart, structureEnd);

assert.ok(structureStart >= 0 && structureEnd > structureStart, "the structure and deferred OCR phases must both exist");
assert.doesNotMatch(structureScanner, /await collect(?:AssignmentImage|AfterClassPill|AssessmentPill)Evidence\(/,
  "the structure phase must never wait for OCR evidence");
assert.match(content, /message\.type === "SCAN_COURSE_OCR"/, "OCR must run through a separate second-phase message");
assert.match(content, /assignmentTextEvidence\(instructionText, "กิจกรรมท้ายบท"\)/,
  "decorative images must be rejected from the after-class OCR path before OCR starts");
assert.match(content, /readImageWhenUnresolved/, "visible image labels must be used before OCR");

assert.match(background, /scanDeferredCourseOcr/, "the background worker must start OCR only after structure collection");
assert.match(background, /ocrEvidenceStatus:ocr\.status/, "the report must retain OCR completion state separately");
assert.match(background, /return \{activities:\[\],status:result\?\.timedOut \? "timeout" : "unavailable"/,
  "an OCR timeout must fall back to the structure result instead of failing the course");

console.log("deferred OCR tests passed: structure first, targeted OCR second, non-fatal fallback");
